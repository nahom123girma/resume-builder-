import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#F4EDE0',
        'cream-2': '#EFE6D4',
        paper: '#FAF6EC',
        'paper-2': '#F8F2E4',
        ink: '#1B1916',
        'ink-soft': '#3A352D',
        'ink-mute': '#6E6557',
        rule: '#D9CFB8',
        'rule-soft': '#E5DCC4',
        amber: '#C44A1A',
        'amber-deep': '#9F3A13',
        moss: '#3D5240',
        clay: '#A86B3D',
        brick: '#8E3320',
      },
      fontFamily: {
        serif: ['var(--font-fraunces)', 'Georgia', 'serif'],
        sans: ['var(--font-plex-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-plex-mono)', 'monospace'],
      },
      boxShadow: {
        soft: '0 1px 0 rgba(27,25,22,.04), 0 12px 30px -10px rgba(27,25,22,.12)',
        'soft-lg': '0 30px 80px -30px rgba(27,25,22,.28)',
      },
    },
  },
  plugins: [],
};
export default config;
