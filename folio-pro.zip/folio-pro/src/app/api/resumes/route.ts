import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { EMPTY_RESUME } from '@/lib/resume-types';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const resumes = await db.resume.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: 'desc' },
    select: { id: true, title: true, templateId: true, data: true, createdAt: true, updatedAt: true },
  });
  return NextResponse.json({ resumes });
}

const CreateBody = z.object({
  title: z.string().optional(),
  templateId: z.string().optional(),
  data: z.any().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body: z.infer<typeof CreateBody> = {};
  try {
    body = CreateBody.parse(await req.json());
  } catch {
    /* ok, defaults below */
  }

  const resume = await db.resume.create({
    data: {
      userId: user.id,
      title: body.title ?? 'Untitled résumé',
      templateId: body.templateId ?? 'broadsheet',
      data: body.data ?? (EMPTY_RESUME as any),
    },
  });
  return NextResponse.json({ resume });
}
