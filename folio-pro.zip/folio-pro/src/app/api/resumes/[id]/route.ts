import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

type Ctx = { params: Promise<{ id: string }> };

async function ownedBy(userId: string, id: string) {
  return db.resume.findFirst({ where: { id, userId } });
}

export async function GET(_req: Request, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { id } = await ctx.params;
  const r = await ownedBy(user.id, id);
  if (!r) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ resume: r });
}

const UpdateBody = z.object({
  title: z.string().optional(),
  templateId: z.string().optional(),
  data: z.any().optional(),
});

export async function PUT(req: Request, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { id } = await ctx.params;
  const owned = await ownedBy(user.id, id);
  if (!owned) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  let body: z.infer<typeof UpdateBody>;
  try {
    body = UpdateBody.parse(await req.json());
  } catch {
    return NextResponse.json({ error: 'Invalid body' }, { status: 400 });
  }

  const updated = await db.resume.update({
    where: { id },
    data: {
      title: body.title ?? undefined,
      templateId: body.templateId ?? undefined,
      data: body.data ?? undefined,
    },
  });
  return NextResponse.json({ resume: updated });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { id } = await ctx.params;
  const owned = await ownedBy(user.id, id);
  if (!owned) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  await db.resume.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
