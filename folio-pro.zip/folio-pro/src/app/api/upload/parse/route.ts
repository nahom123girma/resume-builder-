import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { extractText } from '@/lib/file-extract';
import { completeJSON } from '@/lib/anthropic';
import { EMPTY_RESUME, type ResumeData } from '@/lib/resume-types';

export const runtime = 'nodejs'; // unpdf and mammoth need Node, not Edge
export const maxDuration = 30;   // allow up to 30s for parse + AI

const PARSE_SYSTEM = `You parse résumé text into structured JSON.

Return JSON in this EXACT shape — no extra fields, no missing required fields:

{
  "name": string,
  "title": string,
  "email": string,
  "phone": string,
  "location": string,
  "website": string,
  "linkedin": string,
  "summary": string,
  "experience": [
    {
      "title": string,
      "company": string,
      "location": string,
      "start": string,
      "end": string,
      "bullets": string[]
    }
  ],
  "education": [
    {
      "degree": string,
      "school": string,
      "location": string,
      "start": string,
      "end": string
    }
  ],
  "skills": string[],
  "projects": [
    { "name": string, "url": string, "description": string, "bullets": string[] }
  ],
  "certifications": [
    { "name": string, "issuer": string, "date": string, "credentialId": string }
  ]
}

RULES
- NEVER invent information. If a field is missing from the source, use empty string "" or [].
- "title" is the candidate's CURRENT or most recent role title (e.g. "Senior Engineer"), not "Resume" or "CV".
- "summary" is the personal summary/profile/objective section. Empty string if not present.
- Preserve bullets as written — do not paraphrase, do not rewrite, do not strip leading dashes/bullets if the content makes sense.
- Each bullet should be ONE complete thought. If the PDF broke a bullet across multiple lines, merge them.
- Dates as strings. Normalize to "Mon YYYY" format ("Mar 2022", "Jan 2024"). For ongoing roles use "Present". For year-only sources, just use "2022".
- "skills" is the explicit skills section, comma- or pipe- or bullet-separated. Do not infer skills from job descriptions or experience bullets — only what's explicitly listed.
- "projects" and "certifications" only if explicitly present as their own sections.
- For each experience item, "location" can be empty if not in the source.

The input may be messy — broken whitespace from PDF extraction, columns merged together, inconsistent formatting. Use your best judgment to interpret structure.`;

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: 'Invalid upload' }, { status: 400 });
  }

  const file = form.get('file');
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
  }

  // 1. Extract raw text
  let extracted;
  try {
    extracted = await extractText(file);
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? 'Could not read file' }, { status: 415 });
  }

  if (extracted.text.length < 80) {
    return NextResponse.json(
      { error: "We couldn't read enough text from that file. Make sure it isn't scanned image-only." },
      { status: 422 }
    );
  }

  // 2. Send to Claude for structuring
  let parsed: ResumeData;
  try {
    const { data } = await completeJSON<ResumeData>({
      tier: 'smart', // accuracy matters here
      maxTokens: 4000,
      system: PARSE_SYSTEM,
      user: `RÉSUMÉ TEXT (extracted from ${extracted.kind.toUpperCase()}):\n\n${extracted.text}\n\nReturn the JSON now.`,
    });
    // Defensively merge with EMPTY_RESUME so missing keys don't crash the editor
    parsed = {
      ...EMPTY_RESUME,
      ...data,
      experience: Array.isArray(data?.experience) ? data.experience : [],
      education: Array.isArray(data?.education) ? data.education : [],
      skills: Array.isArray(data?.skills) ? data.skills : [],
      projects: Array.isArray(data?.projects) ? data.projects : [],
      certifications: Array.isArray(data?.certifications) ? data.certifications : [],
    };
  } catch (err: any) {
    console.error('[upload/parse] AI structuring failed:', err);
    return NextResponse.json(
      { error: 'AI parsing failed. Try again, or build from a template.' },
      { status: 502 }
    );
  }

  // 3. Persist as a new résumé so the user can immediately edit it
  const title =
    extracted.filename.replace(/\.(pdf|docx)$/i, '').slice(0, 80) ||
    parsed.name ||
    'Imported résumé';

  const resume = await db.resume.create({
    data: {
      userId: user.id,
      title,
      templateId: 'broadsheet',
      data: parsed as any,
    },
  });

  return NextResponse.json({
    resumeId: resume.id,
    parsed,
    meta: {
      filename: extracted.filename,
      kind: extracted.kind,
      bytes: extracted.bytes,
    },
  });
}
