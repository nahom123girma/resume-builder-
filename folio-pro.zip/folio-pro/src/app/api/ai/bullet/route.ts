import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUser } from '@/lib/auth';
import { completeJSON } from '@/lib/anthropic';

const Body = z.object({
  bullet: z.string().min(3),
  context: z
    .object({
      role: z.string().optional(),
      company: z.string().optional(),
    })
    .optional(),
});

type AIResponse = { rewrites: string[] };

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try {
    body = Body.parse(await req.json());
  } catch {
    return NextResponse.json({ error: 'Invalid body' }, { status: 400 });
  }

  const ctx = [
    body.context?.role && `Role: ${body.context.role}`,
    body.context?.company && `Company: ${body.context.company}`,
  ]
    .filter(Boolean)
    .join('\n');

  try {
    const { data } = await completeJSON<AIResponse>({
      tier: 'fast',
      system: `You rewrite résumé bullets to be stronger. Return JSON in this exact shape:

{ "rewrites": ["...", "...", "..."] }

RULES
- Exactly 3 rewrites.
- Each starts with a strong action verb (Built, Led, Shipped, Reduced, Scaled — never "Responsible for" or "Helped").
- Quantify when at all plausible from the original (%, $, count, time).
- One sentence each, 12–22 words.
- Never invent specific numbers the original didn't imply. If the original has no numbers, leave the metric vague but keep the verb strong.
- Preserve the factual content. Don't change what was done — only how it's described.`,
      user: `${ctx ? ctx + '\n\n' : ''}Original bullet:\n"${body.bullet}"\n\nReturn the JSON now.`,
      maxTokens: 400,
    });

    if (!Array.isArray(data?.rewrites)) {
      return NextResponse.json({ error: 'AI returned invalid shape.' }, { status: 502 });
    }
    return NextResponse.json({ rewrites: data.rewrites.slice(0, 3) });
  } catch (err: any) {
    console.error('[ai/bullet]', err);
    return NextResponse.json({ error: 'AI request failed.' }, { status: 500 });
  }
}
