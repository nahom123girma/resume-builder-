import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUser } from '@/lib/auth';
import { completeJSON } from '@/lib/anthropic';
import type { ResumeData } from '@/lib/resume-types';

export const runtime = 'nodejs';
export const maxDuration = 20;

const Body = z.object({ data: z.any() });

export type ImprovementsResult = {
  weakBullets: {
    expIndex: number;
    bulletIndex: number;
    original: string;
    reason: string;
    suggested: string;
  }[];
  missingSkills: string[];
  formattingIssues: string[];
  overallScore: number; // 0-100, the rough quality of the résumé as-is
};

const SYSTEM = `You audit a parsed résumé and return targeted improvements.

Return JSON in EXACTLY this shape:

{
  "weakBullets": [
    {
      "expIndex": 0,
      "bulletIndex": 1,
      "original": "...",
      "reason": "No quantification" | "No action verb" | "Generic phrasing" | "Too short" | "Vague outcome",
      "suggested": "..."
    }
  ],
  "missingSkills": ["..."],
  "formattingIssues": ["..."],
  "overallScore": 0-100
}

RULES
- weakBullets: at most 5. Pick the worst offenders across all experience entries. Don't include strong bullets. The "suggested" rewrite must preserve the factual content — never invent numbers or outcomes that weren't implied.
- missingSkills: at most 6. Include a skill ONLY if it's clearly demonstrated by experience but missing from the explicit skills list. (e.g. they list "Engineer at Stripe building payment APIs" but "API design" is not in skills — include "API design".)
- formattingIssues: at most 4. Concrete and actionable. Examples: "Current role missing end date — use 'Present'", "No location for any role", "No professional summary", "Education is missing graduation year".
- overallScore is a holistic 0-100. Strong résumé with clear quantification, action verbs, full sections = 80+. Average résumé = 50-70. Sparse or poorly written = below 50.
- If the résumé has no experience entries, skip weakBullets entirely (return []) and put "No experience entries listed" in formattingIssues.`;

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try {
    body = Body.parse(await req.json());
  } catch {
    return NextResponse.json({ error: 'Invalid body' }, { status: 400 });
  }
  const data = body.data as ResumeData;

  // Compact representation
  const compact = [
    data.title && `Target: ${data.title}`,
    data.summary && `Summary: ${data.summary}`,
    data.experience?.length &&
      'Experience:\n' +
        data.experience
          .map(
            (x, i) =>
              `[exp ${i}] ${x.title} @ ${x.company} (${x.start || '?'}–${x.end || '?'}); location=${x.location || ''}\n` +
              x.bullets.map((b, j) => `  [bullet ${j}] ${b}`).join('\n')
          )
          .join('\n'),
    `Skills: ${(data.skills ?? []).join(', ')}`,
    data.education?.length &&
      'Education:\n' +
        data.education
          .map((e) => `${e.degree} @ ${e.school} (${e.start || '?'}–${e.end || '?'})`)
          .join('\n'),
  ]
    .filter(Boolean)
    .join('\n\n');

  try {
    const { data: result } = await completeJSON<ImprovementsResult>({
      tier: 'smart',
      maxTokens: 1500,
      system: SYSTEM,
      user: `RÉSUMÉ:\n${compact}\n\nReturn the JSON audit now.`,
    });
    // Defensive defaults
    const safe: ImprovementsResult = {
      weakBullets: Array.isArray(result.weakBullets) ? result.weakBullets.slice(0, 5) : [],
      missingSkills: Array.isArray(result.missingSkills) ? result.missingSkills.slice(0, 6) : [],
      formattingIssues: Array.isArray(result.formattingIssues) ? result.formattingIssues.slice(0, 4) : [],
      overallScore: typeof result.overallScore === 'number' ? Math.max(0, Math.min(100, result.overallScore)) : 60,
    };
    return NextResponse.json({ improvements: safe });
  } catch (err: any) {
    console.error('[ai/improvements]', err);
    return NextResponse.json({ error: 'AI request failed.' }, { status: 500 });
  }
}
