import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUser } from '@/lib/auth';
import { complete } from '@/lib/anthropic';
import type { ResumeData } from '@/lib/resume-types';

const Body = z.object({
  data: z.any(), // partial ResumeData
  tone: z.enum(['confident', 'understated', 'concise']).optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try {
    body = Body.parse(await req.json());
  } catch {
    return NextResponse.json({ error: 'Invalid body' }, { status: 400 });
  }

  const data = body.data as ResumeData;

  // Build a compact context from whatever they've filled in
  const context = [
    data.title && `Role: ${data.title}`,
    data.experience?.length &&
      `Experience: ${data.experience
        .slice(0, 3)
        .map((x) => `${x.title} at ${x.company} (${x.start}–${x.end ?? 'present'})`)
        .join('; ')}`,
    data.skills?.length && `Skills: ${data.skills.slice(0, 12).join(', ')}`,
    data.education?.length &&
      `Education: ${data.education.map((e) => `${e.degree} from ${e.school}`).join('; ')}`,
  ]
    .filter(Boolean)
    .join('\n');

  const tone = body.tone ?? 'confident';

  try {
    const { text } = await complete({
      tier: 'fast',
      system: `You write professional résumé summaries. Output ONLY the summary text — no preamble, no explanation, no quotes around it.

RULES
- 2–3 sentences, 35–60 words.
- ${tone === 'understated' ? 'Calm, factual tone. No hype.' : tone === 'concise' ? 'Maximum brevity. No filler.' : 'Confident, specific. Lead with the strongest credential.'}
- Never invent facts not in the candidate context.
- No clichés ("results-driven", "passionate", "team player", "synergy").
- Specific over generic. Quantified when context allows.`,
      user: `Candidate context:\n${context || 'No context yet — write a placeholder.'}\n\nWrite the summary now.`,
      maxTokens: 200,
    });

    return NextResponse.json({ summary: text.trim() });
  } catch (err: any) {
    console.error('[ai/summary]', err);
    return NextResponse.json({ error: 'AI request failed.' }, { status: 500 });
  }
}
