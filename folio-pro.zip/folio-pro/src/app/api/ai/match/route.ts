import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUser } from '@/lib/auth';
import { completeJSON } from '@/lib/anthropic';
import type { ResumeData } from '@/lib/resume-types';

const Body = z.object({
  resume: z.any(), // ResumeData
  jobDescription: z.string().min(40, 'Paste a longer job description.'),
});

type MatchResult = {
  matchScore: number; // 0-100
  atsScore: number; // 0-100
  matchedSkills: string[];
  missingSkills: string[];
  keywordOverlap: { resume: string[]; jd: string[]; common: string[] };
  improvements: { add: string[]; remove: string[]; rewrite: string[] };
  summary: string; // 1-2 sentences
};

function compactResume(d: ResumeData): string {
  const parts: string[] = [];
  if (d.title) parts.push(`Target role: ${d.title}`);
  if (d.summary) parts.push(`Summary: ${d.summary}`);
  if (d.experience?.length) {
    parts.push(
      'Experience:\n' +
        d.experience
          .map(
            (x) =>
              `- ${x.title} @ ${x.company} (${x.start}–${x.end ?? 'present'}): ${x.bullets.join(' | ')}`
          )
          .join('\n')
    );
  }
  if (d.skills?.length) parts.push(`Skills: ${d.skills.join(', ')}`);
  if (d.education?.length) {
    parts.push(
      'Education: ' + d.education.map((e) => `${e.degree}, ${e.school} (${e.end ?? ''})`).join('; ')
    );
  }
  return parts.join('\n\n');
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try {
    body = Body.parse(await req.json());
  } catch (err: any) {
    return NextResponse.json({ error: err.errors?.[0]?.message ?? 'Invalid body' }, { status: 400 });
  }

  const compactedResume = compactResume(body.resume as ResumeData);

  try {
    const { data } = await completeJSON<MatchResult>({
      tier: 'smart',
      maxTokens: 1800,
      system: `You're a senior recruiter and ATS expert. Compare a résumé to a job description and return a structured fit analysis.

Return JSON in EXACTLY this shape:
{
  "matchScore": 0-100,         // overall fit, weighted on skills + experience relevance
  "atsScore": 0-100,            // formatting/keyword optimization for ATS parsing
  "matchedSkills": ["..."],     // skills the resume already has that the JD wants
  "missingSkills": ["..."],     // critical JD skills the resume lacks (max 8)
  "keywordOverlap": {
    "resume": ["..."],          // top 12 keywords from resume
    "jd":     ["..."],          // top 12 keywords from JD
    "common": ["..."]           // intersection
  },
  "improvements": {
    "add": ["..."],             // specific things to add (max 5, action-oriented)
    "remove": ["..."],          // things to remove or de-emphasize (max 3)
    "rewrite": ["..."]          // bullets/phrases to strengthen (max 4, quote the original snippet)
  },
  "summary": "..."              // 1-2 sentence verdict
}

RULES
- Be honest, not flattering. If the fit is weak, say so.
- "missingSkills" must be skills genuinely required by the JD that genuinely don't appear in the résumé.
- "improvements.rewrite" should quote a snippet from the résumé and pair it with what to change.
- matchScore 90+ is a near-perfect fit; 70-89 strong; 50-69 partial; below 50 weak.`,
      user: `RÉSUMÉ:\n${compactedResume}\n\n=====\n\nJOB DESCRIPTION:\n${body.jobDescription}\n\nReturn the JSON now.`,
    });

    return NextResponse.json({ analysis: data });
  } catch (err: any) {
    console.error('[ai/match]', err);
    return NextResponse.json({ error: 'AI request failed.' }, { status: 500 });
  }
}
