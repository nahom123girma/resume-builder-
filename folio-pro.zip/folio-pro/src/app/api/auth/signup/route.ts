import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { hashPassword, createSession } from '@/lib/auth';

const Body = z.object({
  email: z.string().email(),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
  name: z.string().optional(),
});

export async function POST(req: Request) {
  let body;
  try {
    body = Body.parse(await req.json());
  } catch (err: any) {
    return NextResponse.json({ error: err.errors?.[0]?.message ?? 'Invalid input' }, { status: 400 });
  }

  const email = body.email.toLowerCase();
  const exists = await db.user.findUnique({ where: { email } });
  if (exists) {
    return NextResponse.json({ error: 'That email is already registered.' }, { status: 409 });
  }

  const user = await db.user.create({
    data: {
      email,
      passwordHash: await hashPassword(body.password),
      name: body.name ?? email.split('@')[0],
    },
    select: { id: true, email: true, name: true, plan: true },
  });

  await createSession(user.id);
  return NextResponse.json({ user });
}
