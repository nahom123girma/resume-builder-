import Link from 'next/link';
import { requireUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { Nav } from '@/components/nav';
import { TEMPLATES } from '@/components/templates';
import type { ResumeData } from '@/lib/resume-types';
import { DashboardActions } from './actions';

function fmtAgo(d: Date) {
  const ms = Date.now() - new Date(d).getTime();
  const m = Math.floor(ms / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.floor(h / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default async function DashboardPage() {
  const user = await requireUser();
  const resumes = await db.resume.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: 'desc' },
  });

  return (
    <>
      <Nav user={{ id: user.id, email: user.email, name: user.name, plan: user.plan }} />

      <main className="max-w-[1240px] mx-auto px-6 sm:px-12 relative z-[2]">
        <div className="my-12 pb-7 border-b border-rule flex justify-between items-end flex-wrap gap-5">
          <div>
            <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-3.5 inline-flex items-center gap-2.5">
              <span className="w-6 h-px bg-ink-mute" />Studio
            </div>
            <h1 className="font-serif font-normal text-[clamp(36px,5vw,52px)] tracking-[-0.025em] leading-[1.05]">
              Your <em className="not-italic italic text-amber">résumés</em>.
            </h1>
            <div className="text-ink-soft text-[15px] mt-1.5">
              Welcome back, {user.name ?? user.email.split('@')[0]}.
              {resumes.length === 0 && " Let's start your first one."}
            </div>
          </div>
          <Link href="/builder" className="btn btn-amber">+ New résumé</Link>
        </div>

        {resumes.length === 0 ? (
          <div className="bg-paper border border-dashed border-rule rounded-2xl text-center py-20 px-7 mb-16">
            <div className="font-serif italic text-[56px] text-amber leading-none mb-3">i.</div>
            <h2 className="font-serif text-[28px] tracking-[-0.02em] mb-2">No résumés yet.</h2>
            <p className="text-ink-soft max-w-[380px] mx-auto mb-5">
              Pick a template and we'll save your progress automatically as you edit.
            </p>
            <Link href="/builder" className="btn btn-amber">Choose a template</Link>
          </div>
        ) : (
          <div className="grid grid-cols-[repeat(auto-fill,minmax(260px,1fr))] gap-5 mb-16">
            {resumes.map((r) => {
              const t = TEMPLATES[r.templateId] ?? TEMPLATES.broadsheet;
              const Comp = t.Component;
              return (
                <div
                  key={r.id}
                  className="bg-paper border border-rule rounded-xl p-4 transition-all hover:-translate-y-0.5 hover:border-ink hover:shadow-soft"
                >
                  <Link
                    href={`/builder/${r.id}`}
                    className="block aspect-[8.5/11] bg-cream-2 border border-rule rounded-md mb-3.5 overflow-hidden relative"
                  >
                    <div style={{ transform: 'scale(0.42)', transformOrigin: 'top left', width: '100%', pointerEvents: 'none' }}>
                      <Comp data={r.data as unknown as ResumeData} />
                    </div>
                    <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to bottom, transparent 60%, rgba(244,237,224,.65))' }} />
                  </Link>
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="font-serif text-[17px] font-medium tracking-[-0.01em] flex-1 overflow-hidden text-ellipsis whitespace-nowrap">
                      {r.title || 'Untitled résumé'}
                    </h3>
                    <span className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-ink-mute">
                      {t.tag}
                    </span>
                  </div>
                  <div className="font-mono text-[10.5px] text-ink-mute mb-3">
                    Updated {fmtAgo(r.updatedAt)}
                  </div>
                  <DashboardActions resumeId={r.id} />
                </div>
              );
            })}
          </div>
        )}
      </main>

      <footer className="relative z-[2] border-t border-rule bg-cream-2 py-10 mt-16">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 flex justify-between items-center text-[13px] text-ink-mute flex-wrap gap-3">
          <span>© 2026 Folio Studio Inc.</span>
          <span className="font-mono">v1.0 · pro</span>
        </div>
      </footer>
    </>
  );
}
