'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function DashboardActions({ resumeId }: { resumeId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function duplicate() {
    setBusy(true);
    try {
      const r = await fetch(`/api/resumes/${resumeId}`);
      const j = await r.json();
      if (!j.resume) throw new Error('Could not load résumé');
      const r2 = await fetch('/api/resumes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: (j.resume.title ?? 'Untitled') + ' (copy)',
          templateId: j.resume.templateId,
          data: j.resume.data,
        }),
      });
      if (!r2.ok) throw new Error('Duplicate failed');
      router.refresh();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!confirm('Delete this résumé? This cannot be undone.')) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/resumes/${resumeId}`, { method: 'DELETE' });
      if (!r.ok) throw new Error('Delete failed');
      router.refresh();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex gap-1.5 flex-wrap">
      <button
        onClick={() => router.push(`/builder/${resumeId}`)}
        className="btn btn-outline px-3 py-1.5 text-xs"
        disabled={busy}
      >
        Edit
      </button>
      <button
        onClick={duplicate}
        className="btn btn-outline px-3 py-1.5 text-xs"
        disabled={busy}
      >
        Duplicate
      </button>
      <button
        onClick={remove}
        className="btn px-3 py-1.5 text-xs text-brick border border-brick/30 hover:bg-brick hover:text-paper"
        disabled={busy}
      >
        Delete
      </button>
    </div>
  );
}
