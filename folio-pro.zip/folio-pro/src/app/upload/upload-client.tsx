'use client';

import { useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import type { ResumeData } from '@/lib/resume-types';

type ImprovementsResult = {
  weakBullets: {
    expIndex: number;
    bulletIndex: number;
    original: string;
    reason: string;
    suggested: string;
  }[];
  missingSkills: string[];
  formattingIssues: string[];
  overallScore: number;
};

type Stage = 'idle' | 'uploading' | 'parsing' | 'auditing' | 'review' | 'error';

type ParseResponse = {
  resumeId: string;
  parsed: ResumeData;
  meta: { filename: string; kind: 'pdf' | 'docx'; bytes: number };
};

export function UploadClient() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [stage, setStage] = useState<Stage>('idle');
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [parsed, setParsed] = useState<ParseResponse | null>(null);
  const [improvements, setImprovements] = useState<ImprovementsResult | null>(null);

  async function handleFile(file: File) {
    if (!file) return;
    setError(null);
    setStage('uploading');

    const fd = new FormData();
    fd.append('file', file);

    try {
      setStage('parsing');
      const res = await fetch('/api/upload/parse', { method: 'POST', body: fd });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? 'Parse failed');

      setParsed(json as ParseResponse);

      // Kick off improvements pass in parallel — non-blocking for the UI
      setStage('auditing');
      runImprovements(json.parsed).then((imp) => setImprovements(imp));
      setStage('review');
    } catch (e: any) {
      setError(e.message);
      setStage('error');
    }
  }

  async function runImprovements(data: ResumeData): Promise<ImprovementsResult | null> {
    try {
      const r = await fetch('/api/ai/improvements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data }),
      });
      const j = await r.json();
      if (!r.ok) return null;
      return j.improvements;
    } catch {
      return null;
    }
  }

  function reset() {
    setStage('idle');
    setError(null);
    setParsed(null);
    setImprovements(null);
  }

  // ============ STAGE: idle (drop zone) ============
  if (stage === 'idle' || stage === 'error') {
    return (
      <main className="max-w-[860px] mx-auto px-6 sm:px-12 py-12 relative z-[2]">
        <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-3.5 inline-flex items-center gap-2.5">
          <span className="w-6 h-px bg-ink-mute" />Path A · Upload
        </div>
        <h1 className="font-serif text-[clamp(36px,5vw,52px)] tracking-[-0.025em] leading-[1.05] mb-3">
          Improve a résumé you <em className="not-italic italic text-amber">already have</em>.
        </h1>
        <p className="text-ink-soft text-[16px] mb-8 max-w-[600px]">
          Drop in your existing résumé. Folio's AI parses it into editable form, flags weak bullets, suggests missing skills, and points out formatting issues.
        </p>

        {error && (
          <div className="bg-brick/[0.08] border border-brick/30 text-brick p-3.5 rounded-lg text-[13.5px] mb-5 font-mono">
            {error}
          </div>
        )}

        <label
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) handleFile(f);
          }}
          className={`block bg-paper border-2 border-dashed rounded-2xl p-12 sm:p-16 text-center cursor-pointer transition-all ${
            dragOver ? 'border-amber bg-amber/[0.04]' : 'border-rule hover:border-ink hover:bg-paper-2'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
          <div className="font-serif italic text-[64px] text-amber leading-none mb-4">↓</div>
          <h2 className="font-serif text-[26px] tracking-[-0.02em] mb-2">
            Drop a <em className="not-italic italic text-amber">PDF</em> or <em className="not-italic italic text-amber">DOCX</em>.
          </h2>
          <p className="text-ink-soft text-[14.5px] max-w-[420px] mx-auto mb-5">
            Or click to browse. Up to 4 MB. Your file is read on the server and discarded — only the parsed text is saved.
          </p>
          <span className="btn btn-amber pointer-events-none">Choose file</span>
        </label>

        <div className="grid sm:grid-cols-3 gap-3 mt-8 text-[13px] text-ink-soft">
          {[
            { n: 'i.', t: 'Parse', d: 'AI extracts every section into editable fields.' },
            { n: 'ii.', t: 'Audit', d: 'Flags weak bullets, missing skills, and formatting issues.' },
            { n: 'iii.', t: 'Edit', d: 'Open in any of our templates and refine.' },
          ].map((s) => (
            <div key={s.n} className="bg-cream-2 border border-rule rounded-xl p-4">
              <div className="font-serif italic text-amber text-[20px] mb-1">{s.n}</div>
              <div className="font-medium mb-0.5">{s.t}</div>
              <div className="text-[12.5px] text-ink-mute leading-snug">{s.d}</div>
            </div>
          ))}
        </div>
      </main>
    );
  }

  // ============ STAGES: uploading | parsing | auditing ============
  if (stage === 'uploading' || stage === 'parsing' || stage === 'auditing') {
    const messages: Record<typeof stage, { title: string; sub: string }> = {
      uploading: { title: 'Uploading your file…', sub: 'almost done' },
      parsing:   { title: 'Reading the document…', sub: 'AI is extracting structure — usually 5–10 seconds' },
      auditing:  { title: 'Auditing for improvements…', sub: 'flagging weak bullets and missing skills' },
    };
    const m = messages[stage];
    return (
      <main className="max-w-[600px] mx-auto px-6 py-24 relative z-[2] text-center">
        <div className="font-serif italic text-[60px] text-amber mb-5 animate-pulse">✦</div>
        <h2 className="font-serif text-[28px] tracking-[-0.02em] mb-2">{m.title}</h2>
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">{m.sub}</p>
      </main>
    );
  }

  // ============ STAGE: review ============
  if (stage === 'review' && parsed) {
    return (
      <main className="max-w-[1240px] mx-auto px-6 sm:px-12 py-10 relative z-[2]">
        <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-3.5 inline-flex items-center gap-2.5">
          <span className="w-6 h-px bg-ink-mute" />Parsed successfully
        </div>
        <h1 className="font-serif text-[clamp(32px,4.5vw,46px)] tracking-[-0.025em] leading-[1.05] mb-3">
          Here's what we <em className="not-italic italic text-amber">extracted</em>.
        </h1>
        <p className="text-ink-soft text-[15.5px] mb-8 max-w-[640px]">
          Review what was parsed from <span className="font-mono text-[13px] text-ink">{parsed.meta.filename}</span>. Open in the editor when you're ready — you can edit anything there.
        </p>

        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6 mb-8">
          {/* LEFT — parsed data preview */}
          <div className="bg-paper border border-rule rounded-2xl p-6">
            <div className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute mb-4">
              Parsed sections
            </div>
            <ParsedSummary data={parsed.parsed} />
          </div>

          {/* RIGHT — improvements */}
          <div className="space-y-4">
            <div className="bg-paper border border-rule rounded-2xl p-6">
              <div className="flex items-baseline justify-between mb-4">
                <div className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute">
                  AI audit
                </div>
                {improvements && (
                  <div className="font-serif text-[28px] font-medium tracking-[-0.03em] leading-none" style={{ color: scoreColor(improvements.overallScore) }}>
                    {improvements.overallScore}<span className="text-[18px] text-ink-mute">/100</span>
                  </div>
                )}
              </div>

              {!improvements ? (
                <div className="text-[13px] text-ink-mute font-mono uppercase tracking-[0.06em] py-3">
                  ✦ analyzing…
                </div>
              ) : (
                <>
                  {improvements.formattingIssues.length > 0 && (
                    <div className="mb-4">
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-amber mb-2">
                        Formatting
                      </div>
                      <ul className="text-[13px] space-y-1.5 list-disc pl-5 marker:text-amber leading-snug">
                        {improvements.formattingIssues.map((x, i) => (
                          <li key={i}>{x}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {improvements.missingSkills.length > 0 && (
                    <div className="mb-4">
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-amber mb-2">
                        Skills you might be missing
                      </div>
                      <div className="text-[13px] leading-relaxed">
                        {improvements.missingSkills.join(' · ')}
                      </div>
                    </div>
                  )}

                  {improvements.weakBullets.length > 0 && (
                    <div>
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-amber mb-2">
                        Weak bullets ({improvements.weakBullets.length})
                      </div>
                      <div className="space-y-3">
                        {improvements.weakBullets.map((wb, i) => (
                          <div key={i} className="bg-cream-2 border border-rule rounded-md p-3">
                            <div className="font-mono text-[10px] uppercase tracking-[0.1em] text-brick mb-1.5">
                              ⚠ {wb.reason}
                            </div>
                            <div className="text-[12.5px] text-ink-mute italic mb-1.5 line-through opacity-70">
                              "{wb.original}"
                            </div>
                            <div className="text-[12.5px] text-ink leading-snug">
                              <span className="text-moss font-mono text-[10px] uppercase tracking-[0.1em] mr-1.5">try:</span>
                              {wb.suggested}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {improvements.formattingIssues.length === 0 &&
                   improvements.missingSkills.length === 0 &&
                   improvements.weakBullets.length === 0 && (
                    <div className="text-[14px] text-moss font-serif italic">
                      ✓ No major issues found. Nice résumé.
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 flex-wrap items-center pb-12">
          <button
            onClick={() => router.push(`/builder/${parsed.resumeId}`)}
            className="btn btn-amber"
          >
            Open in editor →
          </button>
          <button onClick={reset} className="btn btn-outline">
            Upload a different file
          </button>
          <Link href="/dashboard" className="btn btn-ghost">
            Skip — see all my résumés
          </Link>
        </div>
      </main>
    );
  }

  return null;
}

function scoreColor(score: number) {
  if (score >= 80) return '#3D5240'; // moss
  if (score >= 60) return '#C44A1A'; // amber
  return '#8E3320';                  // brick
}

function ParsedSummary({ data }: { data: ResumeData }) {
  const has = (s: string | undefined | null) => Boolean(s && s.trim().length);
  return (
    <div className="space-y-4 text-[13.5px]">
      <div>
        <div className="font-serif text-[20px] font-medium tracking-[-0.015em]">
          {data.name || <span className="text-ink-mute italic">No name detected</span>}
        </div>
        {has(data.title) && <div className="text-ink-soft">{data.title}</div>}
        <div className="text-ink-mute text-[12px] mt-1 font-mono">
          {[data.email, data.phone, data.location].filter(has).join(' · ') || '—'}
        </div>
      </div>

      {has(data.summary) && (
        <Block label="Summary">
          <p className="font-serif italic text-[13.5px] leading-relaxed">{data.summary}</p>
        </Block>
      )}

      <Block label={`Experience (${data.experience.length})`}>
        {data.experience.length === 0 ? (
          <span className="text-ink-mute italic text-[12.5px]">None detected</span>
        ) : (
          <ul className="space-y-2">
            {data.experience.slice(0, 4).map((x, i) => (
              <li key={i}>
                <div className="font-medium">{x.title} <span className="text-ink-mute font-normal">— {x.company}</span></div>
                <div className="text-[11.5px] text-ink-mute font-mono">
                  {[x.start, x.end].filter(Boolean).join(' — ')}
                  {x.bullets.length > 0 && ` · ${x.bullets.length} bullet${x.bullets.length === 1 ? '' : 's'}`}
                </div>
              </li>
            ))}
            {data.experience.length > 4 && (
              <li className="text-[12px] text-ink-mute italic">+ {data.experience.length - 4} more</li>
            )}
          </ul>
        )}
      </Block>

      <Block label={`Education (${data.education.length})`}>
        {data.education.length === 0 ? (
          <span className="text-ink-mute italic text-[12.5px]">None detected</span>
        ) : (
          <ul className="space-y-1">
            {data.education.map((e, i) => (
              <li key={i}>
                <span className="font-medium">{e.degree}</span>
                {e.school && <span className="text-ink-mute"> — {e.school}</span>}
              </li>
            ))}
          </ul>
        )}
      </Block>

      <Block label={`Skills (${data.skills.length})`}>
        {data.skills.length === 0 ? (
          <span className="text-ink-mute italic text-[12.5px]">None detected</span>
        ) : (
          <div className="text-[12.5px] leading-relaxed">{data.skills.join(' · ')}</div>
        )}
      </Block>

      {(data.projects?.length ?? 0) > 0 && (
        <Block label={`Projects (${data.projects?.length})`}>
          <ul className="space-y-1">
            {data.projects?.map((p, i) => (
              <li key={i}><span className="font-medium">{p.name}</span></li>
            ))}
          </ul>
        </Block>
      )}

      {(data.certifications?.length ?? 0) > 0 && (
        <Block label={`Certifications (${data.certifications?.length})`}>
          <ul className="space-y-1">
            {data.certifications?.map((c, i) => (
              <li key={i}><span className="font-medium">{c.name}</span> <span className="text-ink-mute">— {c.issuer}</span></li>
            ))}
          </ul>
        </Block>
      )}
    </div>
  );
}

function Block({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="border-t border-rule-soft pt-3">
      <div className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-mute mb-1.5">
        {label}
      </div>
      {children}
    </div>
  );
}
