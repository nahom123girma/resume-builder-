import { redirect } from 'next/navigation';
import { Nav } from '@/components/nav';
import { getCurrentUser } from '@/lib/auth';
import { UploadClient } from './upload-client';

export default async function UploadPage() {
  const user = await getCurrentUser();
  // Auth required — they're going to save a résumé to their account
  if (!user) {
    redirect('/signup?next=/upload');
  }
  return (
    <>
      <Nav user={{ id: user.id, email: user.email, name: user.name, plan: user.plan }} />
      <UploadClient />
    </>
  );
}
