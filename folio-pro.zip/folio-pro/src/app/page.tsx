import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';

export default async function HomePage() {
  const user = await getCurrentUser();

  return (
    <>
      {/* NAV */}
      <nav className="sticky top-0 z-50 backdrop-blur-md bg-cream/80 border-b border-rule">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 py-4 flex items-center justify-between">
          <Link href="/" className="font-serif text-[26px] font-semibold tracking-tight flex items-baseline gap-1.5">
            Folio<span className="w-[7px] h-[7px] rounded-full bg-amber inline-block self-center ml-0.5" />
          </Link>
          <div className="hidden md:flex gap-8 text-sm text-ink-soft">
            <Link href="/upload" className="hover:text-ink">Upload</Link>
            <Link href="/match" className="hover:text-ink">Match</Link>
            <Link href="/builder" className="hover:text-ink">Build</Link>
          </div>
          <div className="flex items-center gap-3">
            {user ? (
              <>
                <Link href="/dashboard" className="btn btn-ghost">My résumés</Link>
                <Link href="/builder" className="btn btn-primary">+ New</Link>
              </>
            ) : (
              <>
                <Link href="/login" className="btn btn-ghost">Log in</Link>
                <Link href="/signup" className="btn btn-primary">Get started</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative z-[2] py-16 sm:py-24 text-center max-w-[1240px] mx-auto px-6 sm:px-12">
        <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-6 inline-flex items-center gap-2.5">
          <span className="w-6 h-px bg-ink-mute" />
          The career &amp; document studio
          <span className="w-6 h-px bg-ink-mute" />
        </div>
        <h1 className="font-serif text-[clamp(44px,6.5vw,82px)] leading-[0.98] tracking-[-0.035em] mb-6 max-w-[880px] mx-auto">
          Three ways to get<br />
          <em className="not-italic font-serif italic text-amber">interview-ready</em>.
        </h1>
        <p className="text-[17px] leading-[1.55] text-ink-soft max-w-[560px] mx-auto mb-12">
          Upload an existing résumé to improve it. Match yours against a job description for honest fit analysis. Or build a new one from scratch with AI assistance at every step.
        </p>
      </section>

      {/* THREE PATHWAYS */}
      <section className="relative z-[2] max-w-[1240px] mx-auto px-6 sm:px-12 pb-24">
        <div className="grid md:grid-cols-3 gap-5">
          {/* A — UPLOAD */}
          <Link
            href="/upload"
            className="group bg-paper border border-rule rounded-2xl p-7 transition-all hover:-translate-y-1 hover:border-ink hover:shadow-soft block"
          >
            <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-ink inline-block" />
              Path A · Upload
            </div>
            <h3 className="font-serif text-[26px] font-medium leading-[1.1] tracking-[-0.015em] mb-3">
              Improve a résumé you <em className="not-italic italic text-amber">already have</em>.
            </h3>
            <p className="text-[14px] text-ink-soft leading-[1.5] mb-5">
              Drop a PDF or DOCX. AI parses it into editable form, flags weak bullets, suggests missing skills, and reformats with any of our templates.
            </p>
            <div className="font-mono text-[11px] uppercase tracking-[0.1em] text-amber group-hover:gap-3 inline-flex items-center gap-2 transition-all">
              Upload résumé →
            </div>
          </Link>

          {/* B — MATCH */}
          <Link
            href="/match"
            className="group bg-paper border border-rule rounded-2xl p-7 transition-all hover:-translate-y-1 hover:border-ink hover:shadow-soft block"
          >
            <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber inline-block" />
              Path B · Match
            </div>
            <h3 className="font-serif text-[26px] font-medium leading-[1.1] tracking-[-0.015em] mb-3">
              Match against a <em className="not-italic italic text-amber">job description</em>.
            </h3>
            <p className="text-[14px] text-ink-soft leading-[1.5] mb-5">
              Paste a JD. Get an honest fit score, missing skills, keyword overlap, and specific suggestions for what to add, remove, or rewrite.
            </p>
            <div className="font-mono text-[11px] uppercase tracking-[0.1em] text-amber group-hover:gap-3 inline-flex items-center gap-2 transition-all">
              Match a job →
            </div>
          </Link>

          {/* C — CREATE */}
          <Link
            href="/builder"
            className="group bg-paper border border-rule rounded-2xl p-7 transition-all hover:-translate-y-1 hover:border-ink hover:shadow-soft block"
          >
            <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-moss inline-block" />
              Path C · Create
            </div>
            <h3 className="font-serif text-[26px] font-medium leading-[1.1] tracking-[-0.015em] mb-3">
              Build a new résumé <em className="not-italic italic text-amber">from scratch</em>.
            </h3>
            <p className="text-[14px] text-ink-soft leading-[1.5] mb-5">
              Pick a typeset template. Step-by-step wizard for personal info, experience, education, skills, projects, certifications. AI assistance at every step.
            </p>
            <div className="font-mono text-[11px] uppercase tracking-[0.1em] text-amber group-hover:gap-3 inline-flex items-center gap-2 transition-all">
              Start building →
            </div>
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-[2] border-t border-rule bg-cream-2 py-10 mt-12">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 flex justify-between items-center text-[13px] text-ink-mute flex-wrap gap-3">
          <span>© 2026 Folio Studio Inc. Designed in Brooklyn. Typeset everywhere.</span>
          <span className="font-mono">v1.0 · pro build</span>
        </div>
      </footer>
    </>
  );
}
