import { Nav } from '@/components/nav';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { MatchClient } from './match-client';
import type { ResumeData } from '@/lib/resume-types';

export default async function MatchPage() {
  const user = await getCurrentUser();
  const resumes = user
    ? await db.resume.findMany({
        where: { userId: user.id },
        select: { id: true, title: true, data: true, templateId: true },
        orderBy: { updatedAt: 'desc' },
      })
    : [];

  return (
    <>
      <Nav user={user ? { id: user.id, email: user.email, name: user.name, plan: user.plan } : null} />
      <MatchClient
        loggedIn={!!user}
        resumes={resumes.map((r) => ({
          id: r.id,
          title: r.title,
          data: r.data as unknown as ResumeData,
        }))}
      />
    </>
  );
}
