'use client';

import { useState } from 'react';
import Link from 'next/link';
import type { ResumeData } from '@/lib/resume-types';

type MatchResult = {
  matchScore: number;
  atsScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  keywordOverlap: { resume: string[]; jd: string[]; common: string[] };
  improvements: { add: string[]; remove: string[]; rewrite: string[] };
  summary: string;
};

type SavedResume = { id: string; title: string; data: ResumeData };

export function MatchClient({
  loggedIn,
  resumes,
}: {
  loggedIn: boolean;
  resumes: SavedResume[];
}) {
  const [selectedId, setSelectedId] = useState<string>(resumes[0]?.id ?? '');
  const [jd, setJd] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const selected = resumes.find((r) => r.id === selectedId);

  async function analyze() {
    if (!selected) return;
    if (jd.length < 40) {
      setErr('Paste a longer job description (40+ characters).');
      return;
    }
    setErr(null);
    setBusy(true);
    setResult(null);
    try {
      const r = await fetch('/api/ai/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resume: selected.data, jobDescription: jd }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? 'Analysis failed');
      setResult(j.analysis);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="max-w-[1100px] mx-auto px-6 sm:px-12 py-12 relative z-[2]">
      <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-3.5 inline-flex items-center gap-2.5">
        <span className="w-6 h-px bg-ink-mute" />Path B · Match
      </div>
      <h1 className="font-serif text-[clamp(36px,5vw,52px)] tracking-[-0.025em] leading-[1.05] mb-3">
        Match against a <em className="not-italic italic text-amber">job description</em>.
      </h1>
      <p className="text-ink-soft text-[16px] mb-8 max-w-[600px]">
        Pick one of your résumés. Paste the job description. Get a fit score, missing skills, keyword overlap, and specific improvements.
      </p>

      {!loggedIn ? (
        <div className="bg-paper border border-rule rounded-2xl p-9 text-center">
          <h2 className="font-serif text-[24px] tracking-[-0.02em] mb-2">
            Sign in to <em className="not-italic italic text-amber">match</em>.
          </h2>
          <p className="text-ink-soft mb-4">You'll need a saved résumé to match against a job.</p>
          <div className="flex gap-2 justify-center">
            <Link href="/signup?next=/match" className="btn btn-amber">Sign up free</Link>
            <Link href="/login?next=/match" className="btn btn-outline">Log in</Link>
          </div>
        </div>
      ) : resumes.length === 0 ? (
        <div className="bg-paper border border-rule rounded-2xl p-9 text-center">
          <h2 className="font-serif text-[24px] tracking-[-0.02em] mb-2">No résumés yet.</h2>
          <p className="text-ink-soft mb-4">Build a résumé first, then come back to match it.</p>
          <Link href="/builder" className="btn btn-amber">Choose a template</Link>
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Inputs */}
          <div className="bg-paper border border-rule rounded-2xl p-6">
            <div className="field">
              <label>Résumé</label>
              <select
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                className="bg-cream-2 border border-rule rounded-md px-3 py-2.5 text-[14px]"
              >
                {resumes.map((r) => (
                  <option key={r.id} value={r.id}>{r.title}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Job description</label>
              <textarea
                rows={14}
                placeholder="Paste the full job posting here…"
                value={jd}
                onChange={(e) => setJd(e.target.value)}
              />
            </div>
            {err && <div className="text-brick text-[13px] font-mono mb-3">{err}</div>}
            <button
              onClick={analyze}
              disabled={busy || !selected || jd.length < 40}
              className="btn btn-amber w-full justify-center py-3"
            >
              {busy ? '✦ Analyzing…' : '✦ Analyze fit'}
            </button>
            <div className="mt-3 font-mono text-[10.5px] text-ink-mute uppercase tracking-[0.06em] text-center">
              Powered by Claude Sonnet 4.6 · ~5 second analysis
            </div>
          </div>

          {/* Results */}
          <div className="space-y-4">
            {!result && !busy && (
              <div className="bg-cream-2 border border-dashed border-rule rounded-2xl p-9 text-center text-ink-mute">
                <div className="font-serif italic text-[44px] text-amber leading-none mb-3">↑</div>
                Results appear here once you analyze.
              </div>
            )}
            {busy && (
              <div className="bg-cream-2 border border-rule rounded-2xl p-9 text-center text-ink-soft">
                <div className="font-serif italic text-[20px] mb-2">Reading both documents…</div>
                <div className="font-mono text-[11px] uppercase tracking-[0.12em] text-ink-mute">
                  this usually takes 3–6 seconds
                </div>
              </div>
            )}
            {result && (
              <>
                {/* Scores */}
                <div className="bg-paper border border-rule rounded-2xl p-6">
                  <div className="grid grid-cols-2 gap-6 mb-4">
                    <ScoreBox label="Match" score={result.matchScore} />
                    <ScoreBox label="ATS" score={result.atsScore} />
                  </div>
                  <p className="font-serif italic text-[15px] text-ink-soft border-l-2 border-amber pl-3.5">
                    {result.summary}
                  </p>
                </div>

                {/* Skills */}
                <div className="bg-paper border border-rule rounded-2xl p-6">
                  <h3 className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute mb-3">
                    Skills
                  </h3>
                  <div className="text-[13px] mb-3">
                    <strong className="text-moss">✓ Matched:</strong>{' '}
                    {result.matchedSkills.length > 0 ? result.matchedSkills.join(' · ') : 'none'}
                  </div>
                  <div className="text-[13px]">
                    <strong className="text-brick">⚠ Missing:</strong>{' '}
                    {result.missingSkills.length > 0 ? result.missingSkills.join(' · ') : 'none — strong fit'}
                  </div>
                </div>

                {/* Improvements */}
                <div className="bg-paper border border-rule rounded-2xl p-6">
                  <h3 className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute mb-3">
                    Improvements
                  </h3>
                  {result.improvements.add.length > 0 && (
                    <div className="mb-3.5">
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-amber mb-1.5">
                        Add
                      </div>
                      <ul className="text-[13px] space-y-1 list-disc pl-5 marker:text-amber">
                        {result.improvements.add.map((x, i) => <li key={i}>{x}</li>)}
                      </ul>
                    </div>
                  )}
                  {result.improvements.rewrite.length > 0 && (
                    <div className="mb-3.5">
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-amber mb-1.5">
                        Rewrite
                      </div>
                      <ul className="text-[13px] space-y-1 list-disc pl-5 marker:text-amber">
                        {result.improvements.rewrite.map((x, i) => <li key={i}>{x}</li>)}
                      </ul>
                    </div>
                  )}
                  {result.improvements.remove.length > 0 && (
                    <div>
                      <div className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-brick mb-1.5">
                        Remove or de-emphasize
                      </div>
                      <ul className="text-[13px] space-y-1 list-disc pl-5 marker:text-brick">
                        {result.improvements.remove.map((x, i) => <li key={i}>{x}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </main>
  );
}

function ScoreBox({ label, score }: { label: string; score: number }) {
  const color = score >= 80 ? '#3D5240' : score >= 60 ? '#C44A1A' : '#8E3320';
  return (
    <div className="text-center">
      <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-mute mb-1">
        {label}
      </div>
      <div className="font-serif text-[56px] font-medium tracking-[-0.04em] leading-none" style={{ color }}>
        {score}
        <span className="text-[28px] text-ink-mute">%</span>
      </div>
    </div>
  );
}
