'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get('next') ?? '/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const r = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? 'Login failed');
      router.push(next);
      router.refresh();
    } catch (e: any) {
      setErr(e.message);
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen grid place-items-center px-5 py-10 relative z-[2]">
      <div className="w-full max-w-[440px] bg-paper border border-rule rounded-2xl p-9 shadow-soft">
        <Link href="/" className="font-serif text-2xl font-semibold tracking-tight flex items-baseline gap-1.5 mb-7">
          Folio<span className="w-1.5 h-1.5 rounded-full bg-amber inline-block self-center ml-0.5" />
        </Link>

        <h1 className="font-serif text-[30px] tracking-[-0.025em] leading-[1.05] mb-2">
          Welcome <em className="not-italic italic text-amber">back</em>.
        </h1>
        <p className="text-ink-soft text-[14.5px] mb-6">
          Log in to pick up where you left off.
        </p>

        {err && (
          <div className="bg-brick/[0.08] border border-brick/25 text-brick p-2.5 rounded-md text-[13px] mb-3.5 font-mono">
            {err}
          </div>
        )}

        <form onSubmit={submit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="btn btn-amber w-full justify-center py-3.5"
          >
            {busy ? 'Logging in…' : 'Log in'}
          </button>
        </form>

        <div className="mt-4 text-[13px] text-ink-mute text-center">
          No account?{' '}
          <Link href="/signup" className="text-amber border-b border-amber">
            Sign up free
          </Link>
        </div>

        <Link
          href="/"
          className="inline-block mt-7 text-[12px] text-ink-mute font-mono uppercase tracking-[0.06em] hover:text-ink"
        >
          ← back to home
        </Link>
      </div>
    </main>
  );
}
