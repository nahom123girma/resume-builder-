import { notFound, redirect } from 'next/navigation';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { Editor } from '@/components/editor';
import { Nav } from '@/components/nav';
import type { ResumeData } from '@/lib/resume-types';

type P = { params: Promise<{ id: string }> };

export default async function BuilderEditPage({ params }: P) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) {
    redirect(`/login?next=${encodeURIComponent(`/builder/${id}`)}`);
  }
  const resume = await db.resume.findFirst({
    where: { id, userId: user.id },
  });
  if (!resume) notFound();

  return (
    <>
      <Nav user={{ id: user.id, email: user.email, name: user.name, plan: user.plan }} />
      <Editor
        initialId={resume.id}
        initial={{
          id: resume.id,
          title: resume.title,
          templateId: resume.templateId,
          data: resume.data as unknown as ResumeData,
        }}
      />
    </>
  );
}
