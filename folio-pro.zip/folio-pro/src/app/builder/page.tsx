import Link from 'next/link';
import { redirect } from 'next/navigation';
import { Nav } from '@/components/nav';
import { TEMPLATES } from '@/components/templates';
import { SAMPLE_RESUME, EMPTY_RESUME } from '@/lib/resume-types';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { TemplatePickerCard } from './picker-card';

type SP = { searchParams: Promise<{ template?: string }> };

export default async function BuilderPickerPage({ searchParams }: SP) {
  const sp = await searchParams;
  const user = await getCurrentUser();

  // If they hit /builder?template=xxx, jump straight into a new resume with that template.
  if (sp.template && TEMPLATES[sp.template]) {
    if (!user) {
      redirect(`/signup?next=${encodeURIComponent(`/builder?template=${sp.template}`)}`);
    }
    const r = await db.resume.create({
      data: {
        userId: user.id,
        title: 'Untitled résumé',
        templateId: sp.template,
        data: SAMPLE_RESUME as any,
      },
    });
    redirect(`/builder/${r.id}`);
  }

  return (
    <>
      <Nav user={user ? { id: user.id, email: user.email, name: user.name, plan: user.plan } : null} />

      <main className="max-w-[1240px] mx-auto px-6 sm:px-12 relative z-[2]">
        <div className="text-center my-12">
          <div className="font-mono text-xs uppercase tracking-[0.14em] text-ink-mute mb-3.5 inline-flex items-center gap-2.5">
            <span className="w-6 h-px bg-ink-mute" />Step 01 · Pick a template
          </div>
          <h1 className="font-serif font-normal text-[clamp(36px,5vw,56px)] tracking-[-0.025em] leading-[1.05] mb-2.5">
            Choose your <em className="not-italic italic text-amber">starting point</em>.
          </h1>
          <p className="text-ink-soft max-w-[540px] mx-auto">
            Five typeset templates today; eighteen by the end of this build. All ATS-clean. Click any to start.
          </p>
        </div>

        <div className="grid grid-cols-[repeat(auto-fill,minmax(240px,1fr))] gap-6 mb-16">
          {Object.values(TEMPLATES).map((t) => (
            <TemplatePickerCard key={t.id} template={t} sample={SAMPLE_RESUME} />
          ))}
        </div>
      </main>

      <footer className="relative z-[2] border-t border-rule bg-cream-2 py-10">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 flex justify-between items-center text-[13px] text-ink-mute flex-wrap gap-3">
          <span>© 2026 Folio Studio Inc.</span>
          <span className="font-mono">v1.0 · pro</span>
        </div>
      </footer>
    </>
  );
}
