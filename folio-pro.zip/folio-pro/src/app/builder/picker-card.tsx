'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import type { TemplateMeta } from '@/components/templates';
import type { ResumeData } from '@/lib/resume-types';

export function TemplatePickerCard({
  template,
  sample,
}: {
  template: TemplateMeta;
  sample: ResumeData;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const Comp = template.Component;

  async function pick() {
    setBusy(true);
    try {
      const r = await fetch('/api/resumes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'Untitled résumé',
          templateId: template.id,
          data: sample,
        }),
      });
      if (r.status === 401) {
        // Not logged in — redirect them to signup, then come back
        router.push(`/signup?next=${encodeURIComponent(`/builder?template=${template.id}`)}`);
        return;
      }
      const j = await r.json();
      if (j.resume?.id) {
        router.push(`/builder/${j.resume.id}`);
      } else {
        throw new Error(j.error ?? 'Could not create résumé');
      }
    } catch (e: any) {
      alert(e.message);
      setBusy(false);
    }
  }

  return (
    <button
      onClick={pick}
      disabled={busy}
      className="text-left transition-transform hover:-translate-y-1 disabled:opacity-60 disabled:cursor-wait group"
    >
      <div className="aspect-[8.5/11] bg-paper border border-rule rounded-lg overflow-hidden shadow-soft group-hover:shadow-soft-lg group-hover:border-ink transition-all mb-3.5">
        <div style={{ transform: 'scale(0.4)', transformOrigin: 'top left', width: '100%', pointerEvents: 'none' }}>
          <Comp data={sample} />
        </div>
      </div>
      <div className="flex justify-between items-baseline mb-1">
        <span className="font-serif text-[17px] font-medium tracking-[-0.01em]">
          {template.name}
        </span>
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">
          {template.tag}
        </span>
      </div>
      <div className="text-[13px] text-ink-soft leading-snug">{template.desc}</div>
    </button>
  );
}
