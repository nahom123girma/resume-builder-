'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { TEMPLATES } from './templates';
import type { ResumeData, ExperienceItem, EducationItem } from '@/lib/resume-types';
import { EMPTY_RESUME, SAMPLE_RESUME } from '@/lib/resume-types';

type Resume = {
  id?: string;
  title: string;
  templateId: string;
  data: ResumeData;
};

export function Editor({
  initial,
  initialId,
}: {
  initial: Resume;
  initialId?: string;
}) {
  const router = useRouter();
  const [resume, setResume] = useState<Resume>(initial);
  const [resumeId, setResumeId] = useState<string | undefined>(initialId);
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'dirty'>('saved');
  const [aiBusy, setAiBusy] = useState<string | null>(null);

  const saveTimer = useRef<NodeJS.Timeout | null>(null);
  const justMounted = useRef(true);

  // Auto-save: every change schedules a save 700ms after the last keystroke
  useEffect(() => {
    if (justMounted.current) {
      justMounted.current = false;
      return;
    }
    setSaveState('dirty');
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(persist, 700);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resume]);

  async function persist() {
    setSaveState('saving');
    try {
      if (resumeId) {
        await fetch(`/api/resumes/${resumeId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: resume.title,
            templateId: resume.templateId,
            data: resume.data,
          }),
        });
      } else {
        const r = await fetch('/api/resumes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: resume.title,
            templateId: resume.templateId,
            data: resume.data,
          }),
        });
        const j = await r.json();
        if (j.resume?.id) {
          setResumeId(j.resume.id);
          // Replace URL with the new ID without a full navigation
          window.history.replaceState(null, '', `/builder/${j.resume.id}`);
        }
      }
      setSaveState('saved');
    } catch {
      setSaveState('dirty');
    }
  }

  function setData(updater: (d: ResumeData) => ResumeData) {
    setResume((r) => ({ ...r, data: updater(r.data) }));
  }

  // ============ AI HELPERS ============
  async function aiGenerateSummary() {
    setAiBusy('summary');
    try {
      const r = await fetch('/api/ai/summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: resume.data }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? 'AI failed');
      setData((d) => ({ ...d, summary: j.summary }));
    } catch (e: any) {
      alert(e.message);
    } finally {
      setAiBusy(null);
    }
  }

  async function aiRewriteBullet(expIdx: number, bulletIdx: number) {
    const exp = resume.data.experience[expIdx];
    const bullet = exp.bullets[bulletIdx];
    if (!bullet || bullet.length < 4) return;
    setAiBusy(`bullet:${expIdx}:${bulletIdx}`);
    try {
      const r = await fetch('/api/ai/bullet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bullet,
          context: { role: exp.title, company: exp.company },
        }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? 'AI failed');
      const choice = window.prompt(
        'Pick a rewrite (1, 2, or 3):\n\n' +
          j.rewrites.map((x: string, i: number) => `${i + 1}. ${x}`).join('\n\n') +
          '\n\nEnter 1, 2, or 3 (or cancel):'
      );
      const n = parseInt(choice ?? '0', 10);
      if (n >= 1 && n <= j.rewrites.length) {
        setData((d) => {
          const exps = [...d.experience];
          exps[expIdx] = {
            ...exps[expIdx],
            bullets: exps[expIdx].bullets.map((b, i) => (i === bulletIdx ? j.rewrites[n - 1] : b)),
          };
          return { ...d, experience: exps };
        });
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setAiBusy(null);
    }
  }

  // ============ EXP/EDU MUTATORS ============
  const addExperience = () =>
    setData((d) => ({
      ...d,
      experience: [
        ...d.experience,
        { title: '', company: '', start: '', end: '', location: '', bullets: [''] },
      ],
    }));

  const removeExperience = (i: number) =>
    setData((d) => ({ ...d, experience: d.experience.filter((_, j) => j !== i) }));

  const updateExp = (i: number, patch: Partial<ExperienceItem>) =>
    setData((d) => ({
      ...d,
      experience: d.experience.map((x, j) => (j === i ? { ...x, ...patch } : x)),
    }));

  const addBullet = (i: number) =>
    setData((d) => ({
      ...d,
      experience: d.experience.map((x, j) =>
        j === i ? { ...x, bullets: [...x.bullets, ''] } : x
      ),
    }));

  const updateBullet = (i: number, bi: number, val: string) =>
    setData((d) => ({
      ...d,
      experience: d.experience.map((x, j) =>
        j === i ? { ...x, bullets: x.bullets.map((b, bj) => (bj === bi ? val : b)) } : x
      ),
    }));

  const removeBullet = (i: number, bi: number) =>
    setData((d) => ({
      ...d,
      experience: d.experience.map((x, j) =>
        j === i ? { ...x, bullets: x.bullets.filter((_, bj) => bj !== bi) } : x
      ),
    }));

  const addEducation = () =>
    setData((d) => ({
      ...d,
      education: [...d.education, { degree: '', school: '', start: '', end: '' }],
    }));

  const removeEducation = (i: number) =>
    setData((d) => ({ ...d, education: d.education.filter((_, j) => j !== i) }));

  const updateEdu = (i: number, patch: Partial<EducationItem>) =>
    setData((d) => ({
      ...d,
      education: d.education.map((x, j) => (j === i ? { ...x, ...patch } : x)),
    }));

  // ============ RENDER ============
  const Tpl = TEMPLATES[resume.templateId]?.Component ?? TEMPLATES.broadsheet.Component;

  return (
    <div className="grid lg:grid-cols-2 h-[calc(100vh-65px)] overflow-hidden">
      {/* LEFT — editor */}
      <section className="overflow-y-auto px-8 pt-6 pb-16 border-r border-rule">
        {/* Bar */}
        <div className="sticky top-0 -mx-8 px-8 py-3.5 bg-cream/95 backdrop-blur-md border-b border-rule mb-5 flex items-center justify-between gap-3 flex-wrap z-[5]">
          <input
            value={resume.title}
            onChange={(e) => setResume((r) => ({ ...r, title: e.target.value }))}
            className="font-serif text-[22px] font-medium tracking-[-0.015em] bg-transparent border-0 outline-0 flex-1 min-w-[200px] py-1 border-b border-dashed border-transparent hover:border-rule focus:border-rule transition-colors"
            placeholder="Untitled résumé"
          />
          <div className="font-mono text-[10.5px] uppercase tracking-[0.06em] text-ink-mute flex items-center gap-1.5">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                saveState === 'saving' ? 'bg-amber animate-pulse' : saveState === 'dirty' ? 'bg-clay' : 'bg-moss'
              }`}
            />
            {saveState === 'saving' ? 'Saving…' : saveState === 'dirty' ? 'Unsaved' : 'Saved'}
          </div>
        </div>

        {/* Template switcher */}
        <Section title="Template">
          <div className="flex gap-1.5 flex-wrap">
            {Object.values(TEMPLATES).map((t) => (
              <button
                key={t.id}
                onClick={() => setResume((r) => ({ ...r, templateId: t.id }))}
                className={`px-3 py-1 rounded-full border text-[12px] transition-colors ${
                  resume.templateId === t.id
                    ? 'bg-ink text-cream border-ink'
                    : 'bg-cream-2 text-ink-soft border-rule hover:border-ink-mute'
                }`}
              >
                {t.name}
              </button>
            ))}
          </div>
        </Section>

        {/* Personal info */}
        <Section title="Personal info">
          <Row>
            <Field label="Full name" value={resume.data.name} onChange={(v) => setData((d) => ({ ...d, name: v }))} />
            <Field label="Headline / role" value={resume.data.title} onChange={(v) => setData((d) => ({ ...d, title: v }))} />
          </Row>
          <Row>
            <Field label="Email" type="email" value={resume.data.email} onChange={(v) => setData((d) => ({ ...d, email: v }))} />
            <Field label="Phone" value={resume.data.phone} onChange={(v) => setData((d) => ({ ...d, phone: v }))} />
          </Row>
          <Row>
            <Field label="Location" value={resume.data.location} onChange={(v) => setData((d) => ({ ...d, location: v }))} />
            <Field label="Website" value={resume.data.website ?? ''} onChange={(v) => setData((d) => ({ ...d, website: v }))} />
          </Row>
          <Field label="LinkedIn" value={resume.data.linkedin ?? ''} onChange={(v) => setData((d) => ({ ...d, linkedin: v }))} />
        </Section>

        {/* Summary */}
        <Section
          title="Summary"
          right={
            <button
              onClick={aiGenerateSummary}
              disabled={aiBusy !== null}
              className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-amber hover:text-amber-deep disabled:opacity-50"
            >
              {aiBusy === 'summary' ? '✦ generating…' : '✦ Generate with AI'}
            </button>
          }
        >
          <div className="field">
            <textarea
              rows={4}
              placeholder="Two or three sentences about who you are and what you do."
              value={resume.data.summary}
              onChange={(e) => setData((d) => ({ ...d, summary: e.target.value }))}
            />
          </div>
        </Section>

        {/* Experience */}
        <Section
          title="Experience"
          right={<button onClick={addExperience} className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-amber hover:text-amber-deep">+ Add role</button>}
        >
          {resume.data.experience.length === 0 ? (
            <button
              onClick={addExperience}
              className="w-full border border-dashed border-rule rounded-lg py-5 text-center font-serif italic text-ink-mute hover:border-ink hover:text-ink"
            >
              + Add your first role
            </button>
          ) : (
            resume.data.experience.map((x, i) => (
              <div key={i} className="bg-paper border border-rule rounded-xl p-3.5 mb-2.5 relative">
                <button
                  onClick={() => removeExperience(i)}
                  className="absolute top-2 right-2.5 text-ink-mute text-[13px] w-5 h-5 rounded-full grid place-items-center hover:bg-brick/10 hover:text-brick"
                  title="Remove role"
                >
                  ✕
                </button>
                <Row>
                  <Field label="Title" value={x.title} onChange={(v) => updateExp(i, { title: v })} />
                  <Field label="Company" value={x.company} onChange={(v) => updateExp(i, { company: v })} />
                </Row>
                <Row>
                  <Field label="Start" value={x.start} placeholder="Jan 2022" onChange={(v) => updateExp(i, { start: v })} />
                  <Field label="End" value={x.end ?? ''} placeholder="Present" onChange={(v) => updateExp(i, { end: v })} />
                </Row>
                <Field label="Location (optional)" value={x.location ?? ''} onChange={(v) => updateExp(i, { location: v })} />
                <div className="mt-2.5">
                  <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute block mb-1.5">Bullets</label>
                  {x.bullets.map((b, bi) => (
                    <div key={bi} className="flex items-start gap-2 mb-1.5">
                      <span className="text-amber pt-2 text-xs">▸</span>
                      <textarea
                        rows={2}
                        className="flex-1 bg-cream-2 border border-rule rounded-md px-2.5 py-1.5 text-[13px] font-serif resize-none leading-snug focus:border-ink outline-0"
                        value={b}
                        onChange={(e) => updateBullet(i, bi, e.target.value)}
                        placeholder="Action verb, quantified outcome."
                      />
                      <button
                        onClick={() => aiRewriteBullet(i, bi)}
                        disabled={aiBusy !== null || b.length < 4}
                        title="Rewrite with AI"
                        className="text-amber p-1.5 text-[11px] hover:text-amber-deep disabled:opacity-30"
                      >
                        {aiBusy === `bullet:${i}:${bi}` ? '…' : '✦'}
                      </button>
                      <button
                        onClick={() => removeBullet(i, bi)}
                        className="text-ink-mute p-1.5 text-[11px] hover:text-brick"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => addBullet(i)}
                    className="font-mono text-[11px] uppercase tracking-[0.1em] text-amber hover:text-amber-deep"
                  >
                    + Add bullet
                  </button>
                </div>
              </div>
            ))
          )}
        </Section>

        {/* Education */}
        <Section
          title="Education"
          right={<button onClick={addEducation} className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-amber hover:text-amber-deep">+ Add school</button>}
        >
          {resume.data.education.length === 0 ? (
            <button
              onClick={addEducation}
              className="w-full border border-dashed border-rule rounded-lg py-5 text-center font-serif italic text-ink-mute hover:border-ink hover:text-ink"
            >
              + Add education
            </button>
          ) : (
            resume.data.education.map((e, i) => (
              <div key={i} className="bg-paper border border-rule rounded-xl p-3.5 mb-2.5 relative">
                <button
                  onClick={() => removeEducation(i)}
                  className="absolute top-2 right-2.5 text-ink-mute text-[13px] w-5 h-5 rounded-full grid place-items-center hover:bg-brick/10 hover:text-brick"
                >
                  ✕
                </button>
                <Row>
                  <Field label="Degree" value={e.degree} onChange={(v) => updateEdu(i, { degree: v })} />
                  <Field label="School" value={e.school} onChange={(v) => updateEdu(i, { school: v })} />
                </Row>
                <Row>
                  <Field label="Start" value={e.start} onChange={(v) => updateEdu(i, { start: v })} />
                  <Field label="End" value={e.end ?? ''} onChange={(v) => updateEdu(i, { end: v })} />
                </Row>
              </div>
            ))
          )}
        </Section>

        {/* Skills */}
        <Section title="Skills">
          <div className="field">
            <textarea
              rows={2}
              placeholder="React, Figma, Public speaking — comma separated"
              value={resume.data.skills.join(', ')}
              onChange={(e) => setData((d) => ({ ...d, skills: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) }))}
            />
          </div>
        </Section>
      </section>

      {/* RIGHT — preview */}
      <section className="bg-cream-2 overflow-y-auto p-7 flex flex-col items-center gap-5">
        <div className="w-full max-w-[580px]">
          <Tpl data={resume.data} />
        </div>
        <div className="flex gap-2 flex-wrap justify-center no-print">
          <button onClick={() => window.print()} className="btn btn-amber">↓ Download PDF</button>
          <button onClick={() => router.push('/dashboard')} className="btn btn-outline">My résumés</button>
        </div>
        <div className="font-mono text-[10.5px] text-ink-mute tracking-[0.06em] text-center max-w-[380px] no-print">
          TIP · in the print dialog choose "Save as PDF" as the destination
        </div>
      </section>
    </div>
  );
}

// ============ INTERNAL UI HELPERS ============
function Section({
  title,
  right,
  children,
}: {
  title: string;
  right?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-7">
      <div className="flex justify-between items-baseline mb-2.5">
        <h3 className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute font-medium">
          {title}
        </h3>
        {right}
      </div>
      {children}
    </div>
  );
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 [&>.field]:mb-0 mb-3.5">{children}</div>;
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div className="field">
      <label>{label}</label>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
