// Folio — résumé templates as React components.
// Currently 5; growing to 18 across subsequent turns.
// Every template takes the same `ResumeData` and renders an article that fits 8.5×11.

import type { ResumeData } from '@/lib/resume-types';

type TplProps = { data: ResumeData };

// Helper: only render dates/contact bits if they exist
const dateRange = (start?: string, end?: string) =>
  [start, end].filter(Boolean).join(' — ');

const contactJoin = (...parts: (string | undefined)[]) =>
  parts.filter(Boolean).join(' · ');

// ============ 1. BROADSHEET (CLASSIC) ============
function Broadsheet({ data: d }: TplProps) {
  return (
    <article className="tpl tpl-broadsheet">
      <header>
        <h1>{d.name || 'Your name'}</h1>
        <div className="role">{d.title || 'Your title'}</div>
        <div className="contact">{contactJoin(d.email, d.phone, d.location, d.website)}</div>
      </header>
      {d.summary && (
        <section>
          <h2>Summary</h2>
          <p>{d.summary}</p>
        </section>
      )}
      {d.experience.length > 0 && (
        <section>
          <h2>Experience</h2>
          {d.experience.map((x, i) => (
            <div key={i} className="entry">
              <div className="row">
                <span><strong>{x.title}</strong>{x.company && <>, <em>{x.company}</em></>}</span>
                <span className="dates">{dateRange(x.start, x.end)}</span>
              </div>
              {x.bullets.length > 0 && (
                <ul>{x.bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>
              )}
            </div>
          ))}
        </section>
      )}
      {d.education.length > 0 && (
        <section>
          <h2>Education</h2>
          {d.education.map((e, i) => (
            <div key={i} className="row">
              <span><strong>{e.degree}</strong>{e.school && <>, <em>{e.school}</em></>}</span>
              <span className="dates">{dateRange(e.start, e.end)}</span>
            </div>
          ))}
        </section>
      )}
      {d.skills.length > 0 && (
        <section>
          <h2>Skills</h2>
          <p className="skills">{d.skills.join(' · ')}</p>
        </section>
      )}
    </article>
  );
}

// ============ 2. SIDEBAR (MODERN) ============
function Sidebar({ data: d }: TplProps) {
  return (
    <article className="tpl tpl-sidebar">
      <aside>
        <div className="ident">
          <div className="ident-name">{d.name || 'Your name'}</div>
          <div className="ident-role">{d.title || 'Your title'}</div>
        </div>
        <div className="aside-block">
          <h3>Contact</h3>
          {d.email && <div>{d.email}</div>}
          {d.phone && <div>{d.phone}</div>}
          {d.location && <div>{d.location}</div>}
          {d.website && <div>{d.website}</div>}
          {d.linkedin && <div>{d.linkedin}</div>}
        </div>
        {d.skills.length > 0 && (
          <div className="aside-block">
            <h3>Skills</h3>
            {d.skills.map((s, i) => <div key={i}>{s}</div>)}
          </div>
        )}
      </aside>
      <main>
        {d.summary && (
          <section>
            <h2>Profile</h2>
            <p>{d.summary}</p>
          </section>
        )}
        {d.experience.length > 0 && (
          <section>
            <h2>Experience</h2>
            {d.experience.map((x, i) => (
              <div key={i} className="entry">
                <div className="row">
                  <span><strong>{x.title}</strong></span>
                  <span className="dates">{dateRange(x.start, x.end)}</span>
                </div>
                <div className="company">{x.company}{x.location && ` · ${x.location}`}</div>
                {x.bullets.length > 0 && (
                  <ul>{x.bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>
                )}
              </div>
            ))}
          </section>
        )}
        {d.education.length > 0 && (
          <section>
            <h2>Education</h2>
            {d.education.map((e, i) => (
              <div key={i} className="row">
                <span><strong>{e.degree}</strong>{e.school && `, ${e.school}`}</span>
                <span className="dates">{dateRange(e.start, e.end)}</span>
              </div>
            ))}
          </section>
        )}
      </main>
    </article>
  );
}

// ============ 3. EDITORIAL (SERIF) ============
function Editorial({ data: d }: TplProps) {
  return (
    <article className="tpl tpl-editorial">
      <header>
        <h1>{d.name || 'Your name'}</h1>
        <div className="role">{d.title || 'Your title'}</div>
      </header>
      <div className="grid">
        <aside>
          <div className="ed-block">
            <h3>Contact</h3>
            {d.email && <div>{d.email}</div>}
            {d.phone && <div>{d.phone}</div>}
            {d.location && <div>{d.location}</div>}
            {d.website && <div>{d.website}</div>}
          </div>
          {d.skills.length > 0 && (
            <div className="ed-block">
              <h3>Skills</h3>
              <p>{d.skills.join(' · ')}</p>
            </div>
          )}
          {d.education.length > 0 && (
            <div className="ed-block">
              <h3>Education</h3>
              {d.education.map((e, i) => (
                <div key={i}>
                  <div><strong>{e.degree}</strong></div>
                  <div className="ed-meta">{e.school}{e.end && ` · ${e.end}`}</div>
                </div>
              ))}
            </div>
          )}
        </aside>
        <main>
          {d.summary && (
            <section>
              <p className="lede">{d.summary}</p>
            </section>
          )}
          {d.experience.length > 0 && (
            <section>
              <h2>Experience</h2>
              {d.experience.map((x, i) => (
                <div key={i} className="entry">
                  <div className="ed-title">
                    {x.title}<span className="ed-comma">,</span> <em>{x.company}</em>
                  </div>
                  <div className="ed-meta">
                    {dateRange(x.start, x.end)}{x.location && ` · ${x.location}`}
                  </div>
                  {x.bullets.length > 0 && (
                    <ul>{x.bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>
                  )}
                </div>
              ))}
            </section>
          )}
        </main>
      </div>
    </article>
  );
}

// ============ 4. WHISPER (MINIMAL) ============
function Whisper({ data: d }: TplProps) {
  const lc = (s: string) => s.toLowerCase();
  return (
    <article className="tpl tpl-whisper">
      <header>
        <h1>{lc(d.name || 'your name')}.</h1>
        <div className="role">{lc(d.title || 'your title')}</div>
        <div className="contact">
          {[d.email, d.phone, d.location, d.website].filter(Boolean).map(lc).join('  /  ')}
        </div>
      </header>
      {d.summary && <section>{d.summary}</section>}
      {d.experience.length > 0 && (
        <section>
          <h2>experience</h2>
          {d.experience.map((x, i) => (
            <div key={i} className="entry">
              <div className="title">{lc(x.title)} · {lc(x.company)}</div>
              <div className="dates">{lc(dateRange(x.start, x.end))}</div>
              {x.bullets.length > 0 && (
                <ul>{x.bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>
              )}
            </div>
          ))}
        </section>
      )}
      {d.education.length > 0 && (
        <section>
          <h2>education</h2>
          {d.education.map((e, i) => (
            <div key={i} className="entry">
              <div className="title">{lc(e.degree)}</div>
              <div className="dates">{lc(e.school)}{e.end && `  —  ${lc(e.end)}`}</div>
            </div>
          ))}
        </section>
      )}
      {d.skills.length > 0 && (
        <section>
          <h2>skills</h2>
          <div className="skills">{d.skills.map(lc).join(' · ')}</div>
        </section>
      )}
    </article>
  );
}

// ============ 5. COMPACT (DENSE) ============
function Compact({ data: d }: TplProps) {
  return (
    <article className="tpl tpl-compact">
      <header>
        <h1>{d.name || 'Your name'}</h1>
        <div className="role">{d.title || 'Your title'}</div>
        <div className="contact">{contactJoin(d.email, d.phone, d.location, d.website, d.linkedin)}</div>
      </header>
      <hr />
      {d.summary && (
        <section className="full">
          <strong>SUMMARY.</strong> {d.summary}
        </section>
      )}
      <div className="cols">
        <div className="left-col">
          {d.experience.length > 0 && (
            <section>
              <h2>Experience</h2>
              {d.experience.map((x, i) => (
                <div key={i} className="entry">
                  <div className="row">
                    <strong>{x.title}</strong>
                    <span className="dates">{dateRange(x.start, x.end)}</span>
                  </div>
                  <div className="company"><em>{x.company}</em>{x.location && `, ${x.location}`}</div>
                  {x.bullets.length > 0 && (
                    <ul>{x.bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>
                  )}
                </div>
              ))}
            </section>
          )}
        </div>
        <div className="right-col">
          {d.skills.length > 0 && (
            <section>
              <h2>Skills</h2>
              <p>{d.skills.join(' · ')}</p>
            </section>
          )}
          {d.education.length > 0 && (
            <section>
              <h2>Education</h2>
              {d.education.map((e, i) => (
                <div key={i} className="entry">
                  <div><strong>{e.degree}</strong></div>
                  <div className="company"><em>{e.school}</em></div>
                  <div className="dates">{dateRange(e.start, e.end)}</div>
                </div>
              ))}
            </section>
          )}
        </div>
      </div>
    </article>
  );
}

// ============ TEMPLATE REGISTRY ============
export type TemplateMeta = {
  id: string;
  name: string;
  tag: string;
  desc: string;
  Component: React.ComponentType<TplProps>;
};

export const TEMPLATES: Record<string, TemplateMeta> = {
  broadsheet: {
    id: 'broadsheet',
    name: 'Broadsheet',
    tag: 'CLASSIC',
    desc: 'Single-column serif. Newspaper-style. Reads quietly, prints clean.',
    Component: Broadsheet,
  },
  sidebar: {
    id: 'sidebar',
    name: 'Sidebar',
    tag: 'MODERN',
    desc: 'Dark left rail with contact and skills. Bold. Recruiter-friendly.',
    Component: Sidebar,
  },
  editorial: {
    id: 'editorial',
    name: 'Editorial',
    tag: 'SERIF',
    desc: 'Italic display name and grid layout. Magazine-style. Memorable.',
    Component: Editorial,
  },
  whisper: {
    id: 'whisper',
    name: 'Whisper',
    tag: 'MINIMAL',
    desc: 'Lowercase, sans-serif, generous whitespace. Less is more.',
    Component: Whisper,
  },
  compact: {
    id: 'compact',
    name: 'Compact',
    tag: 'DENSE',
    desc: 'Two-column dense layout. Maximizes content on one page. For senior CVs.',
    Component: Compact,
  },
};

export function renderTemplate(templateId: string, data: ResumeData) {
  const t = TEMPLATES[templateId] ?? TEMPLATES.broadsheet;
  const C = t.Component;
  return <C data={data} />;
}
