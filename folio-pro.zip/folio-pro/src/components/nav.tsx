'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';

export type CurrentUser = {
  id: string;
  email: string;
  name: string | null;
  plan: string;
} | null;

export function Nav({ user }: { user: CurrentUser }) {
  const router = useRouter();

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-md bg-cream/80 border-b border-rule no-print">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-12 py-4 flex items-center justify-between">
        <Link href="/" className="font-serif text-[26px] font-semibold tracking-tight flex items-baseline gap-1.5">
          Folio<span className="w-[7px] h-[7px] rounded-full bg-amber inline-block self-center ml-0.5" />
        </Link>
        <div className="hidden md:flex gap-8 text-sm text-ink-soft">
          <Link href="/upload" className="hover:text-ink">Upload</Link>
          <Link href="/match" className="hover:text-ink">Match</Link>
          <Link href="/builder" className="hover:text-ink">Build</Link>
          {user && <Link href="/dashboard" className="hover:text-ink">My résumés</Link>}
        </div>
        <div className="flex items-center gap-3">
          {user ? (
            <>
              <Link href="/builder" className="btn btn-primary">+ New</Link>
              <button onClick={logout} className="btn btn-ghost">Log out</button>
            </>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost">Log in</Link>
              <Link href="/signup" className="btn btn-primary">Get started</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
