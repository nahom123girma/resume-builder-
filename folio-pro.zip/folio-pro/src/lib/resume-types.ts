// Folio — shared resume types

export type ExperienceItem = {
  title: string;
  company: string;
  location?: string;
  start: string;
  end?: string;
  bullets: string[];
};

export type EducationItem = {
  degree: string;
  school: string;
  location?: string;
  start: string;
  end?: string;
};

export type ProjectItem = {
  name: string;
  url?: string;
  description: string;
  bullets: string[];
};

export type CertificationItem = {
  name: string;
  issuer: string;
  date?: string;
  credentialId?: string;
};

export type ResumeData = {
  name: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  linkedin?: string;
  summary: string;
  experience: ExperienceItem[];
  education: EducationItem[];
  skills: string[];
  projects?: ProjectItem[];
  certifications?: CertificationItem[];
};

export const EMPTY_RESUME: ResumeData = {
  name: '',
  title: '',
  email: '',
  phone: '',
  location: '',
  website: '',
  linkedin: '',
  summary: '',
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
};

export const SAMPLE_RESUME: ResumeData = {
  name: 'Maya Hernandez',
  title: 'Senior Product Designer',
  email: 'maya@folio.studio',
  phone: '+1 (415) 555 0117',
  location: 'San Francisco, CA',
  website: 'mayahernandez.design',
  linkedin: 'linkedin.com/in/mayah',
  summary:
    'Senior product designer with 8 years shipping 0→1 products at venture-backed startups. Specialise in design systems, dense data UIs, and the kind of unglamorous CRUD work that makes a product actually usable.',
  experience: [
    {
      title: 'Senior Product Designer',
      company: 'Linear',
      location: 'Remote',
      start: 'Mar 2022',
      end: 'Present',
      bullets: [
        'Led design for the Insights product line, taking it from prototype to general availability across 2,300+ teams.',
        "Built and maintained Linear's design-system primitives, reducing component duplication by 64% across 8 product surfaces.",
        "Mentored 4 junior designers; ran weekly critique that became the team's most-attended ritual.",
      ],
    },
    {
      title: 'Product Designer',
      company: 'Notion',
      location: 'San Francisco',
      start: 'Jun 2019',
      end: 'Feb 2022',
      bullets: [
        "Designed Notion's first iOS-native editor; shipped to 2M+ users in the first quarter.",
        'Owned the onboarding redesign that lifted activation from 41% → 58% over 9 months.',
      ],
    },
  ],
  education: [
    {
      degree: 'BFA, Communication Design',
      school: 'Parsons School of Design',
      location: 'New York, NY',
      start: '2015',
      end: '2019',
    },
  ],
  skills: ['Product Design', 'Design Systems', 'Figma', 'Prototyping', 'User Research', 'SwiftUI', 'React', 'CSS'],
  projects: [],
  certifications: [],
};
