// Folio — auth helpers
// JWT-signed session cookies via `jose`. Passwords hashed with bcrypt.

import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { db } from './db';

const COOKIE_NAME = 'folio_session';
const ALG = 'HS256';

function getKey() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error(
      'AUTH_SECRET is missing or too short. Generate one with `openssl rand -base64 32`.'
    );
  }
  return new TextEncoder().encode(secret);
}

export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string) {
  return bcrypt.compare(plain, hash);
}

export async function createSession(userId: string) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: ALG })
    .setIssuedAt()
    .setExpirationTime('30d')
    .sign(getKey());

  const c = await cookies();
  c.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
}

export async function destroySession() {
  const c = await cookies();
  c.delete(COOKIE_NAME);
}

/** Reads the session cookie and returns `{ userId }` or null. */
export async function readSession(): Promise<{ userId: string } | null> {
  try {
    const c = await cookies();
    const token = c.get(COOKIE_NAME)?.value;
    if (!token) return null;
    const { payload } = await jwtVerify(token, getKey(), { algorithms: [ALG] });
    if (typeof payload.uid !== 'string') return null;
    return { userId: payload.uid };
  } catch {
    return null;
  }
}

/** Returns the current user, or null. */
export async function getCurrentUser() {
  const s = await readSession();
  if (!s) return null;
  return db.user.findUnique({
    where: { id: s.userId },
    select: { id: true, email: true, name: true, plan: true, createdAt: true },
  });
}

/** Use in server components / pages: redirects to /login if no user. */
export async function requireUser() {
  const u = await getCurrentUser();
  if (!u) {
    const { redirect } = await import('next/navigation');
    redirect('/login');
  }
  return u!;
}
