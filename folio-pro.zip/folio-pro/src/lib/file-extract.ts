// Folio — file extraction helpers
// Extract raw text from uploaded PDF / DOCX files. Used by /api/upload/parse.

const MAX_BYTES = 4 * 1024 * 1024; // 4 MB

export type ExtractedDoc = {
  text: string;
  filename: string;
  kind: 'pdf' | 'docx';
  bytes: number;
};

export async function extractText(file: File): Promise<ExtractedDoc> {
  if (file.size > MAX_BYTES) {
    throw new Error(`File is ${(file.size / 1024 / 1024).toFixed(1)} MB. Limit is 4 MB.`);
  }

  const lowerName = file.name.toLowerCase();
  const isPdf =
    file.type === 'application/pdf' || lowerName.endsWith('.pdf');
  const isDocx =
    file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    lowerName.endsWith('.docx');

  if (!isPdf && !isDocx) {
    throw new Error('Unsupported file type. Upload a PDF or DOCX.');
  }

  const buffer = await file.arrayBuffer();

  if (isPdf) {
    // Dynamic import — keeps unpdf out of the cold-start critical path
    // on routes that don't need it.
    const { extractText: pdfExtract, getDocumentProxy } = await import('unpdf');
    const pdf = await getDocumentProxy(new Uint8Array(buffer));
    const { text } = await pdfExtract(pdf, { mergePages: true });
    const merged = Array.isArray(text) ? text.join('\n') : (text as string);
    return {
      text: cleanWhitespace(merged),
      filename: file.name,
      kind: 'pdf',
      bytes: file.size,
    };
  }

  // DOCX
  const mammoth = (await import('mammoth')).default;
  const result = await mammoth.extractRawText({ buffer: Buffer.from(buffer) });
  return {
    text: cleanWhitespace(result.value),
    filename: file.name,
    kind: 'docx',
    bytes: file.size,
  };
}

/**
 * Light cleanup. PDF extraction often produces broken whitespace and
 * weird ligature artifacts. We normalize but DON'T rewrite content —
 * the AI parsing pass handles structure interpretation.
 */
function cleanWhitespace(text: string): string {
  return text
    .replace(/\u0000/g, '')                // null bytes
    .replace(/\r\n/g, '\n')                 // windows line endings
    .replace(/\u00ad/g, '')                 // soft hyphens
    .replace(/[ \t]+/g, ' ')                // collapse runs of spaces/tabs
    .replace(/\n{3,}/g, '\n\n')             // collapse 3+ blank lines
    .replace(/[\u2018\u2019]/g, "'")        // smart quotes → straight
    .replace(/[\u201c\u201d]/g, '"')
    .trim();
}
