// Folio — Anthropic API wrapper
// Single place where every AI call lives. Models centralized so you can swap.

import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Model selection:
// - HAIKU for fast, cheap tasks (summary generation, bullet rewrites, skill suggestions)
// - SONNET for heavier reasoning (job-match analysis, ATS scoring with NLP)
export const MODELS = {
  fast: 'claude-haiku-4-5',
  smart: 'claude-sonnet-4-6',
} as const;

export type ModelTier = keyof typeof MODELS;

/**
 * Run a one-shot Claude completion. System prompt + user prompt → text out.
 * For more advanced flows (streaming, tools), use the SDK directly.
 */
export async function complete(opts: {
  system: string;
  user: string;
  tier?: ModelTier;
  maxTokens?: number;
}) {
  const model = MODELS[opts.tier ?? 'fast'];
  const response = await client.messages.create({
    model,
    max_tokens: opts.maxTokens ?? 1024,
    system: opts.system,
    messages: [{ role: 'user', content: opts.user }],
  });
  // Extract the text from the first text block
  const block = response.content.find((b) => b.type === 'text');
  return {
    text: block && block.type === 'text' ? block.text : '',
    usage: response.usage,
    model,
  };
}

/**
 * Ask Claude for structured JSON. The system prompt MUST instruct it to
 * return only JSON. We strip ```json fences and parse.
 */
export async function completeJSON<T = unknown>(opts: {
  system: string;
  user: string;
  tier?: ModelTier;
  maxTokens?: number;
}): Promise<{ data: T; usage: Anthropic.Usage; model: string }> {
  const { text, usage, model } = await complete({
    ...opts,
    system: opts.system + '\n\nRespond ONLY with valid JSON. No markdown, no preamble.',
  });
  const cleaned = text.replace(/```json\s*|\s*```/g, '').trim();
  let data: T;
  try {
    data = JSON.parse(cleaned);
  } catch {
    // Try to find a JSON object inside the text
    const m = cleaned.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
    if (!m) throw new Error('Claude returned non-JSON output: ' + text.slice(0, 200));
    data = JSON.parse(m[0]);
  }
  return { data, usage, model };
}
