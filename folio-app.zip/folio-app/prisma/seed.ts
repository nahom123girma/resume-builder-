import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { SAMPLE_RESUME } from "../src/types/resume";

const db = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database…");

  // Create demo user
  const passwordHash = await bcrypt.hash("password123", 10);
  const user = await db.user.upsert({
    where: { email: "demo@folio.studio" },
    create: {
      email: "demo@folio.studio",
      name: "Maya Hernandez",
      passwordHash,
      plan: "PRO",
    },
    update: {},
  });
  console.log(`✅ Created user: ${user.email} (password: password123)`);

  // Sample resume
  const resume = await db.resume.upsert({
    where: { id: "demo-resume" },
    create: {
      id: "demo-resume",
      userId: user.id,
      title: "Senior Product Designer",
      content: JSON.stringify(SAMPLE_RESUME),
      atsScore: 87,
    },
    update: {
      content: JSON.stringify(SAMPLE_RESUME),
    },
  });
  console.log(`✅ Created résumé: ${resume.title}`);

  // Sample jobs across pipeline
  const sampleJobs = [
    { title: "Senior Product Designer", company: "Anthropic", location: "San Francisco / Remote", salaryRange: "$210k - $250k", status: "INTERVIEW", matchScore: 94 },
    { title: "Staff Designer", company: "Linear", location: "Remote", salaryRange: "$220k - $280k", status: "APPLIED", matchScore: 91 },
    { title: "Product Designer, Growth", company: "Vercel", location: "Remote", salaryRange: "$180k - $220k", status: "SAVED", matchScore: 86 },
    { title: "Senior IC Designer", company: "Figma", location: "San Francisco", salaryRange: "$200k - $260k", status: "REJECTED", matchScore: 78 },
    { title: "Lead Product Designer", company: "Stripe", location: "Remote", salaryRange: "$240k - $300k", status: "INTERVIEW", matchScore: 89 },
    { title: "Senior Product Designer", company: "Notion", location: "San Francisco", salaryRange: "$190k - $230k", status: "OFFER", matchScore: 92 },
  ];

  for (const j of sampleJobs) {
    await db.job.create({
      data: {
        userId: user.id,
        title: j.title,
        company: j.company,
        location: j.location,
        salaryRange: j.salaryRange,
        status: j.status as any,
        matchScore: j.matchScore,
        appliedAt: ["APPLIED", "INTERVIEW", "OFFER", "REJECTED"].includes(j.status)
          ? new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000)
          : null,
        interviewAt: ["INTERVIEW", "OFFER"].includes(j.status)
          ? new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000)
          : null,
      },
    });
  }
  console.log(`✅ Created ${sampleJobs.length} jobs`);

  console.log("\n🎉 Done. Log in at http://localhost:3000/login with:");
  console.log("   email:    demo@folio.studio");
  console.log("   password: password123\n");
}

main()
  .catch((e) => {
    console.error("Seed failed:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
