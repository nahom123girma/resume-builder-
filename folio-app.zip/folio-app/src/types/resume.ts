// The shape of resume.content (stored as JSON string in DB)

export interface ResumeContent {
  contact: ContactInfo;
  summary?: string;
  experience: ExperienceEntry[];
  education: EducationEntry[];
  skills: string[];
  projects?: ProjectEntry[];
  certifications?: CertificationEntry[];
  languages?: LanguageEntry[];
  // Section ordering — drives the editor and renderer
  sectionOrder: SectionKey[];
}

export type SectionKey =
  | "contact"
  | "summary"
  | "experience"
  | "education"
  | "skills"
  | "projects"
  | "certifications"
  | "languages";

export interface ContactInfo {
  name: string;
  title: string;
  email: string;
  phone?: string;
  location?: string;
  website?: string;
  linkedin?: string;
}

export interface ExperienceEntry {
  id: string;
  title: string;
  company: string;
  location?: string;
  startDate: string;
  endDate: string | "Present";
  bullets: { id: string; text: string }[];
}

export interface EducationEntry {
  id: string;
  degree: string;
  school: string;
  location?: string;
  startDate: string;
  endDate: string;
  gpa?: string;
}

export interface ProjectEntry {
  id: string;
  name: string;
  description: string;
  url?: string;
  bullets?: { id: string; text: string }[];
}

export interface CertificationEntry {
  id: string;
  name: string;
  issuer: string;
  date: string;
}

export interface LanguageEntry {
  id: string;
  language: string;
  proficiency: "Native" | "Fluent" | "Professional" | "Conversational" | "Basic";
}

// Default empty resume — used when a new resume is created
export const EMPTY_RESUME: ResumeContent = {
  contact: { name: "", title: "", email: "" },
  summary: "",
  experience: [],
  education: [],
  skills: [],
  sectionOrder: ["contact", "summary", "experience", "education", "skills"],
};

// Sample resume — for the "try it without signing up" flow
export const SAMPLE_RESUME: ResumeContent = {
  contact: {
    name: "Maya Hernandez",
    title: "Senior Product Designer",
    email: "maya@folio.studio",
    phone: "+1 (415) 555 · 0117",
    location: "San Francisco, CA",
    website: "mayahernandez.design",
  },
  summary:
    "Senior product designer with 8 years shipping 0→1 products at venture-backed startups. Specialize in design systems, dense data UIs, and the kind of unglamorous CRUD work that makes a product actually usable.",
  experience: [
    {
      id: "exp-1",
      title: "Senior Product Designer",
      company: "Linear",
      location: "Remote",
      startDate: "Mar 2022",
      endDate: "Present",
      bullets: [
        {
          id: "b-1",
          text: "Led design for the Insights product line, taking it from prototype to general availability across 2,300+ teams.",
        },
        {
          id: "b-2",
          text: "Built and maintained Linear's design-system primitives, reducing component duplication by 64% across 8 product surfaces.",
        },
        {
          id: "b-3",
          text: "Mentored 4 junior designers; ran weekly critique that became the team's most-attended ritual.",
        },
      ],
    },
    {
      id: "exp-2",
      title: "Product Designer",
      company: "Notion",
      location: "San Francisco",
      startDate: "Jun 2019",
      endDate: "Feb 2022",
      bullets: [
        {
          id: "b-4",
          text: "Designed Notion's first iOS-native editor; shipped to 2M+ users in the first quarter.",
        },
        {
          id: "b-5",
          text: "Owned the onboarding redesign that lifted activation from 41% → 58% over 9 months.",
        },
      ],
    },
  ],
  education: [
    {
      id: "edu-1",
      degree: "BFA, Communication Design",
      school: "Parsons School of Design",
      location: "New York, NY",
      startDate: "2015",
      endDate: "2019",
    },
  ],
  skills: [
    "Product Design",
    "Design Systems",
    "Figma",
    "Prototyping",
    "User Research",
    "SwiftUI",
    "React",
    "CSS",
  ],
  sectionOrder: ["contact", "summary", "experience", "education", "skills"],
};
