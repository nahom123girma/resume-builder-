import Stripe from "stripe";

let stripeInstance: Stripe | null = null;

export function getStripe(): Stripe {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not set");
  }
  if (!stripeInstance) {
    stripeInstance = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2025-02-24.acacia",
      typescript: true,
    });
  }
  return stripeInstance;
}

export const PLANS = {
  FREE: {
    name: "Free",
    limits: { resumes: 3, pdfConversionsPerMonth: 5, aiCallsPerMonth: 20 },
  },
  PRO: {
    name: "Pro",
    priceMonthly: process.env.STRIPE_PRICE_PRO_MONTHLY,
    priceYearly: process.env.STRIPE_PRICE_PRO_YEARLY,
    limits: { resumes: Infinity, pdfConversionsPerMonth: Infinity, aiCallsPerMonth: 1000 },
  },
  STUDIO: {
    name: "Studio",
    limits: { resumes: Infinity, pdfConversionsPerMonth: Infinity, aiCallsPerMonth: 5000 },
  },
} as const;
