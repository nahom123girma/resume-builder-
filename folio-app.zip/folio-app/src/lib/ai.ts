import Anthropic from "@anthropic-ai/sdk";
import { db } from "./db";
import type { AiFeature } from "@prisma/client";

// Lazily initialize so missing key doesn't crash at import time
let anthropic: Anthropic | null = null;
function getClient() {
  if (!anthropic && process.env.ANTHROPIC_API_KEY) {
    anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return anthropic;
}

const MODEL = "claude-3-5-sonnet-latest";

// =========================================
// SYSTEM PROMPTS
// Hand-crafted per task. Keep these in source control,
// not in a config file — they're product, not config.
// =========================================

const PROMPTS = {
  REWRITE_BULLET: `You are a résumé writing expert. Rewrite the user's bullet point to be:
- Concise (under 25 words ideally, never over 30)
- Active voice, starting with a strong verb
- Quantified where possible (numbers, percentages, scale)
- ATS-friendly (no special characters or formatting)
- Free of buzzwords ("synergy", "leverage", "passionate")

Return ONLY the rewritten bullet — no preamble, no quotes, no explanation.`,

  REWRITE_SUMMARY: `You are a résumé writing expert. Rewrite the user's professional summary to be:
- 2-3 sentences (60-80 words)
- Specific to their experience (no generic phrases)
- Calibrated to the role they're targeting
- Free of clichés ("results-driven", "team player")

Return ONLY the rewritten summary.`,

  GENERATE_COVER_LETTER: `You are writing a cover letter on behalf of the candidate. Use the résumé and job description provided to write a 250-word letter that:
- Opens with a specific reason for interest in this company (not the role)
- Names two relevant accomplishments from the résumé with metrics
- Connects those to the job's stated needs
- Closes with a specific next step

Use the candidate's voice (clear, direct, no hyperbole). No "I am writing to apply" openers. No "thank you for considering" closers.`,

  TAILOR_RESUME: `You are tailoring a résumé for a specific job. Given the original résumé content and the job description, return a JSON object with:
{
  "summary": "rewritten summary",
  "bullets": [{ "id": "<original-id>", "text": "rewritten bullet" }],
  "skillsOrder": ["reordered", "skills", "list"],
  "missingKeywords": ["keywords from JD not in resume"]
}

Keep all factual content true to the original — don't invent experience.`,

  ATS_SCORE: `You are an ATS (Applicant Tracking System) parser. Analyze the résumé and return a JSON object:
{
  "score": <0-100 integer>,
  "format": "clean" | "issues",
  "lengthOk": <boolean>,
  "keywords": { "found": <int>, "missing": <int>, "list": ["missing", "keywords"] },
  "suggestions": ["specific actionable improvements"]
}`,
};

// =========================================
// HELPERS
// =========================================

interface AiCallOpts {
  userId: string;
  feature: AiFeature;
  prompt: string;
  userMessage: string;
  maxTokens?: number;
}

async function logUsage(
  userId: string,
  feature: AiFeature,
  inputTokens: number,
  outputTokens: number
) {
  // Sonnet pricing as of 2025: $3/M input, $15/M output
  const costCents = Math.ceil(
    (inputTokens / 1_000_000) * 300 + (outputTokens / 1_000_000) * 1500
  );
  await db.aiUsage.create({
    data: {
      userId,
      feature,
      inputTokens,
      outputTokens,
      costCents,
      model: MODEL,
    },
  });
}

// =========================================
// PUBLIC API
// =========================================

export async function callAi(opts: AiCallOpts): Promise<string> {
  const client = getClient();

  // Mock fallback for local dev without API key
  if (!client) {
    return mockResponse(opts.feature, opts.userMessage);
  }

  const response = await client.messages.create({
    model: MODEL,
    max_tokens: opts.maxTokens ?? 1024,
    system: opts.prompt,
    messages: [{ role: "user", content: opts.userMessage }],
  });

  await logUsage(
    opts.userId,
    opts.feature,
    response.usage.input_tokens,
    response.usage.output_tokens
  );

  const text = response.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n");

  return text.trim();
}

// Convenience wrappers
export const ai = {
  rewriteBullet: (userId: string, bullet: string) =>
    callAi({
      userId,
      feature: "REWRITE_BULLET",
      prompt: PROMPTS.REWRITE_BULLET,
      userMessage: bullet,
      maxTokens: 200,
    }),

  rewriteSummary: (userId: string, summary: string, role?: string) =>
    callAi({
      userId,
      feature: "REWRITE_SUMMARY",
      prompt: PROMPTS.REWRITE_SUMMARY,
      userMessage: role
        ? `Target role: ${role}\n\nCurrent summary:\n${summary}`
        : summary,
      maxTokens: 300,
    }),

  coverLetter: (userId: string, resume: string, jobDescription: string) =>
    callAi({
      userId,
      feature: "GENERATE_COVER_LETTER",
      prompt: PROMPTS.GENERATE_COVER_LETTER,
      userMessage: `RÉSUMÉ:\n${resume}\n\nJOB DESCRIPTION:\n${jobDescription}`,
      maxTokens: 800,
    }),

  atsScore: async (userId: string, resume: string, jobDescription?: string) => {
    const text = await callAi({
      userId,
      feature: "ATS_SCORE",
      prompt: PROMPTS.ATS_SCORE,
      userMessage: jobDescription
        ? `RÉSUMÉ:\n${resume}\n\nJOB DESCRIPTION:\n${jobDescription}`
        : resume,
      maxTokens: 600,
    });
    try {
      // Strip markdown fences if present
      const cleaned = text.replace(/^```(?:json)?\n?|\n?```$/g, "");
      return JSON.parse(cleaned);
    } catch {
      return { score: 0, error: "Failed to parse AI response" };
    }
  },
};

// =========================================
// MOCK RESPONSES (used when no API key)
// =========================================

function mockResponse(feature: AiFeature, input: string): string {
  switch (feature) {
    case "REWRITE_BULLET":
      return `Built and nurtured a portfolio of 40+ enterprise relationships, driving $2.1M in new pipeline.`;
    case "REWRITE_SUMMARY":
      return `Senior product designer with 8 years shipping 0→1 products at venture-backed startups. Specialize in design systems and dense data UIs that ship and scale.`;
    case "GENERATE_COVER_LETTER":
      return `Dear hiring manager,\n\nI've followed Anthropic since the publication of the Constitutional AI paper, and I've been waiting for a product role that ties research safety to consumer-facing UX.\n\n[mock response — set ANTHROPIC_API_KEY to get real letters]\n\n— Maya`;
    case "ATS_SCORE":
      return JSON.stringify({
        score: 87,
        format: "clean",
        lengthOk: true,
        keywords: { found: 12, missing: 2, list: ["model evaluation", "safety reviews"] },
        suggestions: ["Add 'model evaluation' to your skills section", "Quantify the Linear bullet about Insights"],
      });
    default:
      return "[mock AI response]";
  }
}
