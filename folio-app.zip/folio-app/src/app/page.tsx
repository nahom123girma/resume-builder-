import { Hero } from "@/components/landing/Hero";
import { TrustBar } from "@/components/landing/TrustBar";
import { Templates } from "@/components/landing/Templates";
import { Results } from "@/components/landing/Results";
import { Features } from "@/components/landing/Features";
import { FinalCta } from "@/components/landing/FinalCta";
import { MarketingNav } from "@/components/layout/MarketingNav";
import { MarketingFooter } from "@/components/layout/MarketingFooter";

export default function HomePage() {
  return (
    <>
      <MarketingNav />
      <main>
        <Hero />
        <TrustBar />
        <Templates />
        <Results />
        <Features />
        <FinalCta />
      </main>
      <MarketingFooter />
    </>
  );
}
