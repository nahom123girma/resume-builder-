import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/", "/dashboard", "/composer", "/jobs", "/letters", "/pdf-tools/merge", "/pdf-tools/split", "/settings", "/assistant"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
