import { MarketingNav } from "@/components/layout/MarketingNav";
import { MarketingFooter } from "@/components/layout/MarketingFooter";
import { PricingTiers } from "@/components/landing/PricingTiers";

export default function PricingPage() {
  return (
    <>
      <MarketingNav />
      <main className="py-[clamp(60px,8vw,100px)]">
        <div className="container-page text-center mb-14">
          <div className="eyebrow mb-6 justify-center"><span>Pricing</span></div>
          <h1 className="font-serif text-[clamp(40px,6vw,72px)] font-normal leading-[0.98] tracking-tightest mb-5">
            Simple <em className="italic text-amber">prices</em>.<br />Honest math.
          </h1>
          <p className="text-ink-soft text-[16px] max-w-[520px] mx-auto">
            Free forever for the basics. Upgrade when you actually need it. Cancel in two clicks.
          </p>
        </div>
        <PricingTiers />
      </main>
      <MarketingFooter />
    </>
  );
}
