import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const now = new Date();

  return [
    { url: `${base}/`, lastModified: now, priority: 1.0, changeFrequency: "weekly" },
    { url: `${base}/pricing`, lastModified: now, priority: 0.9, changeFrequency: "monthly" },
    { url: `${base}/login`, lastModified: now, priority: 0.5 },
    { url: `${base}/signup`, lastModified: now, priority: 0.7 },
    { url: `${base}/pdf-tools`, lastModified: now, priority: 0.8, changeFrequency: "monthly" },
    { url: `${base}/pdf-tools/merge`, lastModified: now, priority: 0.7 },
    { url: `${base}/pdf-tools/split`, lastModified: now, priority: 0.7 },
  ];
}
