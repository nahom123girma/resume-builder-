import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Folio — The career & document studio",
  description:
    "Build a job-winning résumé 2× as fast. Choose from typeset templates, generate content with AI, and apply in minutes.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"),
  icons: {
    icon: "/icon.svg",
  },
  openGraph: {
    title: "Folio — The career & document studio",
    description:
      "The AI-powered studio for résumés, cover letters, PDFs, and job search.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
