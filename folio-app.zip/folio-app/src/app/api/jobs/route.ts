import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import type { Job } from "@prisma/client";
import { z } from "zod";

// GET /api/jobs — list user's jobs grouped by status
export async function GET() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const jobs = await db.job.findMany({
    where: { userId: session.user.id },
    orderBy: { updatedAt: "desc" },
  });

  // Group by status for the kanban
  const grouped = {
    SAVED: jobs.filter((j: Job) => j.status === "SAVED"),
    APPLIED: jobs.filter((j: Job) => j.status === "APPLIED"),
    INTERVIEW: jobs.filter((j: Job) => j.status === "INTERVIEW"),
    OFFER: jobs.filter((j: Job) => j.status === "OFFER"),
    REJECTED: jobs.filter((j: Job) => j.status === "REJECTED"),
  };

  return NextResponse.json({ jobs: grouped, total: jobs.length });
}

const createSchema = z.object({
  title: z.string().min(1),
  company: z.string().min(1),
  location: z.string().optional(),
  url: z.string().url().optional(),
  salaryRange: z.string().optional(),
  description: z.string().optional(),
  status: z.enum(["SAVED", "APPLIED", "INTERVIEW", "OFFER", "REJECTED"]).optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = createSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const job = await db.job.create({
    data: {
      userId: session.user.id,
      ...parsed.data,
      status: parsed.data.status ?? "SAVED",
    },
  });

  return NextResponse.json({ job }, { status: 201 });
}
