import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

async function authOrFail(id: string) {
  const session = await auth();
  if (!session?.user) return { ok: false as const, code: 401 };
  const job = await db.job.findUnique({ where: { id } });
  if (!job) return { ok: false as const, code: 404 };
  if (job.userId !== session.user.id) return { ok: false as const, code: 403 };
  return { ok: true as const, job };
}

const patchSchema = z.object({
  title: z.string().optional(),
  company: z.string().optional(),
  location: z.string().optional(),
  url: z.string().url().optional().nullable(),
  salaryRange: z.string().optional(),
  status: z.enum(["SAVED", "APPLIED", "INTERVIEW", "OFFER", "REJECTED"]).optional(),
  matchScore: z.number().min(0).max(100).optional(),
  description: z.string().optional(),
  notes: z.string().optional(),
  appliedAt: z.string().datetime().optional().nullable(),
  interviewAt: z.string().datetime().optional().nullable(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });

  const parsed = patchSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // If the status moved to APPLIED for the first time, stamp appliedAt
  const data: any = { ...parsed.data };
  if (parsed.data.status === "APPLIED" && !r.job.appliedAt) {
    data.appliedAt = new Date();
  }
  if (parsed.data.status === "INTERVIEW" && !r.job.interviewAt) {
    data.interviewAt = new Date();
  }

  // Convert string dates to Date objects
  if (typeof data.appliedAt === "string") data.appliedAt = new Date(data.appliedAt);
  if (typeof data.interviewAt === "string") data.interviewAt = new Date(data.interviewAt);

  const updated = await db.job.update({
    where: { id: r.job.id },
    data,
  });

  return NextResponse.json({ job: updated });
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });

  await db.job.delete({ where: { id: r.job.id } });
  return NextResponse.json({ ok: true });
}
