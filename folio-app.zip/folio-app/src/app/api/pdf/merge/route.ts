import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { PDFDocument } from "pdf-lib";

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const formData = await req.formData();
  const files = formData.getAll("files") as File[];

  if (files.length < 2) {
    return NextResponse.json({ error: "Need at least 2 PDFs" }, { status: 400 });
  }

  // Hard cap to keep this from blowing memory
  const totalSize = files.reduce((s, f) => s + f.size, 0);
  if (totalSize > 50 * 1024 * 1024) {
    return NextResponse.json({ error: "Total file size > 50MB" }, { status: 413 });
  }

  try {
    const merged = await PDFDocument.create();
    for (const file of files) {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
      const copied = await merged.copyPages(src, src.getPageIndices());
      copied.forEach((p) => merged.addPage(p));
    }

    const out = await merged.save();
    return new NextResponse(out as BodyInit, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": 'attachment; filename="merged.pdf"',
      },
    });
  } catch (err) {
    console.error("PDF merge failed:", err);
    return NextResponse.json({ error: "Failed to merge PDFs" }, { status: 500 });
  }
}
