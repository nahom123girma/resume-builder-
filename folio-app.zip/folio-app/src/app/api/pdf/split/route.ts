import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { PDFDocument } from "pdf-lib";

// Parse "1-3, 5, 7-10" → [0,1,2,4,6,7,8,9] (zero-indexed)
function parsePageRange(input: string, totalPages: number): number[] {
  const indices = new Set<number>();
  for (const part of input.split(",")) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    if (trimmed.includes("-")) {
      const [a, b] = trimmed.split("-").map((s) => parseInt(s.trim(), 10));
      if (isNaN(a) || isNaN(b)) continue;
      for (let i = Math.min(a, b); i <= Math.max(a, b); i++) {
        if (i >= 1 && i <= totalPages) indices.add(i - 1);
      }
    } else {
      const n = parseInt(trimmed, 10);
      if (!isNaN(n) && n >= 1 && n <= totalPages) indices.add(n - 1);
    }
  }
  return Array.from(indices).sort((a, b) => a - b);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  const pageInput = formData.get("pages") as string | null;

  if (!file || !pageInput) {
    return NextResponse.json({ error: "Missing file or page range" }, { status: 400 });
  }

  if (file.size > 25 * 1024 * 1024) {
    return NextResponse.json({ error: "File > 25MB" }, { status: 413 });
  }

  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
    const pages = parsePageRange(pageInput, src.getPageCount());

    if (pages.length === 0) {
      return NextResponse.json({ error: "No valid pages selected" }, { status: 400 });
    }

    const out = await PDFDocument.create();
    const copied = await out.copyPages(src, pages);
    copied.forEach((p) => out.addPage(p));

    const bytes2 = await out.save();
    return new NextResponse(bytes2 as BodyInit, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": 'attachment; filename="split.pdf"',
      },
    });
  } catch (err) {
    console.error("PDF split failed:", err);
    return NextResponse.json({ error: "Failed to split PDF" }, { status: 500 });
  }
}
