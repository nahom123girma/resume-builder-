import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { ai } from "@/lib/ai";
import { db } from "@/lib/db";
import { z } from "zod";

const schema = z.object({
  resumeId: z.string(),
  jobDescription: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const resume = await db.resume.findUnique({
    where: { id: parsed.data.resumeId },
  });
  if (!resume || resume.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  // Convert resume.content (JSON) to plain text for the AI
  const content = JSON.parse(resume.content);
  const plainText = JSON.stringify(content, null, 2);

  const result = await ai.atsScore(session.user.id, plainText, parsed.data.jobDescription);

  // Persist the score
  if (typeof result.score === "number") {
    await db.resume.update({
      where: { id: resume.id },
      data: { atsScore: result.score },
    });
  }

  return NextResponse.json(result);
}
