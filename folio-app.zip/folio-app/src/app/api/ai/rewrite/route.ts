import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { ai } from "@/lib/ai";
import { z } from "zod";

const schema = z.object({
  type: z.enum(["bullet", "summary"]),
  text: z.string().min(1).max(2000),
  role: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const result =
      parsed.data.type === "bullet"
        ? await ai.rewriteBullet(session.user.id, parsed.data.text)
        : await ai.rewriteSummary(session.user.id, parsed.data.text, parsed.data.role);

    return NextResponse.json({ text: result });
  } catch (err) {
    console.error("AI rewrite failed:", err);
    return NextResponse.json({ error: "AI service unavailable" }, { status: 503 });
  }
}
