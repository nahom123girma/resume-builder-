import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { ai } from "@/lib/ai";
import { db } from "@/lib/db";
import { z } from "zod";

const schema = z.object({
  resumeId: z.string(),
  jobDescription: z.string().min(50),
  jobId: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const resume = await db.resume.findUnique({ where: { id: parsed.data.resumeId } });
  if (!resume || resume.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const resumeText = JSON.stringify(JSON.parse(resume.content), null, 2);
  const letterText = await ai.coverLetter(
    session.user.id,
    resumeText,
    parsed.data.jobDescription
  );

  const letter = await db.coverLetter.create({
    data: {
      userId: session.user.id,
      title: "Cover letter — generated",
      content: letterText,
    },
  });

  // Optionally link to a job
  if (parsed.data.jobId) {
    await db.job.update({
      where: { id: parsed.data.jobId },
      data: { coverLetterId: letter.id },
    });
  }

  return NextResponse.json({ letter });
}
