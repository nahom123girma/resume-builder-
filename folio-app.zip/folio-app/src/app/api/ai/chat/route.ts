import { auth } from "@/lib/auth";
import Anthropic from "@anthropic-ai/sdk";
import { db } from "@/lib/db";
import { z } from "zod";
import { NextResponse } from "next/server";

const SYSTEM_PROMPT = `You are Folio, a sharp career assistant for an editorial-warm résumé and document studio. You help users with:
- Résumé writing (tight, quantified, no buzzwords)
- Cover letter drafting (250 words, in their voice, no clichés)
- Interview prep (specific questions, not generic ones)
- Career strategy (calibrated to their level)

Tone: direct, useful, friendly. Short paragraphs. No emojis. No "I'd be happy to" preambles. No "feel free to ask" closers. If a user gives you a piece of writing to improve, return the rewrite first, then a one-sentence note on what changed.`;

const schema = z.object({
  messages: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string(),
  })).min(1).max(50),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // Mock fallback when no API key — for dev without setup
  if (!process.env.ANTHROPIC_API_KEY) {
    return new Response(mockStream("This is a mock response — set ANTHROPIC_API_KEY in your .env to get real answers from Claude."), {
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const userId = session.user.id;

  const stream = await client.messages.stream({
    model: "claude-3-5-sonnet-latest",
    max_tokens: 1024,
    system: SYSTEM_PROMPT,
    messages: parsed.data.messages,
  });

  // Pipe Anthropic's stream into a plain text Response
  const encoder = new TextEncoder();
  let inputTokens = 0;
  let outputTokens = 0;

  const body = new ReadableStream({
    async start(controller) {
      try {
        for await (const event of stream) {
          if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
            controller.enqueue(encoder.encode(event.delta.text));
          }
          if (event.type === "message_start") {
            inputTokens = event.message.usage.input_tokens;
          }
          if (event.type === "message_delta" && event.usage) {
            outputTokens = event.usage.output_tokens;
          }
        }
        controller.close();

        // Log usage post-stream
        const costCents = Math.ceil(
          (inputTokens / 1_000_000) * 300 + (outputTokens / 1_000_000) * 1500
        );
        await db.aiUsage.create({
          data: {
            userId,
            feature: "TAILOR_RESUME", // closest enum value; consider adding CHAT
            inputTokens,
            outputTokens,
            costCents,
            model: "claude-3-5-sonnet-latest",
          },
        }).catch(() => { /* non-fatal */ });
      } catch (err) {
        console.error("Stream error:", err);
        controller.error(err);
      }
    },
  });

  return new Response(body, {
    headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-cache" },
  });
}

// Mock streaming response for dev without API key
function mockStream(text: string): ReadableStream {
  const encoder = new TextEncoder();
  const words = text.split(" ");
  return new ReadableStream({
    async start(controller) {
      for (const word of words) {
        await new Promise((r) => setTimeout(r, 40));
        controller.enqueue(encoder.encode(word + " "));
      }
      controller.close();
    },
  });
}
