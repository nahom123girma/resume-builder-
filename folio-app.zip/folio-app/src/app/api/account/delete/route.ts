import { NextResponse } from "next/server";
import { auth, signOut } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";

export async function POST() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Cascade-deletes everything via schema's onDelete: Cascade relations
  await db.user.delete({ where: { id: session.user.id } });

  // Sign out and redirect to home
  await signOut({ redirect: false });
  return NextResponse.redirect(new URL("/", process.env.NEXTAUTH_URL ?? "http://localhost:3000"));
}
