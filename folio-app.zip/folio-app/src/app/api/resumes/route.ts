import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { EMPTY_RESUME, SAMPLE_RESUME } from "@/types/resume";
import { z } from "zod";

// GET /api/resumes — list user's resumes
export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const resumes = await db.resume.findMany({
    where: { userId: session.user.id },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      title: true,
      templateId: true,
      themeColor: true,
      atsScore: true,
      updatedAt: true,
      createdAt: true,
    },
  });

  return NextResponse.json({ resumes });
}

const createSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  templateId: z.string().optional(),
  starter: z.enum(["empty", "sample"]).optional(),
});

// POST /api/resumes — create a new resume
export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // Plan limit check
  const count = await db.resume.count({ where: { userId: session.user.id } });
  const user = await db.user.findUnique({ where: { id: session.user.id } });
  if (user?.plan === "FREE" && count >= 3) {
    return NextResponse.json(
      { error: "Free plan limited to 3 résumés. Upgrade to Pro for unlimited." },
      { status: 402 }
    );
  }

  const starter = parsed.data.starter ?? "empty";
  const resume = await db.resume.create({
    data: {
      userId: session.user.id,
      title: parsed.data.title ?? "Untitled résumé",
      templateId: parsed.data.templateId ?? "broadsheet",
      content: JSON.stringify(starter === "sample" ? SAMPLE_RESUME : EMPTY_RESUME),
    },
  });

  return NextResponse.json({ resume }, { status: 201 });
}
