import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

async function authOrFail(id: string) {
  const session = await auth();
  if (!session?.user) return { ok: false as const, code: 401 };
  const resume = await db.resume.findUnique({ where: { id } });
  if (!resume) return { ok: false as const, code: 404 };
  if (resume.userId !== session.user.id) return { ok: false as const, code: 403 };
  return { ok: true as const, resume, userId: session.user.id };
}

// GET /api/resumes/[id]
export async function GET(_: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });
  return NextResponse.json({ resume: r.resume });
}

const patchSchema = z.object({
  title: z.string().optional(),
  templateId: z.string().optional(),
  themeColor: z.string().optional(),
  content: z.string().optional(), // JSON string
  atsScore: z.number().min(0).max(100).optional(),
});

// PATCH /api/resumes/[id]
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });

  const body = await req.json();
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // Snapshot a version before significant content changes
  if (parsed.data.content && parsed.data.content !== r.resume.content) {
    await db.resumeVersion.create({
      data: {
        resumeId: r.resume.id,
        content: r.resume.content,
        note: "Auto-snapshot",
      },
    });
  }

  const updated = await db.resume.update({
    where: { id: r.resume.id },
    data: parsed.data,
  });

  return NextResponse.json({ resume: updated });
}

// DELETE /api/resumes/[id]
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });

  await db.resume.delete({ where: { id: r.resume.id } });
  return NextResponse.json({ ok: true });
}
