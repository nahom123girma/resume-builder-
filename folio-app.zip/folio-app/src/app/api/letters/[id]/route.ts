import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

async function authOrFail(id: string) {
  const session = await auth();
  if (!session?.user) return { ok: false as const, code: 401 };
  const letter = await db.coverLetter.findUnique({ where: { id } });
  if (!letter) return { ok: false as const, code: 404 };
  if (letter.userId !== session.user.id) return { ok: false as const, code: 403 };
  return { ok: true as const, letter };
}

const patchSchema = z.object({
  title: z.string().optional(),
  content: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });

  const parsed = patchSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const updated = await db.coverLetter.update({
    where: { id: r.letter.id },
    data: parsed.data,
  });
  return NextResponse.json({ letter: updated });
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const r = await authOrFail(params.id);
  if (!r.ok) return NextResponse.json({ error: "Forbidden" }, { status: r.code });
  await db.coverLetter.delete({ where: { id: r.letter.id } });
  return NextResponse.json({ ok: true });
}
