import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { Document, Paragraph, TextRun, Packer, HeadingLevel, AlignmentType } from "docx";
import type { ResumeContent } from "@/types/resume";
import { z } from "zod";

const schema = z.object({ resumeId: z.string() });

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const resume = await db.resume.findUnique({ where: { id: parsed.data.resumeId } });
  if (!resume || resume.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const content = JSON.parse(resume.content) as ResumeContent;
  const doc = buildDocx(content);
  const buffer = await Packer.toBuffer(doc);

  return new NextResponse(buffer as BodyInit, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="${resume.title.replace(/[^a-z0-9-_]/gi, "_")}.docx"`,
    },
  });
}

function buildDocx(c: ResumeContent): Document {
  const children: Paragraph[] = [];

  // Header — name
  children.push(
    new Paragraph({
      children: [new TextRun({ text: c.contact.name || "Untitled", bold: true, size: 36 })],
      heading: HeadingLevel.TITLE,
      spacing: { after: 80 },
    })
  );
  if (c.contact.title) {
    children.push(
      new Paragraph({
        children: [new TextRun({ text: c.contact.title, italics: true, size: 22 })],
        spacing: { after: 80 },
      })
    );
  }

  // Contact line
  const contactBits = [c.contact.email, c.contact.phone, c.contact.location, c.contact.website]
    .filter(Boolean)
    .join("  ·  ");
  if (contactBits) {
    children.push(
      new Paragraph({
        children: [new TextRun({ text: contactBits, size: 18 })],
        spacing: { after: 240 },
      })
    );
  }

  // Summary
  if (c.summary) {
    pushHeading(children, "SUMMARY");
    children.push(
      new Paragraph({
        children: [new TextRun({ text: c.summary, size: 22 })],
        spacing: { after: 200 },
      })
    );
  }

  // Experience
  if (c.experience.length) {
    pushHeading(children, "EXPERIENCE");
    for (const exp of c.experience) {
      const dateRange = `${exp.startDate}${exp.endDate ? ` — ${exp.endDate}` : ""}`;
      children.push(
        new Paragraph({
          children: [
            new TextRun({ text: exp.title, bold: true, size: 22 }),
            new TextRun({ text: exp.company ? `, ${exp.company}` : "", italics: true, size: 22 }),
            new TextRun({ text: `\t${dateRange}`, size: 18, color: "666666" }),
          ],
          spacing: { before: 120, after: 80 },
        })
      );
      for (const b of exp.bullets) {
        children.push(
          new Paragraph({
            children: [new TextRun({ text: `• ${b.text}`, size: 22 })],
            indent: { left: 280 },
            spacing: { after: 60 },
          })
        );
      }
    }
  }

  // Education
  if (c.education.length) {
    pushHeading(children, "EDUCATION");
    for (const edu of c.education) {
      const dateRange = `${edu.startDate}${edu.endDate ? ` — ${edu.endDate}` : ""}`;
      children.push(
        new Paragraph({
          children: [
            new TextRun({ text: edu.degree, bold: true, size: 22 }),
            new TextRun({ text: edu.school ? `, ${edu.school}` : "", italics: true, size: 22 }),
            new TextRun({ text: `\t${dateRange}`, size: 18, color: "666666" }),
          ],
          spacing: { after: 120 },
        })
      );
    }
  }

  // Skills
  if (c.skills.length) {
    pushHeading(children, "SKILLS");
    children.push(
      new Paragraph({
        children: [new TextRun({ text: c.skills.join("  ·  "), size: 22 })],
        spacing: { after: 120 },
      })
    );
  }

  return new Document({
    styles: {
      default: {
        document: {
          run: { font: "Calibri" },
        },
      },
    },
    sections: [{ children }],
  });
}

function pushHeading(arr: Paragraph[], text: string) {
  arr.push(
    new Paragraph({
      children: [new TextRun({ text, bold: true, size: 18, color: "C44A1A" })],
      spacing: { before: 240, after: 60 },
      border: { bottom: { color: "C44A1A", size: 6, style: "single" } },
    })
  );
}
