import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import type { ResumeContent } from "@/types/resume";
import { z } from "zod";

const schema = z.object({ resumeId: z.string() });

// US Letter dimensions
const PAGE_W = 612;
const PAGE_H = 792;
const MARGIN_X = 56;
const MARGIN_TOP = 60;

const COLORS = {
  ink: rgb(0.106, 0.098, 0.086), // #1B1916
  inkSoft: rgb(0.227, 0.207, 0.176),
  inkMute: rgb(0.43, 0.4, 0.34),
  amber: rgb(0.769, 0.286, 0.102),
  rule: rgb(0.851, 0.812, 0.722),
};

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const resume = await db.resume.findUnique({ where: { id: parsed.data.resumeId } });
  if (!resume || resume.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const content = JSON.parse(resume.content) as ResumeContent;
  const bytes = await renderResumePdf(content);

  return new NextResponse(bytes as BodyInit, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${resume.title.replace(/[^a-z0-9-_]/gi, "_")}.pdf"`,
    },
  });
}

async function renderResumePdf(c: ResumeContent): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([PAGE_W, PAGE_H]);

  const fontReg = await pdf.embedFont(StandardFonts.TimesRoman);
  const fontBold = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const fontItalic = await pdf.embedFont(StandardFonts.TimesRomanItalic);
  const fontMono = await pdf.embedFont(StandardFonts.Courier);
  const fontMonoBold = await pdf.embedFont(StandardFonts.CourierBold);

  let y = PAGE_H - MARGIN_TOP;

  // === HEADER ===
  page.drawText(c.contact.name || "Untitled", {
    x: MARGIN_X, y, size: 22, font: fontBold, color: COLORS.ink,
  });
  y -= 18;

  if (c.contact.title) {
    page.drawText(c.contact.title.toUpperCase(), {
      x: MARGIN_X, y, size: 8, font: fontMono, color: COLORS.inkMute,
    });
    y -= 14;
  }

  const contact = [c.contact.email, c.contact.phone, c.contact.location, c.contact.website]
    .filter(Boolean).join("  ·  ");
  if (contact) {
    page.drawText(contact, { x: MARGIN_X, y, size: 9, font: fontReg, color: COLORS.inkSoft });
    y -= 14;
  }

  // Divider
  y -= 4;
  page.drawLine({
    start: { x: MARGIN_X, y },
    end: { x: PAGE_W - MARGIN_X, y },
    thickness: 0.8, color: COLORS.ink,
  });
  y -= 18;

  // === SUMMARY ===
  if (c.summary) {
    drawSectionHeading(page, "SUMMARY", y, fontMonoBold);
    y -= 14;
    y = drawWrappedText(page, c.summary, MARGIN_X, y, PAGE_W - MARGIN_X * 2, 10, fontReg, COLORS.inkSoft);
    y -= 14;
  }

  // === EXPERIENCE ===
  if (c.experience.length) {
    drawSectionHeading(page, "EXPERIENCE", y, fontMonoBold);
    y -= 14;

    for (const exp of c.experience) {
      // Title + company on left
      const titleStr = exp.company ? `${exp.title}, ` : exp.title;
      page.drawText(titleStr, {
        x: MARGIN_X, y, size: 10.5, font: fontBold, color: COLORS.ink,
      });
      const titleW = fontBold.widthOfTextAtSize(titleStr, 10.5);
      if (exp.company) {
        page.drawText(exp.company, {
          x: MARGIN_X + titleW, y, size: 10.5, font: fontItalic, color: COLORS.inkSoft,
        });
      }
      // Date on right
      const dateStr = `${exp.startDate}${exp.endDate ? ` — ${exp.endDate}` : ""}`.toUpperCase();
      const dateW = fontMono.widthOfTextAtSize(dateStr, 7.5);
      page.drawText(dateStr, {
        x: PAGE_W - MARGIN_X - dateW, y, size: 7.5, font: fontMono, color: COLORS.inkMute,
      });
      y -= 14;

      for (const b of exp.bullets) {
        page.drawText("•", { x: MARGIN_X + 6, y, size: 9, font: fontBold, color: COLORS.amber });
        y = drawWrappedText(page, b.text, MARGIN_X + 18, y, PAGE_W - MARGIN_X * 2 - 18, 9.5, fontReg, COLORS.inkSoft);
        y -= 4;
      }
      y -= 6;
    }
  }

  // === EDUCATION ===
  if (c.education.length && y > 100) {
    drawSectionHeading(page, "EDUCATION", y, fontMonoBold);
    y -= 14;

    for (const edu of c.education) {
      const degreeStr = edu.school ? `${edu.degree}, ` : edu.degree;
      page.drawText(degreeStr, { x: MARGIN_X, y, size: 10, font: fontBold, color: COLORS.ink });
      const degW = fontBold.widthOfTextAtSize(degreeStr, 10);
      if (edu.school) {
        page.drawText(edu.school, {
          x: MARGIN_X + degW, y, size: 10, font: fontItalic, color: COLORS.inkSoft,
        });
      }
      const dateStr = `${edu.startDate}${edu.endDate ? ` — ${edu.endDate}` : ""}`.toUpperCase();
      const dateW = fontMono.widthOfTextAtSize(dateStr, 7.5);
      page.drawText(dateStr, {
        x: PAGE_W - MARGIN_X - dateW, y, size: 7.5, font: fontMono, color: COLORS.inkMute,
      });
      y -= 14;
    }
    y -= 6;
  }

  // === SKILLS ===
  if (c.skills.length && y > 60) {
    drawSectionHeading(page, "SKILLS", y, fontMonoBold);
    y -= 14;
    y = drawWrappedText(page, c.skills.join("  ·  "), MARGIN_X, y, PAGE_W - MARGIN_X * 2, 9.5, fontReg, COLORS.inkSoft);
  }

  return pdf.save();
}

function drawSectionHeading(page: any, text: string, y: number, font: any) {
  page.drawText(text, {
    x: MARGIN_X, y, size: 8, font, color: COLORS.amber,
    characterSpacing: 1.2,
  });
}

// Word-wrap a string to fit a given width, returns the new y position
function drawWrappedText(
  page: any,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  size: number,
  font: any,
  color: any
): number {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (font.widthOfTextAtSize(test, size) > maxWidth) {
      if (line) lines.push(line);
      line = w;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);

  let currentY = y;
  for (const l of lines) {
    page.drawText(l, { x, y: currentY, size, font, color });
    currentY -= size + 3;
  }
  return currentY;
}
