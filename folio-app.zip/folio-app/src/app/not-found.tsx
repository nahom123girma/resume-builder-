import Link from "next/link";

export default function NotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center max-w-[480px]">
        <div className="font-serif italic text-amber text-[120px] leading-none mb-3">404.</div>
        <h1 className="font-serif text-[36px] font-normal tracking-tight leading-[1.05] mb-3">
          Page <em className="italic text-amber">not found</em>.
        </h1>
        <p className="text-ink-soft text-[15px] mb-7">
          The page you're looking for might have moved, been deleted, or never existed in the first place.
        </p>
        <div className="flex justify-center gap-2.5">
          <Link href="/" className="btn btn-ink">Go home</Link>
          <Link href="/dashboard" className="btn btn-outline">Open dashboard</Link>
        </div>
      </div>
    </main>
  );
}
