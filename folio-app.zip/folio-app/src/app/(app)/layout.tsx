import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { AppTopbar } from "@/components/layout/AppTopbar";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  return (
    <div className="grid grid-rows-[56px_1fr] h-screen overflow-hidden">
      <AppTopbar user={session.user} />
      <div className="grid grid-cols-[224px_1fr] overflow-hidden">
        <AppSidebar />
        <main className="overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
