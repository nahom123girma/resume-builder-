import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import { JobsView } from "@/components/jobs/JobsView";
import type { Job } from "@prisma/client";

export default async function JobsPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const jobs = await db.job.findMany({
    where: { userId: session.user.id },
    orderBy: { updatedAt: "desc" },
  });

  const grouped = {
    SAVED: jobs.filter((j: Job) => j.status === "SAVED"),
    APPLIED: jobs.filter((j: Job) => j.status === "APPLIED"),
    INTERVIEW: jobs.filter((j: Job) => j.status === "INTERVIEW"),
    OFFER: jobs.filter((j: Job) => j.status === "OFFER"),
    REJECTED: jobs.filter((j: Job) => j.status === "REJECTED"),
  };

  return <JobsView initial={grouped} />;
}
