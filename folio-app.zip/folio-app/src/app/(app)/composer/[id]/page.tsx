import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect, notFound } from "next/navigation";
import { ComposerWorkspace } from "@/components/composer/ComposerWorkspace";
import type { ResumeContent } from "@/types/resume";

export default async function ComposerEditorPage({
  params,
}: {
  params: { id: string };
}) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const resume = await db.resume.findUnique({
    where: { id: params.id },
  });
  if (!resume || resume.userId !== session.user.id) notFound();

  const content = JSON.parse(resume.content) as ResumeContent;

  return (
    <ComposerWorkspace
      resumeId={resume.id}
      title={resume.title}
      initialContent={content}
      atsScore={resume.atsScore}
    />
  );
}
