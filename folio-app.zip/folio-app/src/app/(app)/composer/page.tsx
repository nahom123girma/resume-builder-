import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import Link from "next/link";
import { formatDate } from "@/lib/utils";
import { NewResumeButton } from "@/components/composer/NewResumeButton";

export default async function ComposerIndex() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const resumes = await db.resume.findMany({
    where: { userId: session.user.id },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      title: true,
      templateId: true,
      themeColor: true,
      atsScore: true,
      updatedAt: true,
    },
  });

  return (
    <div className="px-9 py-8 pb-16 max-w-[1100px]">
      <div className="flex justify-between items-end mb-9 pb-7 border-b border-rule flex-wrap gap-4">
        <div>
          <div className="eyebrow mb-3.5">Composer</div>
          <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05] mb-1.5">
            Your <em className="italic text-amber">résumés</em>.
          </h1>
          <p className="text-ink-soft text-[15px]">
        {resumes.length === 0
          ? "Start with a template, or import an existing résumé."
          : `${resumes.length} ${resumes.length === 1 ? "résumé" : "résumés"} in your studio.`}
      </p>
        </div>
        <NewResumeButton />
      </div>

      {resumes.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {resumes.map((r: { id: string; title: string; templateId: string; themeColor: string; atsScore: number | null; updatedAt: Date }) => (
            <Link
              key={r.id}
              href={`/composer/${r.id}`}
              className="group bg-paper border border-rule rounded-xl p-5 transition-all hover:border-ink hover:-translate-y-0.5 hover:shadow-soft"
            >
              <div className="aspect-[8.5/11] bg-cream-2 border border-rule rounded-md mb-4 grid place-items-center">
                <div className="font-mono text-[10px] text-ink-mute uppercase tracking-[0.16em]">
                  {r.templateId}
                </div>
              </div>
              <div className="flex justify-between items-baseline mb-1.5">
                <h3 className="font-serif text-[17px] font-medium tracking-tight truncate group-hover:text-amber transition-colors">
                  {r.title}
                </h3>
                {r.atsScore != null && (
                  <span className="font-mono text-[11px] text-moss font-medium">
                    {r.atsScore}%
                  </span>
                )}
              </div>
              <div className="font-mono text-[11px] text-ink-mute">
                Updated {formatDate(r.updatedAt)}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="bg-paper border border-rule rounded-xl p-12 text-center">
      <div className="font-serif italic text-[42px] text-amber leading-none mb-4">i.</div>
      <h3 className="font-serif text-[22px] font-medium tracking-tight mb-2">
        No résumés yet.
      </h3>
      <p className="text-ink-soft text-[14px] max-w-[400px] mx-auto mb-6">
        Pick a template, paste in your existing résumé, or start from scratch with a sample to remix.
      </p>
      <NewResumeButton />
    </div>
  );
}
