import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import { SettingsForm } from "@/components/settings/SettingsForm";
import Link from "next/link";

export default async function SettingsPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const [user, aiUsageThisMonth, resumeCount] = await Promise.all([
    db.user.findUnique({
      where: { id: session.user.id },
      include: { subscription: true },
    }),
    db.aiUsage.aggregate({
      where: {
        userId: session.user.id,
        createdAt: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
      },
      _count: true,
      _sum: { costCents: true, inputTokens: true, outputTokens: true },
    }),
    db.resume.count({ where: { userId: session.user.id } }),
  ]);
  if (!user) redirect("/login");

  const usageCount = aiUsageThisMonth._count ?? 0;
  const usageCostCents = aiUsageThisMonth._sum?.costCents ?? 0;

  return (
    <div className="px-9 py-8 pb-16 max-w-[820px]">
      <div className="mb-9 pb-7 border-b border-rule">
        <div className="eyebrow mb-3.5">Settings</div>
        <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05]">
          Your <em className="italic text-amber">studio</em>.
        </h1>
      </div>

      {/* Account */}
      <section className="mb-9">
        <h2 className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-ink-mute font-medium mb-3.5">
          Account
        </h2>
        <div className="bg-paper border border-rule rounded-xl p-6">
          <SettingsForm user={{ id: user.id, name: user.name ?? "", email: user.email }} />
        </div>
      </section>

      {/* Plan */}
      <section className="mb-9">
        <h2 className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-ink-mute font-medium mb-3.5">
          Plan
        </h2>
        <div className="bg-paper border border-rule rounded-xl p-6 flex items-center justify-between gap-5 flex-wrap">
          <div>
            <div className="flex items-baseline gap-2.5">
              <span className="font-serif text-[26px] font-medium tracking-tight">{user.plan}</span>
              {user.subscription?.currentPeriodEnd && (
                <span className="font-mono text-[11px] text-ink-mute uppercase tracking-[0.06em]">
                  · renews {user.subscription.currentPeriodEnd.toLocaleDateString()}
                </span>
              )}
            </div>
            <p className="text-[13px] text-ink-soft mt-1">
              {user.plan === "FREE"
                ? "3 résumés, 5 PDF conversions/mo, 20 AI calls/mo."
                : "Unlimited résumés, unlimited PDF tools, 1,000 AI calls/mo."}
            </p>
          </div>
          {user.plan === "FREE" ? (
            <Link href="/pricing" className="btn btn-amber">Upgrade to Pro</Link>
          ) : (
            <Link href="/pricing" className="btn btn-outline">Manage subscription</Link>
          )}
        </div>
      </section>

      {/* Usage */}
      <section className="mb-9">
        <h2 className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-ink-mute font-medium mb-3.5">
          Usage this month
        </h2>
        <div className="grid grid-cols-3 gap-3">
          <UsageCard label="AI calls" value={usageCount.toString()} />
          <UsageCard label="Résumés stored" value={resumeCount.toString()} />
          <UsageCard label="AI cost (est)" value={`$${(usageCostCents / 100).toFixed(2)}`} />
        </div>
      </section>

      {/* Danger zone */}
      <section>
        <h2 className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-brick font-medium mb-3.5">
          Danger zone
        </h2>
        <div className="bg-paper border border-brick/30 rounded-xl p-6 flex items-center justify-between gap-5 flex-wrap">
          <div>
            <div className="font-serif text-[16px] font-medium mb-1">Delete account</div>
            <p className="text-[13px] text-ink-soft">
              Permanently remove your account, résumés, jobs, and letters. Can't be undone.
            </p>
          </div>
          <DeleteButton />
        </div>
      </section>
    </div>
  );
}

function UsageCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-paper border border-rule rounded-xl p-5">
      <div className="font-serif italic text-[13px] text-ink-soft mb-2">{label}</div>
      <div className="font-serif text-[32px] font-medium tracking-[-0.04em] leading-none">{value}</div>
    </div>
  );
}

function DeleteButton() {
  return (
    <form action="/api/account/delete" method="POST">
      <button
        type="submit"
        formNoValidate
        className="btn border-brick text-brick hover:bg-brick hover:text-paper"
      >
        Delete account
      </button>
    </form>
  );
}
