export default function Loading() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-ink-mute">
          Folio · Loading
        </div>
        <div className="flex gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber animate-pulse-soft" />
          <span className="w-2 h-2 rounded-full bg-amber animate-pulse-soft" style={{ animationDelay: "0.15s" }} />
          <span className="w-2 h-2 rounded-full bg-amber animate-pulse-soft" style={{ animationDelay: "0.3s" }} />
        </div>
      </div>
    </div>
  );
}
