"use client";

import { useState } from "react";
import Link from "next/link";

export default function MergePdfPage() {
  const [files, setFiles] = useState<File[]>([]);
  const [merging, setMerging] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  function onPick(picked: FileList | null) {
    if (!picked) return;
    setFiles((prev) => [...prev, ...Array.from(picked).filter((f) => f.type === "application/pdf")]);
  }

  function move(idx: number, dir: -1 | 1) {
    setFiles((prev) => {
      const next = [...prev];
      const target = idx + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[idx], next[target]] = [next[target], next[idx]];
      return next;
    });
  }

  async function doMerge() {
    if (files.length < 2) return;
    setMerging(true);
    const fd = new FormData();
    files.forEach((f) => fd.append("files", f));

    const res = await fetch("/api/pdf/merge", { method: "POST", body: fd });
    if (!res.ok) {
      setMerging(false);
      alert("Merge failed");
      return;
    }
    const blob = await res.blob();
    setResultUrl(URL.createObjectURL(blob));
    setMerging(false);
  }

  return (
    <div className="px-9 py-8 pb-16 max-w-[760px]">
      <Link href="/pdf-tools" className="font-mono text-[11px] uppercase tracking-[0.12em] text-ink-mute hover:text-amber mb-6 inline-block">
        ← All PDF tools
      </Link>

      <div className="mb-7 pb-6 border-b border-rule">
        <div className="eyebrow mb-3.5">PDF Tool · 01</div>
        <h1 className="font-serif text-[40px] font-normal tracking-tight leading-[1.05] mb-1.5">
          Merge <em className="italic text-amber">PDFs</em>.
        </h1>
        <p className="text-ink-soft text-[15px]">
          Drop PDF files below. Drag to reorder. Click merge.
        </p>
      </div>

      <label className="block bg-paper border-2 border-dashed border-rule rounded-xl p-10 text-center cursor-pointer hover:border-ink transition-colors mb-6">
        <input
          type="file"
          accept="application/pdf"
          multiple
          className="hidden"
          onChange={(e) => onPick(e.target.files)}
        />
        <div className="font-serif italic text-[18px] mb-1">Drop PDFs here</div>
        <div className="text-[13px] text-ink-mute">or click to browse</div>
      </label>

      {files.length > 0 && (
        <div className="bg-paper border border-rule rounded-xl p-3 mb-6 flex flex-col gap-1.5">
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-3 px-3 py-2 hover:bg-cream-2 rounded">
              <span className="font-mono text-[10px] text-ink-mute w-6">{String(i + 1).padStart(2, "0")}</span>
              <span className="flex-1 truncate text-[14px]">{f.name}</span>
              <span className="font-mono text-[10.5px] text-ink-mute">{Math.round(f.size / 1024)} KB</span>
              <div className="flex gap-1">
                <button onClick={() => move(i, -1)} disabled={i === 0} className="text-ink-mute hover:text-ink disabled:opacity-30 px-1">↑</button>
                <button onClick={() => move(i, 1)} disabled={i === files.length - 1} className="text-ink-mute hover:text-ink disabled:opacity-30 px-1">↓</button>
                <button onClick={() => setFiles((prev) => prev.filter((_, j) => j !== i))} className="text-ink-mute hover:text-brick px-1">✕</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-end gap-2">
        <button
          onClick={doMerge}
          disabled={files.length < 2 || merging}
          className="btn btn-amber disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {merging ? "Merging…" : `Merge ${files.length} files`}
        </button>
      </div>

      {resultUrl && (
        <div className="mt-6 bg-moss-soft border border-moss/30 rounded-xl p-5 flex items-center justify-between">
          <div>
            <div className="font-serif text-[16px] font-medium mb-0.5">Merge complete.</div>
            <div className="text-[13px] text-ink-soft">Your file is ready to download.</div>
          </div>
          <a href={resultUrl} download="merged.pdf" className="btn btn-ink">Download PDF</a>
        </div>
      )}
    </div>
  );
}
