import Link from "next/link";

const TOOLS = [
  { slug: "merge", title: "Merge PDFs", desc: "Combine many files into one. Reorder before merging.", num: "№ 01", status: "live" },
  { slug: "split", title: "Split PDF", desc: "Extract pages or break into sections.", num: "№ 02", status: "live" },
  { slug: "compress", title: "Compress PDF", desc: "Shrink file size without losing fidelity.", num: "№ 03", status: "soon" },
  { slug: "pdf-to-word", title: "PDF to Word", desc: "Editable .docx, formatting preserved.", num: "№ 04", status: "soon" },
  { slug: "word-to-pdf", title: "Word to PDF", desc: "Convert .doc/.docx to printable PDF.", num: "№ 05", status: "soon" },
  { slug: "ocr", title: "OCR Scanner", desc: "Make a scanned PDF searchable and selectable.", num: "№ 06", status: "soon" },
  { slug: "sign", title: "Sign PDF", desc: "Add a signature, date, and initials in the right places.", num: "№ 07", status: "soon" },
];

export default function PdfToolsHubPage() {
  return (
    <div className="px-9 py-8 pb-16 max-w-[1100px]">
      <div className="mb-9 pb-7 border-b border-rule">
        <div className="eyebrow mb-3.5">PDF Tools</div>
        <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05] mb-1.5">
          Surgical <em className="italic text-amber">PDF tools</em>.
        </h1>
        <p className="text-ink-soft text-[15px] max-w-[520px]">
          Each tool does one thing well. No banner ads, no upsell flows, no waiting-room timers.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {TOOLS.map((tool) => {
          const live = tool.status === "live";
          const Inner = (
            <div className={`bg-paper border border-rule rounded-xl p-5 h-full transition-all ${live ? "hover:border-ink hover:-translate-y-0.5 hover:shadow-soft cursor-pointer" : "opacity-70"}`}>
              <div className="flex justify-between items-baseline mb-3">
                <span className="font-mono text-[10px] tracking-[0.16em] uppercase text-ink-mute">{tool.num}</span>
                <span className={`font-mono text-[9.5px] tracking-[0.12em] uppercase font-medium ${live ? "text-moss" : "text-clay"}`}>
                  {live ? "● LIVE" : "○ SOON"}
                </span>
              </div>
              <h3 className="font-serif text-[20px] font-medium tracking-tight mb-2">{tool.title}</h3>
              <p className="text-ink-soft text-[13.5px] leading-relaxed">{tool.desc}</p>
            </div>
          );
          return live ? (
            <Link key={tool.slug} href={`/pdf-tools/${tool.slug}`}>{Inner}</Link>
          ) : (
            <div key={tool.slug}>{Inner}</div>
          );
        })}
      </div>
    </div>
  );
}
