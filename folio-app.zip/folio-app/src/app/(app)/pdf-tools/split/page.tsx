"use client";

import { useState } from "react";
import Link from "next/link";

export default function SplitPdfPage() {
  const [file, setFile] = useState<File | null>(null);
  const [pageRange, setPageRange] = useState("1-3, 5, 7-10");
  const [splitting, setSplitting] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  async function doSplit() {
    if (!file) return;
    setSplitting(true);
    const fd = new FormData();
    fd.append("file", file);
    fd.append("pages", pageRange);

    const res = await fetch("/api/pdf/split", { method: "POST", body: fd });
    if (!res.ok) {
      setSplitting(false);
      const j = await res.json();
      alert(j.error ?? "Split failed");
      return;
    }
    const blob = await res.blob();
    setResultUrl(URL.createObjectURL(blob));
    setSplitting(false);
  }

  return (
    <div className="px-9 py-8 pb-16 max-w-[680px]">
      <Link href="/pdf-tools" className="font-mono text-[11px] uppercase tracking-[0.12em] text-ink-mute hover:text-amber mb-6 inline-block">
        ← All PDF tools
      </Link>

      <div className="mb-7 pb-6 border-b border-rule">
        <div className="eyebrow mb-3.5">PDF Tool · 02</div>
        <h1 className="font-serif text-[40px] font-normal tracking-tight leading-[1.05] mb-1.5">
          Split <em className="italic text-amber">PDF</em>.
        </h1>
        <p className="text-ink-soft text-[15px]">Extract specific pages from a PDF.</p>
      </div>

      <label className="block bg-paper border-2 border-dashed border-rule rounded-xl p-10 text-center cursor-pointer hover:border-ink transition-colors mb-5">
        <input
          type="file"
          accept="application/pdf"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
        />
        {file ? (
          <div>
            <div className="font-serif text-[16px] font-medium">{file.name}</div>
            <div className="text-[12px] text-ink-mute mt-1">{Math.round(file.size / 1024)} KB · click to change</div>
          </div>
        ) : (
          <>
            <div className="font-serif italic text-[18px] mb-1">Drop a PDF here</div>
            <div className="text-[13px] text-ink-mute">or click to browse</div>
          </>
        )}
      </label>

      <div className="bg-paper border border-rule rounded-xl p-5 mb-5">
        <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute mb-2 block">
          Pages to extract
        </label>
        <input
          value={pageRange}
          onChange={(e) => setPageRange(e.target.value)}
          placeholder="1-3, 5, 7-10"
          className="w-full bg-cream-2 border border-rule rounded-md px-3 py-2 text-[14px] font-mono focus:border-ink outline-none"
        />
        <p className="text-[12px] text-ink-mute font-serif italic mt-2">
          Use ranges (1-5) or single pages (7), separated by commas.
        </p>
      </div>

      <div className="flex justify-end gap-2">
        <button
          onClick={doSplit}
          disabled={!file || splitting}
          className="btn btn-amber disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {splitting ? "Splitting…" : "Extract pages"}
        </button>
      </div>

      {resultUrl && (
        <div className="mt-6 bg-moss-soft border border-moss/30 rounded-xl p-5 flex items-center justify-between">
          <div>
            <div className="font-serif text-[16px] font-medium mb-0.5">Done.</div>
            <div className="text-[13px] text-ink-soft">Pages extracted to a new PDF.</div>
          </div>
          <a href={resultUrl} download="split.pdf" className="btn btn-ink">Download PDF</a>
        </div>
      )}
    </div>
  );
}
