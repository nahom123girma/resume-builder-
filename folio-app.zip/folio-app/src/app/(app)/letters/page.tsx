import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import Link from "next/link";
import { formatDate } from "@/lib/utils";
import { LettersGenerator } from "@/components/letters/LettersGenerator";

export default async function LettersPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const [letters, resumes] = await Promise.all([
    db.coverLetter.findMany({
      where: { userId: session.user.id },
      orderBy: { updatedAt: "desc" },
    }),
    db.resume.findMany({
      where: { userId: session.user.id },
      select: { id: true, title: true },
      orderBy: { updatedAt: "desc" },
    }),
  ]);

  return (
    <div className="px-9 py-8 pb-16 max-w-[1100px]">
      <div className="flex justify-between items-end mb-9 pb-7 border-b border-rule flex-wrap gap-4">
        <div>
          <div className="eyebrow mb-3.5">Cover letters</div>
          <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05] mb-1.5">
            The <em className="italic text-amber">letter</em> studio.
          </h1>
          <p className="text-ink-soft text-[15px]">
            Paste a job description, pick a résumé, get a draft in your voice.
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_1.2fr] gap-7">
        <LettersGenerator resumes={resumes} />

        <div>
          <h2 className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-ink-mute font-medium mb-3.5">
            Your letters
          </h2>
          {letters.length === 0 ? (
            <div className="bg-paper border border-dashed border-rule rounded-xl p-9 text-center">
              <div className="font-serif italic text-[15px] text-ink-mute mb-1">No letters yet.</div>
              <div className="text-[13px] text-ink-mute">Use the generator to create your first one.</div>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {letters.map((l: { id: string; title: string; content: string; updatedAt: Date }) => (
                <Link
                  key={l.id}
                  href={`/letters/${l.id}`}
                  className="block bg-paper border border-rule rounded-xl p-4 hover:border-ink hover:shadow-soft transition-all"
                >
                  <div className="flex justify-between items-baseline mb-1.5">
                    <h3 className="font-serif text-[15px] font-medium tracking-tight truncate flex-1">
                      {l.title}
                    </h3>
                    <span className="font-mono text-[10.5px] text-ink-mute uppercase tracking-[0.06em] ml-3">
                      {formatDate(l.updatedAt)}
                    </span>
                  </div>
                  <p className="text-[12.5px] text-ink-mute font-serif italic line-clamp-2">
                    {l.content.slice(0, 180)}…
                  </p>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
