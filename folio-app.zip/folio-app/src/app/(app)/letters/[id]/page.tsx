import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect, notFound } from "next/navigation";
import { LetterEditor } from "@/components/letters/LetterEditor";

export default async function LetterPage({ params }: { params: { id: string } }) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const letter = await db.coverLetter.findUnique({ where: { id: params.id } });
  if (!letter || letter.userId !== session.user.id) notFound();

  return (
    <LetterEditor
      letterId={letter.id}
      initialTitle={letter.title}
      initialContent={letter.content}
    />
  );
}
