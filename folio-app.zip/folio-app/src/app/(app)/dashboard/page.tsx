import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import { Stats } from "@/components/dashboard/Stats";
import { Kanban } from "@/components/dashboard/Kanban";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { AssistantPanel } from "@/components/dashboard/AssistantPanel";
import type { Job } from "@prisma/client";
import Link from "next/link";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const [jobs, resumes, aiUsage] = await Promise.all([
    db.job.findMany({
      where: { userId: session.user.id },
      orderBy: { updatedAt: "desc" },
    }),
    db.resume.findMany({
      where: { userId: session.user.id },
      select: { id: true, title: true, atsScore: true, updatedAt: true },
    }),
    db.aiUsage.count({
      where: {
        userId: session.user.id,
        createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
      },
    }),
  ]);

  const groupedJobs = {
    SAVED: jobs.filter((j: Job) => j.status === "SAVED"),
    APPLIED: jobs.filter((j: Job) => j.status === "APPLIED"),
    INTERVIEW: jobs.filter((j: Job) => j.status === "INTERVIEW"),
    OFFER: jobs.filter((j: Job) => j.status === "OFFER"),
    REJECTED: jobs.filter((j: Job) => j.status === "REJECTED"),
  };

  // Compute stats
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const appliedThisWeek = jobs.filter((j: Job) => j.appliedAt && j.appliedAt >= sevenDaysAgo).length;
  const interviewsThisWeek = jobs.filter(
    (j: Job) => j.interviewAt && j.interviewAt >= sevenDaysAgo
  ).length;
  const responseRate = jobs.length > 0
    ? Math.round((groupedJobs.INTERVIEW.length + groupedJobs.OFFER.length) / Math.max(jobs.length, 1) * 100)
    : 0;
  const avgScore = resumes.length > 0
    ? Math.round(resumes.reduce((s: number, r: { atsScore: number | null }) => s + (r.atsScore ?? 0), 0) / resumes.length)
    : 0;

  const firstName = session.user.name?.split(" ")[0] ?? session.user.email.split("@")[0];
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });

  return (
    <div className="px-9 py-8 pb-16">
      <div className="flex justify-between items-end mb-9 pb-7 border-b border-rule flex-wrap gap-4">
        <div>
          <div className="eyebrow mb-3.5">{today}</div>
          <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05] mb-1.5">
            Welcome back, <em className="italic text-amber">{firstName}</em>.
          </h1>
          <p className="text-ink-soft text-[15px] max-w-[420px]">
            You have <strong className="text-ink font-medium">{interviewsThisWeek} interviews</strong> scheduled this week and <em className="italic text-amber">{resumes.length} résumés</em> in your studio.
          </p>
        </div>
        <div className="flex gap-2.5">
          <Link href="/jobs/new" className="btn btn-outline">Import job</Link>
          <Link href="/composer/new" className="btn btn-amber">+ New résumé</Link>
        </div>
      </div>

      <Stats
        applied={appliedThisWeek}
        responseRate={responseRate}
        interviews={interviewsThisWeek}
        avgScore={avgScore}
      />

      <Kanban jobs={groupedJobs} />

      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-5 mt-9">
        <ActivityFeed jobs={jobs.slice(0, 5)} />
        <AssistantPanel />
      </div>
    </div>
  );
}
