import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { AssistantChat } from "@/components/assistant/AssistantChat";

export default async function AssistantPage({
  searchParams,
}: {
  searchParams: { q?: string };
}) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  return <AssistantChat initialPrompt={searchParams.q ?? ""} />;
}
