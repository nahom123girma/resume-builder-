"use client";

import Link from "next/link";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body>
        <main className="min-h-screen flex items-center justify-center px-6 bg-cream">
          <div className="text-center max-w-[480px]">
            <div className="font-mono text-[11px] tracking-[0.16em] uppercase text-brick mb-4">
              ✕ Something went wrong
            </div>
            <h1 className="font-serif text-[32px] font-normal tracking-tight leading-[1.05] mb-3">
              Hit an <em className="italic text-amber">unexpected error</em>.
            </h1>
            <p className="text-ink-soft text-[14px] mb-2 font-serif">
              The error has been logged. You can try again, or head somewhere safe.
            </p>
            {error.digest && (
              <p className="font-mono text-[10.5px] text-ink-mute mb-7 tracking-[0.06em]">
                ref · {error.digest}
              </p>
            )}
            <div className="flex justify-center gap-2.5">
              <button onClick={() => reset()} className="btn btn-amber">Try again</button>
              <Link href="/" className="btn btn-outline">Go home</Link>
            </div>
          </div>
        </main>
      </body>
    </html>
  );
}
