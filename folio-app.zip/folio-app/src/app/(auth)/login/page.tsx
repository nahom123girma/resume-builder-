"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const result = await signIn("credentials", {
      email: formData.get("email") as string,
      password: formData.get("password") as string,
      redirect: false,
    });

    if (result?.error) {
      setError("Invalid email or password");
      setLoading(false);
      return;
    }
    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-[420px]">
        <Link href="/" className="flex items-baseline gap-1.5 font-serif text-3xl font-semibold tracking-tighter mb-10">
          Folio<span className="self-center w-2 h-2 rounded-full bg-amber inline-block ml-0.5" />
        </Link>

        <h1 className="font-serif text-4xl font-normal tracking-tight mb-2">
          Welcome <em className="italic text-amber">back</em>.
        </h1>
        <p className="text-ink-soft mb-8">Log in to pick up where you left off.</p>

        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="font-mono text-[11px] uppercase tracking-[0.04em] font-medium text-ink-soft">Email</label>
            <input name="email" type="email" required autoComplete="email"
              className="bg-paper border border-rule rounded-md px-3 py-2.5 text-[14px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition" />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="font-mono text-[11px] uppercase tracking-[0.04em] font-medium text-ink-soft">Password</label>
            <input name="password" type="password" required autoComplete="current-password"
              className="bg-paper border border-rule rounded-md px-3 py-2.5 text-[14px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition" />
          </div>

          {error && (
            <div className="bg-amber-soft border border-amber rounded-md p-3 text-sm text-amber-deep">{error}</div>
          )}

          <button type="submit" disabled={loading} className="btn btn-amber w-full justify-center py-3 mt-2 disabled:opacity-60">
            {loading ? "Logging in…" : "Log in"}
          </button>
        </form>

        <p className="text-sm text-ink-soft text-center mt-6">
          Need an account?{" "}
          <Link href="/signup" className="text-amber border-b border-amber">Sign up</Link>
        </p>
      </div>
    </main>
  );
}
