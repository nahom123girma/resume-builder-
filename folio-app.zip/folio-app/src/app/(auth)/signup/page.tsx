"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";

export default function SignupPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      password: formData.get("password") as string,
    };

    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const j = await res.json();
      setError(j.error ?? "Signup failed");
      setLoading(false);
      return;
    }

    // Auto-sign in
    await signIn("credentials", {
      email: data.email,
      password: data.password,
      redirect: false,
    });
    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-[420px]">
        <Link href="/" className="flex items-baseline gap-1.5 font-serif text-3xl font-semibold tracking-tighter mb-10">
          Folio<span className="self-center w-2 h-2 rounded-full bg-amber inline-block ml-0.5" />
        </Link>

        <h1 className="font-serif text-4xl font-normal tracking-tight mb-2">
          Create your <em className="italic text-amber">account</em>.
        </h1>
        <p className="text-ink-soft mb-8">Free forever for the basics. Seven days free for everything.</p>

        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <Field label="Name" name="name" type="text" required autoComplete="name" />
          <Field label="Email" name="email" type="email" required autoComplete="email" />
          <Field label="Password" name="password" type="password" required minLength={8} autoComplete="new-password" />

          {error && (
            <div className="bg-amber-soft border border-amber rounded-md p-3 text-sm text-amber-deep">
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn btn-amber w-full justify-center py-3 mt-2 disabled:opacity-60">
            {loading ? "Creating…" : "Create account"}
          </button>
        </form>

        <p className="text-sm text-ink-soft text-center mt-6">
          Already have an account?{" "}
          <Link href="/login" className="text-amber border-b border-amber">Log in</Link>
        </p>
      </div>
    </main>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[11px] uppercase tracking-[0.04em] font-medium text-ink-soft">{label}</label>
      <input
        {...props}
        className="bg-paper border border-rule rounded-md px-3 py-2.5 text-[14px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
      />
    </div>
  );
}
