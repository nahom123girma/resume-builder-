import type { ResumeContent } from "@/types/resume";

export function ResumePreview({ content }: { content: ResumeContent }) {
  return (
    <article className="bg-white shadow-lg aspect-[8.5/11] overflow-hidden font-serif p-[60px_56px] text-ink relative">
      {/* Header */}
      <header className="border-b border-ink pb-3 mb-5">
        <h1 className="font-serif text-[32px] font-medium tracking-tight leading-none mb-1">
          {content.contact.name || "Your name"}
        </h1>
        <div className="font-mono text-[10px] tracking-[0.16em] uppercase text-ink-mute mb-2">
          {content.contact.title || "Your title"}
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-[10.5px] text-ink-soft">
          {content.contact.email && <span>{content.contact.email}</span>}
          {content.contact.phone && <span>· {content.contact.phone}</span>}
          {content.contact.location && <span>· {content.contact.location}</span>}
          {content.contact.website && <span>· {content.contact.website}</span>}
        </div>
      </header>

      {/* Summary */}
      {content.summary && (
        <Section heading="Summary">
          <p className="text-[12px] leading-snug text-ink-soft">{content.summary}</p>
        </Section>
      )}

      {/* Experience */}
      {content.experience.length > 0 && (
        <Section heading="Experience">
          <div className="flex flex-col gap-3.5">
            {content.experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline mb-0.5">
                  <div className="font-medium text-[12.5px]">
                    {exp.title}{exp.company && <>, <span className="italic font-normal text-ink-soft">{exp.company}</span></>}
                  </div>
                  <div className="font-mono text-[9.5px] text-ink-mute uppercase tracking-wider">
                    {exp.startDate}{exp.endDate && ` — ${exp.endDate}`}
                  </div>
                </div>
                {exp.bullets.length > 0 && (
                  <ul className="mt-1.5 space-y-1 text-[11px] leading-snug text-ink-soft">
                    {exp.bullets.map((b) => (
                      <li key={b.id} className="flex gap-2">
                        <span className="text-amber">▸</span>
                        <span>{b.text}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Education */}
      {content.education.length > 0 && (
        <Section heading="Education">
          <div className="flex flex-col gap-2">
            {content.education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-baseline">
                <div className="text-[12px]">
                  <span className="font-medium">{edu.degree}</span>
                  {edu.school && <span className="italic text-ink-soft">, {edu.school}</span>}
                </div>
                <div className="font-mono text-[9.5px] text-ink-mute uppercase tracking-wider">
                  {edu.startDate}{edu.endDate && ` — ${edu.endDate}`}
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Skills */}
      {content.skills.length > 0 && (
        <Section heading="Skills">
          <div className="text-[11px] leading-snug text-ink-soft">
            {content.skills.join(" · ")}
          </div>
        </Section>
      )}
    </article>
  );
}

function Section({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section className="mb-4">
      <h2 className="font-mono text-[9.5px] tracking-[0.18em] uppercase text-amber font-medium mb-1.5">
        {heading}
      </h2>
      {children}
    </section>
  );
}
