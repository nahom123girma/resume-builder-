"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import type { ResumeContent, ExperienceEntry, EducationEntry } from "@/types/resume";
import { ResumePreview } from "./ResumePreview";

interface Props {
  resumeId: string;
  title: string;
  initialContent: ResumeContent;
  atsScore: number | null;
}

type SaveState = "saved" | "saving" | "dirty" | "error";

export function ComposerWorkspace({ resumeId, title: initialTitle, initialContent, atsScore: initialScore }: Props) {
  const router = useRouter();
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState<ResumeContent>(initialContent);
  const [saveState, setSaveState] = useState<SaveState>("saved");
  const [score, setScore] = useState<number | null>(initialScore);
  const [scoring, setScoring] = useState(false);
  const saveTimer = useRef<NodeJS.Timeout | null>(null);

  // Debounced auto-save
  const triggerSave = useCallback((nextTitle: string, nextContent: ResumeContent) => {
    setSaveState("dirty");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaveState("saving");
      try {
        const res = await fetch(`/api/resumes/${resumeId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: nextTitle,
            content: JSON.stringify(nextContent),
          }),
        });
        setSaveState(res.ok ? "saved" : "error");
      } catch {
        setSaveState("error");
      }
    }, 700);
  }, [resumeId]);

  function update(next: ResumeContent) {
    setContent(next);
    triggerSave(title, next);
  }

  function updateTitle(next: string) {
    setTitle(next);
    triggerSave(next, content);
  }

  // Update contact info
  function updateContact<K extends keyof ResumeContent["contact"]>(key: K, value: ResumeContent["contact"][K]) {
    update({ ...content, contact: { ...content.contact, [key]: value } });
  }

  // Update summary
  async function aiRewriteSummary() {
    if (!content.summary) return;
    const res = await fetch("/api/ai/rewrite", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "summary", text: content.summary, role: content.contact.title }),
    });
    if (res.ok) {
      const { text } = await res.json();
      update({ ...content, summary: text });
    }
  }

  async function aiRewriteBullet(expId: string, bulletId: string) {
    const exp = content.experience.find((e) => e.id === expId);
    const bullet = exp?.bullets.find((b) => b.id === bulletId);
    if (!bullet) return;

    const res = await fetch("/api/ai/rewrite", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "bullet", text: bullet.text }),
    });
    if (!res.ok) return;
    const { text } = await res.json();
    update({
      ...content,
      experience: content.experience.map((e) =>
        e.id !== expId
          ? e
          : { ...e, bullets: e.bullets.map((b) => (b.id !== bulletId ? b : { ...b, text })) }
      ),
    });
  }

  async function runAtsScore() {
    setScoring(true);
    const res = await fetch("/api/ai/score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resumeId }),
    });
    if (res.ok) {
      const data = await res.json();
      if (typeof data.score === "number") setScore(data.score);
    }
    setScoring(false);
  }

  // Experience handlers
  function addExperience() {
    const newExp: ExperienceEntry = {
      id: `exp-${Date.now()}`,
      title: "",
      company: "",
      startDate: "",
      endDate: "Present",
      bullets: [],
    };
    update({ ...content, experience: [...content.experience, newExp] });
  }

  function updateExperience(id: string, patch: Partial<ExperienceEntry>) {
    update({
      ...content,
      experience: content.experience.map((e) => (e.id === id ? { ...e, ...patch } : e)),
    });
  }

  function removeExperience(id: string) {
    update({ ...content, experience: content.experience.filter((e) => e.id !== id) });
  }

  function addBullet(expId: string) {
    update({
      ...content,
      experience: content.experience.map((e) =>
        e.id !== expId
          ? e
          : { ...e, bullets: [...e.bullets, { id: `b-${Date.now()}`, text: "" }] }
      ),
    });
  }

  function updateBullet(expId: string, bulletId: string, text: string) {
    update({
      ...content,
      experience: content.experience.map((e) =>
        e.id !== expId
          ? e
          : { ...e, bullets: e.bullets.map((b) => (b.id !== bulletId ? b : { ...b, text })) }
      ),
    });
  }

  function removeBullet(expId: string, bulletId: string) {
    update({
      ...content,
      experience: content.experience.map((e) =>
        e.id !== expId ? e : { ...e, bullets: e.bullets.filter((b) => b.id !== bulletId) }
      ),
    });
  }

  function addEducation() {
    const e: EducationEntry = {
      id: `edu-${Date.now()}`,
      degree: "",
      school: "",
      startDate: "",
      endDate: "",
    };
    update({ ...content, education: [...content.education, e] });
  }

  function updateEducation(id: string, patch: Partial<EducationEntry>) {
    update({ ...content, education: content.education.map((e) => (e.id === id ? { ...e, ...patch } : e)) });
  }

  function removeEducation(id: string) {
    update({ ...content, education: content.education.filter((e) => e.id !== id) });
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] h-full">
      {/* LEFT: Editor */}
      <div className="border-r border-rule overflow-y-auto px-8 py-7 pb-20">
        <div className="flex items-center justify-between mb-6 sticky top-0 bg-cream/95 backdrop-blur-md -mx-8 px-8 py-3 -mt-7 z-10 border-b border-rule">
          <input
            value={title}
            onChange={(e) => updateTitle(e.target.value)}
            className="font-serif text-2xl font-medium tracking-tight bg-transparent border-0 outline-none focus:ring-0 max-w-[60%] truncate"
          />
          <div className="flex items-center gap-3">
            <SaveIndicator state={saveState} />
            <button
              onClick={runAtsScore}
              disabled={scoring}
              className="btn btn-outline text-xs disabled:opacity-60"
            >
              {scoring ? "Scoring…" : score != null ? `${score}% · Re-score` : "Run ATS check"}
            </button>
          </div>
        </div>

        {/* Contact section */}
        <Section title="Contact">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Name" value={content.contact.name} onChange={(v) => updateContact("name", v)} />
            <Field label="Title" value={content.contact.title} onChange={(v) => updateContact("title", v)} />
            <Field label="Email" value={content.contact.email} onChange={(v) => updateContact("email", v)} type="email" />
            <Field label="Phone" value={content.contact.phone ?? ""} onChange={(v) => updateContact("phone", v)} />
            <Field label="Location" value={content.contact.location ?? ""} onChange={(v) => updateContact("location", v)} />
            <Field label="Website" value={content.contact.website ?? ""} onChange={(v) => updateContact("website", v)} />
          </div>
        </Section>

        {/* Summary */}
        <Section
          title="Summary"
          action={
            content.summary ? (
              <AiButton onClick={aiRewriteSummary} label="Rewrite with AI" />
            ) : null
          }
        >
          <Textarea
            value={content.summary ?? ""}
            onChange={(v) => update({ ...content, summary: v })}
            placeholder="A short paragraph about who you are and what you do."
            rows={4}
          />
        </Section>

        {/* Experience */}
        <Section
          title="Experience"
          action={<button onClick={addExperience} className="text-xs font-mono uppercase tracking-wider text-amber hover:text-amber-deep">+ Add role</button>}
        >
          <div className="flex flex-col gap-5">
            {content.experience.map((exp) => (
              <div key={exp.id} className="bg-paper border border-rule rounded-xl p-4">
                <div className="flex justify-between items-start gap-3 mb-3">
                  <div className="grid grid-cols-2 gap-2 flex-1">
                    <Field label="Title" value={exp.title} onChange={(v) => updateExperience(exp.id, { title: v })} />
                    <Field label="Company" value={exp.company} onChange={(v) => updateExperience(exp.id, { company: v })} />
                    <Field label="Start" value={exp.startDate} onChange={(v) => updateExperience(exp.id, { startDate: v })} />
                    <Field label="End" value={exp.endDate} onChange={(v) => updateExperience(exp.id, { endDate: v })} />
                  </div>
                  <button
                    onClick={() => removeExperience(exp.id)}
                    className="text-[11px] text-ink-mute hover:text-brick mt-5"
                    title="Remove role"
                  >
                    ✕
                  </button>
                </div>
                <div className="flex flex-col gap-2">
                  {exp.bullets.map((b) => (
                    <div key={b.id} className="flex items-start gap-2 group">
                      <span className="text-amber text-[12px] mt-2.5">▸</span>
                      <textarea
                        value={b.text}
                        onChange={(e) => updateBullet(exp.id, b.id, e.target.value)}
                        rows={2}
                        className="flex-1 bg-cream-2 border border-rule rounded-md px-2.5 py-2 text-[13.5px] font-serif resize-none focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
                        placeholder="Quantified accomplishment, action verb first…"
                      />
                      <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => aiRewriteBullet(exp.id, b.id)}
                          className="text-[10px] font-mono uppercase tracking-wider text-amber border border-amber/30 px-1.5 py-0.5 rounded hover:bg-amber-soft"
                          title="Rewrite with AI"
                        >
                          ✦ AI
                        </button>
                        <button
                          onClick={() => removeBullet(exp.id, b.id)}
                          className="text-[10px] text-ink-mute hover:text-brick px-1.5"
                          title="Remove"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={() => addBullet(exp.id)}
                    className="text-[11.5px] font-mono uppercase tracking-wider text-ink-mute hover:text-amber text-left mt-1"
                  >
                    + Add bullet
                  </button>
                </div>
              </div>
            ))}
            {content.experience.length === 0 && (
              <button
                onClick={addExperience}
                className="border border-dashed border-rule rounded-xl py-8 text-center font-serif italic text-[14px] text-ink-mute hover:border-ink hover:text-ink transition-colors"
              >
                + Add your first role
              </button>
            )}
          </div>
        </Section>

        {/* Education */}
        <Section
          title="Education"
          action={<button onClick={addEducation} className="text-xs font-mono uppercase tracking-wider text-amber hover:text-amber-deep">+ Add school</button>}
        >
          <div className="flex flex-col gap-3">
            {content.education.map((edu) => (
              <div key={edu.id} className="bg-paper border border-rule rounded-xl p-4 grid grid-cols-2 gap-2 relative">
                <Field label="Degree" value={edu.degree} onChange={(v) => updateEducation(edu.id, { degree: v })} />
                <Field label="School" value={edu.school} onChange={(v) => updateEducation(edu.id, { school: v })} />
                <Field label="Start" value={edu.startDate} onChange={(v) => updateEducation(edu.id, { startDate: v })} />
                <Field label="End" value={edu.endDate} onChange={(v) => updateEducation(edu.id, { endDate: v })} />
                <button
                  onClick={() => removeEducation(edu.id)}
                  className="absolute top-2 right-2 text-[11px] text-ink-mute hover:text-brick"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </Section>

        {/* Skills */}
        <Section title="Skills">
          <Textarea
            value={content.skills.join(", ")}
            onChange={(v) =>
              update({
                ...content,
                skills: v.split(",").map((s) => s.trim()).filter(Boolean),
              })
            }
            placeholder="React, TypeScript, Figma, …"
            rows={2}
          />
          <div className="flex flex-wrap gap-1.5 mt-2">
            {content.skills.map((s) => (
              <span key={s} className="font-mono text-[11px] bg-cream-2 border border-rule px-2 py-0.5 rounded">
                {s}
              </span>
            ))}
          </div>
        </Section>
      </div>

      {/* RIGHT: Live preview */}
      <div className="bg-cream-2 overflow-y-auto p-8 pb-16">
        <div className="max-w-[600px] mx-auto">
          <div className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-mute mb-3 text-center">
            Live preview · {content.contact.name || "Untitled"}
          </div>
          <ResumePreview content={content} />
          <div className="mt-6 flex justify-center gap-2">
            <ExportButton resumeId={resumeId} format="pdf" label="↓ Download PDF" className="btn btn-ink text-[13px]" />
            <ExportButton resumeId={resumeId} format="docx" label="↓ DOCX" className="btn btn-outline text-[13px]" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- Subcomponents ----------

function Section({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="mb-7">
      <div className="flex justify-between items-baseline mb-3">
        <h3 className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-mute font-medium">
          {title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="bg-cream-2 border border-rule rounded-md px-2.5 py-1.5 text-[13px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
      />
    </div>
  );
}

function Textarea({ value, onChange, placeholder, rows = 3 }: { value: string; onChange: (v: string) => void; placeholder?: string; rows?: number }) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full bg-cream-2 border border-rule rounded-md px-3 py-2 text-[14px] font-serif resize-none focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
    />
  );
}

function AiButton({ onClick, label }: { onClick: () => void; label: string }) {
  const [loading, setLoading] = useState(false);
  return (
    <button
      onClick={async () => {
        setLoading(true);
        try { await onClick(); } finally { setLoading(false); }
      }}
      disabled={loading}
      className="text-xs font-mono uppercase tracking-wider text-amber border border-amber/30 px-2 py-0.5 rounded hover:bg-amber-soft disabled:opacity-60"
    >
      {loading ? "…" : `✦ ${label}`}
    </button>
  );
}

function SaveIndicator({ state }: { state: SaveState }) {
  const map = {
    saved: { dot: "bg-moss", label: "Saved" },
    saving: { dot: "bg-amber animate-pulse-soft", label: "Saving…" },
    dirty: { dot: "bg-clay", label: "Unsaved" },
    error: { dot: "bg-brick", label: "Save failed" },
  } as const;
  const { dot, label } = map[state];
  return (
    <div className="flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-[0.06em] text-ink-mute">
      <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
      {label}
    </div>
  );
}

function ExportButton({ resumeId, format, label, className }: { resumeId: string; format: "pdf" | "docx"; label: string; className: string }) {
  const [loading, setLoading] = useState(false);
  async function go() {
    setLoading(true);
    try {
      const res = await fetch(`/api/export/${format}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeId }),
      });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `resume.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert("Export failed");
    } finally {
      setLoading(false);
    }
  }
  return <button onClick={go} disabled={loading} className={`${className} disabled:opacity-60`}>{loading ? "…" : label}</button>;
}
