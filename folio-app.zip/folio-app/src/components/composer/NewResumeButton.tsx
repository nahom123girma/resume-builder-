"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function NewResumeButton() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  async function create(starter: "empty" | "sample") {
    setLoading(true);
    const res = await fetch("/api/resumes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ starter }),
    });
    if (!res.ok) {
      setLoading(false);
      const j = await res.json();
      alert(j.error ?? "Failed to create résumé");
      return;
    }
    const { resume } = await res.json();
    router.push(`/composer/${resume.id}`);
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        disabled={loading}
        className="btn btn-amber disabled:opacity-60"
      >
        {loading ? "Creating…" : "+ New résumé"}
      </button>
      {open && !loading && (
        <div className="absolute right-0 top-full mt-2 w-[260px] bg-paper border border-rule rounded-xl shadow-soft p-2 z-30">
          <button
            onClick={() => create("empty")}
            className="w-full text-left p-3 rounded-lg hover:bg-cream-2 transition-colors"
          >
            <div className="font-serif font-medium text-[14px] mb-0.5">Start from scratch</div>
            <div className="text-[12px] text-ink-mute">Blank template, fill in your own.</div>
          </button>
          <button
            onClick={() => create("sample")}
            className="w-full text-left p-3 rounded-lg hover:bg-cream-2 transition-colors"
          >
            <div className="font-serif font-medium text-[14px] mb-0.5">Use sample data</div>
            <div className="text-[12px] text-ink-mute">Maya Hernandez's résumé to remix.</div>
          </button>
        </div>
      )}
    </div>
  );
}
