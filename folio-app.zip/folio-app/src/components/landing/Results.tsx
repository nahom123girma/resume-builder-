import Link from "next/link";

export function Results() {
  return (
    <section className="bg-paper-2 border-t border-b border-rule py-[clamp(70px,9vw,110px)]">
      <div className="container-page">
        <div className="grid md:grid-cols-[1fr_auto] gap-8 items-center mb-[60px]">
          <h2 className="font-serif font-normal text-[clamp(36px,5.5vw,64px)] leading-none tracking-[-0.03em] max-w-[580px]">
            Create a résumé<br />
            that gets <span className="underline-wavy">results</span>.
          </h2>

          <div className="relative flex items-center gap-6">
            <svg className="w-[110px] h-[60px] text-ink -translate-y-3 hidden md:block" viewBox="0 0 110 60" fill="none">
              <path d="M5 30 Q 35 8, 70 22 T 100 38" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M93 33 L100 38 L96 45" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <Link href="/composer" className="btn btn-amber">Choose a template</Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <Benefit num="i." title="No experience necessary.">
            Whether you're entering the workforce or you've been at it twenty years, Folio's Composer gives you a starting structure that flatters either situation. No staring at a blank page.
          </Benefit>
          <Benefit num="ii." title="Tell us a bit about yourself.">
            We'll suggest the bullet points, phrasing, and section ordering that hiring managers actually respond to — guiding you toward callbacks, not stylistic dead ends.
          </Benefit>
          <Benefit num="iii." title="Simpler than you expect.">
            We've helped over a million applicants get interviews. From first draft to final export, an impactful résumé starts with the right tools — and ends in your inbox.
          </Benefit>
        </div>
      </div>
    </section>
  );
}

function Benefit({ num, title, children }: { num: string; title: string; children: React.ReactNode }) {
  return (
    <div>
      <span className="font-serif italic text-[38px] font-normal text-amber leading-none mb-3.5 block">{num}</span>
      <h3 className="font-serif font-medium text-[22px] leading-tight tracking-tight mb-2.5">{title}</h3>
      <p className="text-ink-soft text-[14.5px] leading-relaxed">{children}</p>
    </div>
  );
}
