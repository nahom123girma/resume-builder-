"use client";
import { useState } from "react";
import Link from "next/link";

const SWATCH_COLORS = ["#1B1916", "#C44A1A", "#3D5240", "#A86B3D", "#5B6A82", "#8E3320"];

export function Templates() {
  return (
    <section id="templates" className="py-[clamp(70px,9vw,110px)]">
      <div className="container-page">
        <div className="text-center mb-12">
          <h2 className="font-serif font-normal text-[clamp(36px,5vw,56px)] leading-tight tracking-tighter mb-3.5">
            Templates designed by<br />
            people who <em className="italic text-amber">read</em>.
          </h2>
          <p className="text-ink-soft text-base max-w-[540px] mx-auto">
            No "creative" templates with cartoon icons. Each one is typeset like it belongs in a literary magazine, not a clip-art folder.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-[22px] mb-7">
          <TemplateCard name="Broadsheet" tag="CLASSIC" defaultSwatch={0}>
            <BroadsheetPreview />
          </TemplateCard>
          <TemplateCard name="Sidebar" tag="MODERN" defaultSwatch={1}>
            <SidebarPreview />
          </TemplateCard>
          <TemplateCard name="Editorial" tag="SERIF" defaultSwatch={2}>
            <EditorialPreview />
          </TemplateCard>
          <TemplateCard name="Whisper" tag="MINIMAL" defaultSwatch={0}>
            <MinimalPreview />
          </TemplateCard>
        </div>

        <div className="flex justify-center">
          <Link
            href="/composer"
            className="inline-flex items-center gap-1.5 font-serif italic text-[17px] text-amber border-b border-amber pb-0.5 transition-all hover:gap-3"
          >
            View all 18 templates →
          </Link>
        </div>
      </div>
    </section>
  );
}

function TemplateCard({
  name,
  tag,
  defaultSwatch,
  children,
}: {
  name: string;
  tag: string;
  defaultSwatch: number;
  children: React.ReactNode;
}) {
  const [active, setActive] = useState(defaultSwatch);
  return (
    <div className="cursor-pointer transition-transform duration-300 hover:-translate-y-1.5">
      <div className="aspect-[8.5/11] bg-paper border border-rule rounded-lg p-[18px_14px] text-[8px] overflow-hidden shadow-soft transition-shadow hover:shadow-lg relative">
        {children}
      </div>
      <div className="mt-3.5 flex flex-col gap-2">
        <div className="flex justify-between items-baseline">
          <span className="font-serif text-[17px] font-medium tracking-tight">{name}</span>
          <span className="font-mono text-[10px] text-ink-mute uppercase tracking-wider">{tag}</span>
        </div>
        <div className="flex gap-1.5">
          {SWATCH_COLORS.map((c, i) => (
            <button
              key={i}
              onClick={(e) => {
                e.stopPropagation();
                setActive(i);
              }}
              className="w-3 h-3 rounded-full border border-rule transition-transform hover:scale-125"
              style={{
                background: c,
                outline: i === active ? "1px solid #1B1916" : undefined,
                outlineOffset: i === active ? "2px" : undefined,
              }}
              aria-label={`Color ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// Mini template previews (kept inline for clarity)
function Line({ w = "100%", className = "h-[3px] bg-cream-2" }: { w?: string; className?: string }) {
  return <div className={`${className} mb-[3px] rounded-sm`} style={{ width: w }} />;
}

function BroadsheetPreview() {
  return (
    <>
      <div className="font-serif text-[14px] font-medium mb-px">Maya Hernandez</div>
      <div className="text-[6.5px] text-ink-mute mb-2 font-mono tracking-wider uppercase">Senior Product Designer</div>
      <div className="h-px bg-ink mb-2" />
      <div className="font-mono text-[6px] tracking-widest uppercase text-amber mt-2 mb-1">Summary</div>
      <Line w="85%" /><Line /><Line w="60%" />
      <div className="font-mono text-[6px] tracking-widest uppercase text-amber mt-2 mb-1">Experience</div>
      <Line w="85%" /><Line /><Line w="60%" /><Line />
      <div className="font-mono text-[6px] tracking-widest uppercase text-amber mt-2 mb-1">Education</div>
      <Line w="85%" />
    </>
  );
}

function SidebarPreview() {
  return (
    <div className="bg-ink text-paper -m-[18px] -mt-[18px] -ml-[14px] -mr-[14px] h-full p-[18px_14px] relative rounded-lg">
      <div className="absolute left-0 top-0 bottom-0 w-[35%] bg-amber" />
      <div className="ml-[32%] relative">
        <div className="text-[13px] font-semibold mb-0.5">Maya Hernandez</div>
        <div className="text-[6px] opacity-70 mb-2">Senior Product Designer</div>
        <Line w="80%" className="h-[3px] bg-white/20" />
        <Line className="h-[3px] bg-white/20" />
        <Line w="60%" className="h-[3px] bg-white/20" />
        <Line w="80%" className="h-[3px] bg-white/20" />
        <Line className="h-[3px] bg-white/20" />
      </div>
    </div>
  );
}

function EditorialPreview() {
  return (
    <div className="bg-cream-2 -m-[18px] -mt-[18px] -ml-[14px] -mr-[14px] h-full p-[18px_14px] rounded-lg">
      <div className="font-serif italic text-[22px] font-normal leading-none tracking-[-0.03em] mb-1.5">
        Maya<br />Hernandez
      </div>
      <div className="text-[6px] text-amber mb-2.5 tracking-widest uppercase font-mono">Senior Product Designer</div>
      <div className="grid grid-cols-[1fr_1.3fr] gap-1.5">
        <div>
          <div className="font-mono text-[5.5px] tracking-widest uppercase text-ink mb-1 font-medium">Contact</div>
          <Line className="h-[2.5px] bg-rule" /><Line className="h-[2.5px] bg-rule" />
          <div className="font-mono text-[5.5px] tracking-widest uppercase text-ink mb-1 font-medium mt-2">Skills</div>
          <Line className="h-[2.5px] bg-rule" /><Line className="h-[2.5px] bg-rule" /><Line className="h-[2.5px] bg-rule" />
        </div>
        <div>
          <div className="font-mono text-[5.5px] tracking-widest uppercase text-ink mb-1 font-medium">Experience</div>
          <Line className="h-[2.5px] bg-rule" /><Line className="h-[2.5px] bg-rule" />
          <Line className="h-[2.5px] bg-rule" /><Line className="h-[2.5px] bg-rule" />
        </div>
      </div>
    </div>
  );
}

function MinimalPreview() {
  return (
    <>
      <div className="font-sans text-[12px] font-medium tracking-tight mb-px">maya hernandez.</div>
      <div className="text-[6px] text-ink-mute mb-4">senior product designer</div>
      <div className="text-[7px] font-medium mt-2.5 mb-1">work</div>
      <Line className="h-[2.5px] bg-cream-2" /><Line className="h-[2.5px] bg-cream-2" /><Line className="h-[2.5px] bg-cream-2" />
      <div className="text-[7px] font-medium mt-2.5 mb-1">education</div>
      <Line className="h-[2.5px] bg-cream-2" /><Line className="h-[2.5px] bg-cream-2" />
      <div className="text-[7px] font-medium mt-2.5 mb-1">tools</div>
      <Line className="h-[2.5px] bg-cream-2" />
    </>
  );
}
