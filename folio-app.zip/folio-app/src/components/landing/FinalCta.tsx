import Link from "next/link";

export function FinalCta() {
  return (
    <section className="text-center py-[clamp(60px,8vw,100px)] pb-[clamp(70px,10vw,130px)] border-t border-rule">
      <div className="container-page">
        <h2 className="font-serif font-normal text-[clamp(40px,6vw,80px)] leading-[0.95] tracking-tightest mb-5">
          Stop tweaking.
          <br />
          <em className="italic text-amber">Start applying.</em>
        </h2>
        <p className="text-ink-soft text-[17px] max-w-[520px] mx-auto mb-9">
          Free forever for the basics. Seven days free for everything. The job you want already posted twenty minutes ago.
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link href="/signup" className="btn btn-amber px-7 py-3.5 text-[14.5px]">Create new résumé</Link>
          <Link href="/composer/optimize" className="btn btn-outline px-7 py-3.5 text-[14.5px]">Optimise my résumé</Link>
        </div>
      </div>
    </section>
  );
}
