export function Features() {
  return (
    <section id="features" className="py-[clamp(70px,9vw,110px)]">
      <div className="container-page">
        <div className="text-center mb-12">
          <h2 className="font-serif font-normal text-[clamp(36px,5vw,56px)] leading-tight tracking-tighter mb-3.5">
            Six features to <em className="italic text-amber">boost</em>
            <br />your job search.
          </h2>
          <p className="text-ink-soft text-base max-w-[540px] mx-auto">
            Each one designed to do one thing exceptionally — and quietly hand you off to the next.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-[22px]">
          <FeatureCard num="№ 01" title={<>Template <em>Library</em></>} desc="Eighteen typeset templates. Each tested across four ATS engines before it ships.">
            <div className="flex justify-center items-start gap-2 pt-4">
              <MiniResume name="Avery" rotate="-rotate-6" />
              <MiniResume name="Maya" />
              <MiniResume name="Jordan" rotate="rotate-6" />
            </div>
          </FeatureCard>

          <FeatureCard num="№ 02" title={<>Enhance with <em>AI</em></>} desc="Paste a job duty, get three quantified rewrites that don't sound like AI.">
            <div className="p-3.5 px-[18px] flex flex-col gap-1.5">
              <CheckRow state="done">Reviewed grammar</CheckRow>
              <CheckRow state="active">Sharpening bullet 3</CheckRow>
              <CheckRow state="pending">Match to JD keywords</CheckRow>
              <CheckRow state="pending">Tone consistency</CheckRow>
            </div>
          </FeatureCard>

          <FeatureCard num="№ 03" title={<>Résumé <em>Review</em></>} desc="The same parsers recruiters use — pointed at your draft, not against it.">
            <div className="p-3.5 grid grid-cols-[1fr_auto] gap-3.5 items-center h-full">
              <div className="font-serif text-[56px] font-medium tracking-[-0.04em] leading-[0.9]">
                87<span className="text-amber">%</span>
              </div>
              <div className="font-mono text-[10px] tracking-widest uppercase text-ink-mute">
                <div className="mb-1">Format <strong className="text-moss font-medium">Clean</strong></div>
                <div className="mb-1">Length <strong className="text-moss font-medium">1 page</strong></div>
                <div>Keywords <strong className="text-moss font-medium">12/14</strong></div>
              </div>
            </div>
          </FeatureCard>

          <FeatureCard num="№ 04" title={<>Cover <em>Letter</em> Studio</>} desc="One click per job description. Personalised, in your voice, never sludgy.">
            <div className="relative h-full grid place-items-center p-4">
              <div className="w-[90%] max-w-[200px] bg-white border border-rule rounded p-3.5 px-4 font-serif italic text-[9px] leading-relaxed text-ink-soft shadow-soft" style={{ transform: "rotate(-1.5deg)" }}>
                <div className="mb-1.5">Dear hiring manager,</div>
                <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm" />
                <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm w-[60%]" />
                <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm" />
                <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm" />
                <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm w-[60%]" />
                <div className="font-hand not-italic text-base mt-1.5 text-ink tracking-wide">— Maya</div>
              </div>
            </div>
          </FeatureCard>

          <FeatureCard num="№ 05" title={<>Personal <em>Page</em></>} desc={<>A one-page portfolio at <span className="font-mono text-amber">folio.cv/you</span> for the recruiters who Google.</>}>
            <div className="p-3.5 px-[18px] h-full">
              <div className="bg-paper border border-rule rounded-md h-full overflow-hidden">
                <div className="bg-cream-2 border-b border-rule p-1.5 px-2 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-rule" />
                  <div className="w-1.5 h-1.5 rounded-full bg-rule" />
                  <div className="w-1.5 h-1.5 rounded-full bg-rule" />
                  <div className="flex-1 ml-1.5 bg-paper rounded-sm px-1.5 font-mono text-[8px] text-ink-mute">folio.cv/maya</div>
                </div>
                <div className="p-2.5 px-3.5 font-serif">
                  <div className="text-[14px] font-medium">Maya Hernandez</div>
                  <div className="italic text-[8.5px] text-ink-mute mb-1.5">Senior Product Designer · SF</div>
                  <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm" />
                  <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm w-[60%]" />
                  <div className="h-[1.5px] bg-cream-2 mb-0.5 rounded-sm" />
                </div>
              </div>
            </div>
          </FeatureCard>

          <FeatureCard num="№ 06" title={<>Application <em>Tracker</em></>} desc="Every résumé you sent, every reply you got, every callback waiting.">
            <div className="p-3.5 pb-7 h-full flex items-end gap-1.5">
              <Bar h="30%" label="S" />
              <Bar h="55%" label="A" />
              <Bar h="75%" label="I" amber />
              <Bar h="25%" label="O" />
              <Bar h="45%" label="R" />
            </div>
          </FeatureCard>
        </div>
      </div>
    </section>
  );
}

function FeatureCard({
  num,
  title,
  desc,
  children,
}: {
  num: string;
  title: React.ReactNode;
  desc: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-paper border border-rule rounded-[14px] pt-[26px] px-[26px] pb-0 relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-ink hover:shadow-soft cursor-pointer">
      <div className="font-mono text-[11px] tracking-[0.14em] text-ink-mute uppercase mb-3">{num}</div>
      <h3 className="font-serif font-medium text-[22px] leading-tight tracking-tight mb-2 [&_em]:italic [&_em]:text-amber">{title}</h3>
      <p className="text-ink-soft text-[13.5px] leading-relaxed mb-[22px]">{desc}</p>
      <div className="relative h-[150px] -mx-[26px] bg-cream-2 border-t border-rule overflow-hidden">{children}</div>
    </div>
  );
}

function MiniResume({ name, rotate = "" }: { name: string; rotate?: string }) {
  return (
    <div className={`w-[60px] aspect-[8.5/11] bg-white rounded p-1.5 px-[5px] shadow-soft ${rotate}`}>
      <div className="font-serif text-[5.5px] font-semibold mb-1">{name}</div>
      <div className="h-[1.5px] bg-cream-2 rounded-sm mb-0.5 w-[60%]" />
      <div className="h-[1.5px] bg-cream-2 rounded-sm mb-0.5" />
      <div className="h-[1.5px] bg-cream-2 rounded-sm mb-0.5 w-[60%]" />
      <div className="h-[1.5px] bg-cream-2 rounded-sm mb-0.5" />
    </div>
  );
}

function CheckRow({ state, children }: { state: "done" | "active" | "pending"; children: React.ReactNode }) {
  const icon = state === "done" ? "✓" : state === "active" ? "✦" : "○";
  const color = state === "done" ? "text-moss" : state === "active" ? "text-amber border-amber" : "text-ink-mute";
  return (
    <div className={`flex items-center gap-2 bg-paper border border-rule rounded-md py-1.5 px-2.5 text-[11px] font-serif ${state === "active" ? "border-amber" : ""} ${state === "done" ? "text-moss" : "text-ink-soft"}`}>
      <span className={color}>{icon}</span>
      {children}
    </div>
  );
}

function Bar({ h, label, amber = false }: { h: string; label: string; amber?: boolean }) {
  return (
    <div className={`flex-1 ${amber ? "bg-amber" : "bg-ink"} rounded-t-sm relative`} style={{ height: h }}>
      <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 font-mono text-[8px] text-ink-mute">{label}</span>
    </div>
  );
}
