import Link from "next/link";

export function Hero() {
  return (
    <section className="text-center py-[clamp(50px,7vw,90px)] pb-[clamp(60px,8vw,100px)]">
      <div className="container-page">
        <div className="eyebrow mb-6 justify-center">
          <span>Folio · The career &amp; document studio</span>
        </div>

        <h1 className="font-serif font-normal text-[clamp(44px,6.5vw,84px)] leading-[0.98] tracking-tightest text-ink mx-auto mb-6 max-w-[880px]">
          Job-winning <em className="italic text-amber font-normal">résumé</em>
          <br />
          builder.
        </h1>

        <p className="text-[17px] leading-relaxed text-ink-soft max-w-[560px] mx-auto mb-9">
          Get hired 2× as fast.<sup className="text-[10px] align-super text-amber font-semibold">1</sup> Choose from typeset, recruiter-approved templates. Add ready-to-use bullet points and phrases written by people who actually read résumés.
        </p>

        <div className="flex flex-wrap gap-3 justify-center mb-14">
          <Link href="/signup" className="btn btn-amber px-7 py-3.5 text-[14.5px]">
            Create new résumé
          </Link>
          <Link href="/composer/optimize" className="btn btn-outline px-7 py-3.5 text-[14.5px]">
            Optimise my résumé
          </Link>
        </div>

        {/* Three step cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-[18px] max-w-[1100px] mx-auto text-left">
          <StepCard step={1} dot="bg-ink" tag="Step 01 · Pick" title={<>A <em>typeset</em> template, not clip art.</>}>
            <MockTemplate />
            <div className="absolute bottom-[18px] right-[14px] bg-ink text-paper font-mono text-[9px] tracking-[0.1em] uppercase px-2 py-1 rounded font-medium">Recruiter-approved</div>
          </StepCard>

          <StepCard step={2} dot="bg-amber" tag="Step 02 · Polish" title={<>Generate content with <em>AI support</em>.</>}>
            <MockAi />
          </StepCard>

          <StepCard step={3} dot="bg-moss" tag="Step 03 · Apply" title={<>Get your résumé &amp; <em>apply</em>.</>}>
            <MockFinal />
            <div className="absolute bottom-[26px] right-[18px] bg-moss text-paper font-mono text-[9px] tracking-[0.1em] uppercase px-2.5 py-1 rounded-full font-medium animate-bob">↓ PDF ready</div>
          </StepCard>
        </div>
      </div>
    </section>
  );
}

function StepCard({
  step,
  dot,
  tag,
  title,
  children,
}: {
  step: number;
  dot: string;
  tag: string;
  title: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-paper border border-rule rounded-[14px] pt-[22px] px-[22px] pb-0 relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-soft hover:border-ink">
      <div className="font-mono text-[11px] tracking-[0.14em] uppercase text-ink-mute mb-3.5 inline-flex items-center gap-2">
        <span className={`inline-block w-2 h-2 rounded-full ${dot}`} />
        {tag}
      </div>
      <div className="font-serif text-[22px] font-medium leading-[1.15] tracking-tight mb-[18px] min-h-[50px] [&_em]:italic [&_em]:text-amber">
        {title}
      </div>
      <div className="relative h-[200px] -mx-[22px] -mb-px overflow-hidden bg-cream-2 border-t border-rule">
        {children}
      </div>
    </div>
  );
}

function MockTemplate() {
  return (
    <div className="absolute top-[18px] left-1/2 -translate-x-1/2 w-[150px] aspect-[8.5/11] bg-white rounded font-serif shadow-lg p-[14px_12px]">
      <div className="text-[11px] font-semibold tracking-tight">Maya Hernandez</div>
      <div className="text-[6.5px] text-ink-mute font-mono tracking-wider uppercase mt-px mb-[7px]">Senior Product Designer</div>
      <div className="h-px bg-ink mb-1.5" />
      <div className="font-mono text-[5px] tracking-widest uppercase text-amber my-1.5 font-medium">Summary</div>
      <Line w="85%" /><Line /><Line w="60%" />
      <div className="font-mono text-[5px] tracking-widest uppercase text-amber my-1.5 font-medium">Experience</div>
      <Line w="85%" /><Line /><Line w="60%" /><Line />
    </div>
  );
}

function Line({ w = "100%" }: { w?: string }) {
  return <div className="h-[2px] bg-cream-2 rounded-sm mb-[2.5px]" style={{ width: w }} />;
}

function MockAi() {
  return (
    <div className="absolute inset-[18px_14px] bg-paper border border-rule rounded-lg p-3.5 flex flex-col gap-2">
      <div className="font-mono text-[9px] tracking-[0.14em] uppercase text-amber font-medium">✦ AI suggestions</div>
      <div className="font-serif text-[11px] leading-snug text-ink-soft">Cultivated strong business relationships with customers to drive new development.</div>
      <div className="bg-amber-soft border border-amber rounded-md p-2 font-serif text-[11px] leading-snug text-ink italic relative">
        Built and nurtured a portfolio of 40+ enterprise relationships, driving $2.1M in new pipeline.
        <span className="absolute top-2 right-2 text-amber text-[10px] not-italic">✦</span>
      </div>
      <div className="h-1 w-[30%] bg-amber rounded-sm animate-pulse-soft" />
    </div>
  );
}

function MockFinal() {
  return (
    <div className="absolute top-[14px] left-1/2 w-[130px] aspect-[8.5/11] bg-white rounded p-[12px_10px] shadow-lg font-serif" style={{ transform: "translateX(-50%) rotate(-3deg)" }}>
      <div className="text-[10px] font-semibold">Maya Hernandez</div>
      <div className="text-[5.5px] text-ink-mute font-mono tracking-wider uppercase mb-1.5">Senior Product Designer</div>
      <div className="h-px bg-ink mb-1" />
      <div className="font-mono text-[4px] tracking-widest uppercase text-moss my-1 font-medium">Summary</div>
      <Line /><Line w="60%" />
      <div className="font-mono text-[4px] tracking-widest uppercase text-moss my-1 font-medium">Experience</div>
      <Line /><Line /><Line w="60%" /><Line />
    </div>
  );
}
