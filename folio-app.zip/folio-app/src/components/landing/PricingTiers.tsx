"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const TIERS = [
  {
    id: "free",
    name: "Free",
    price: "$0",
    cadence: "forever",
    desc: "The basics, no card required.",
    features: [
      "3 résumés",
      "5 PDF conversions / month",
      "20 AI rewrites / month",
      "PDF & DOCX export",
    ],
    cta: "Get started",
    href: "/signup",
    highlight: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: "$12",
    cadence: "/ month",
    desc: "For active job seekers.",
    features: [
      "Unlimited résumés",
      "Unlimited PDF tools",
      "1,000 AI rewrites / month",
      "Tailored cover letters",
      "ATS scorer with JD match",
      "Personal page (folio.cv/you)",
    ],
    cta: "Start 7-day free trial",
    href: "checkout",
    highlight: true,
  },
  {
    id: "studio",
    name: "Studio",
    price: "$28",
    cadence: "/ month",
    desc: "For coaches, recruiters, teams.",
    features: [
      "Everything in Pro",
      "5,000 AI rewrites / month",
      "Brand-customised templates",
      "Team workspace (5 seats)",
      "Priority support",
    ],
    cta: "Contact sales",
    href: "/contact",
    highlight: false,
  },
];

export function PricingTiers() {
  const router = useRouter();
  const [loading, setLoading] = useState<string | null>(null);

  async function handleCheckout(tier: string) {
    setLoading(tier);
    const res = await fetch("/api/stripe/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ priceId: process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE ?? "price_pro_monthly" }),
    });
    if (!res.ok) {
      setLoading(null);
      const j = await res.json();
      alert(j.error ?? "Checkout failed. Configure STRIPE_SECRET_KEY in .env to enable.");
      return;
    }
    const { url } = await res.json();
    window.location.href = url;
  }

  return (
    <div className="container-page">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-[1080px] mx-auto">
        {TIERS.map((tier) => (
          <div
            key={tier.id}
            className={`bg-paper border rounded-2xl p-7 relative ${
              tier.highlight ? "border-amber shadow-soft md:scale-105" : "border-rule"
            }`}
          >
            {tier.highlight && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber text-paper font-mono text-[10px] uppercase tracking-[0.16em] px-3 py-1 rounded-full font-medium">
                Most popular
              </div>
            )}
            <h3 className="font-serif text-[26px] font-medium tracking-tight mb-1">{tier.name}</h3>
            <div className="font-serif text-ink-mute italic text-[14px] mb-5">{tier.desc}</div>
            <div className="flex items-baseline gap-1.5 mb-6 pb-5 border-b border-rule">
              <span className="font-serif text-[44px] font-medium tracking-[-0.04em] leading-none">{tier.price}</span>
              <span className="font-mono text-[12px] text-ink-mute">{tier.cadence}</span>
            </div>
            <ul className="flex flex-col gap-2.5 mb-6">
              {tier.features.map((f) => (
                <li key={f} className="flex items-baseline gap-2 text-[13.5px] text-ink-soft">
                  <span className="text-amber">✓</span>
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => {
                if (tier.href === "checkout") handleCheckout(tier.id);
                else router.push(tier.href);
              }}
              disabled={loading === tier.id}
              className={`w-full justify-center ${tier.highlight ? "btn btn-amber" : "btn btn-outline"}`}
            >
              {loading === tier.id ? "Redirecting…" : tier.cta}
            </button>
          </div>
        ))}
      </div>

      <div className="text-center mt-12 text-ink-mute text-[13px]">
        <p>All prices in USD. Cancel anytime from your dashboard. No proration shenanigans.</p>
      </div>
    </div>
  );
}
