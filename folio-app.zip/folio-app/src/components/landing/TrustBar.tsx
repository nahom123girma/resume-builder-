export function TrustBar() {
  return (
    <section className="border-t border-b border-rule bg-cream-2 py-6">
      <div className="container-page flex flex-col md:flex-row items-center justify-between gap-10 flex-wrap">
        <div className="flex items-center gap-3 text-[13px] text-ink-soft">
          <span className="font-mono text-[11px] tracking-[0.14em] uppercase font-medium text-ink">Excellent</span>
          <span className="text-amber text-base">★ ★ ★ ★ ★</span>
          <span><em className="font-serif italic text-ink">4.7 / 5</em> from 24,318 réviews</span>
        </div>

        <div className="flex items-center gap-7 text-[13px] text-ink-mute flex-wrap">
          <span className="font-serif italic text-sm">Customers have been hired by</span>
          <div className="flex items-center gap-6 flex-wrap font-serif font-medium text-[17px] tracking-tight text-ink-soft">
            <span className="opacity-75 hover:opacity-100 hover:text-ink transition-all cursor-pointer">amazon</span>
            <span className="opacity-75 hover:opacity-100 hover:text-ink transition-all cursor-pointer">Pinterest</span>
            <span className="opacity-75 hover:opacity-100 hover:text-ink transition-all cursor-pointer">NIKE</span>
            <span className="opacity-75 hover:opacity-100 hover:text-ink transition-all cursor-pointer">Walmart</span>
            <span className="opacity-75 hover:opacity-100 hover:text-ink transition-all cursor-pointer">SEPHORA</span>
          </div>
        </div>
      </div>
    </section>
  );
}
