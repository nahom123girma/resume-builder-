"use client";

import { useState, useRef, useEffect } from "react";

type Msg = { role: "user" | "assistant"; content: string };

const STARTERS = [
  "Help me tailor a bullet point for a senior PM role",
  "Write a follow-up email to a recruiter who's gone silent",
  "What's a good question to ask in a final-round interview?",
  "Suggest three rewrites of this summary: …",
];

export function AssistantChat({ initialPrompt }: { initialPrompt: string }) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState(initialPrompt);
  const [streaming, setStreaming] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, streaming]);

  // Auto-send on initial prompt arrival
  useEffect(() => {
    if (initialPrompt && messages.length === 0) {
      void send(initialPrompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialPrompt]);

  async function send(prompt?: string) {
    const text = (prompt ?? input).trim();
    if (!text || streaming) return;

    const userMsg: Msg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg, { role: "assistant", content: "" }]);
    setInput("");
    setStreaming(true);

    const res = await fetch("/api/ai/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: [...messages, userMsg] }),
    });

    if (!res.ok || !res.body) {
      setMessages((prev) => {
        const next = [...prev];
        next[next.length - 1] = { role: "assistant", content: "Sorry — something went wrong. Try again?" };
        return next;
      });
      setStreaming(false);
      return;
    }

    // Stream the response
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let acc = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      acc += decoder.decode(value, { stream: true });
      setMessages((prev) => {
        const next = [...prev];
        next[next.length - 1] = { role: "assistant", content: acc };
        return next;
      });
    }
    setStreaming(false);
  }

  return (
    <div className="grid grid-rows-[1fr_auto] h-full">
      <div ref={scrollRef} className="overflow-y-auto px-9 py-8 pb-6">
        <div className="max-w-[760px] mx-auto">
          {messages.length === 0 ? (
            <div className="pt-10">
              <div className="eyebrow mb-4">Assistant</div>
              <h1 className="font-serif text-[40px] font-normal tracking-tight leading-[1.05] mb-3">
                What should we<br />
                <em className="italic text-amber">work on</em>?
              </h1>
              <p className="text-ink-soft text-[15px] mb-8 max-w-[460px]">
                Ask anything — résumé tweaks, cover-letter drafts, interview prep, or general career advice.
              </p>
              <div className="flex flex-col gap-2 max-w-[560px]">
                {STARTERS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="text-left bg-paper border border-rule rounded-lg px-4 py-3 font-serif italic text-[14.5px] text-ink-soft hover:border-ink hover:text-ink hover:translate-x-0.5 transition-all"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              {messages.map((m, i) => (
                <Message key={i} msg={m} streaming={streaming && i === messages.length - 1 && m.role === "assistant"} />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-rule bg-cream/95 backdrop-blur-md p-4">
        <div className="max-w-[760px] mx-auto flex items-end gap-2.5 bg-paper border border-rule rounded-xl p-2.5">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            rows={1}
            placeholder="Type your question…"
            className="flex-1 bg-transparent font-serif text-[14.5px] py-2 px-2 outline-none resize-none max-h-[200px] placeholder:italic placeholder:text-ink-mute"
            style={{ minHeight: "32px" }}
          />
          <button
            onClick={() => void send()}
            disabled={!input.trim() || streaming}
            className="btn btn-amber disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {streaming ? "…" : "Send →"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Message({ msg, streaming }: { msg: Msg; streaming: boolean }) {
  if (msg.role === "user") {
    return (
      <div className="flex justify-end">
        <div className="bg-ink text-cream rounded-2xl rounded-br-sm px-4 py-2.5 max-w-[80%] font-sans text-[14px] leading-snug">
          {msg.content}
        </div>
      </div>
    );
  }
  return (
    <div className="flex gap-3">
      <div className="w-8 h-8 rounded-md bg-amber grid place-items-center font-mono text-[14px] text-paper flex-shrink-0">
        ✦
      </div>
      <div className="font-serif text-[14.5px] leading-relaxed text-ink whitespace-pre-wrap pt-1">
        {msg.content || (streaming ? <BlinkCursor /> : null)}
        {streaming && msg.content && <span className="inline-block w-2 h-[1.2em] bg-amber ml-0.5 animate-pulse-soft align-middle" />}
      </div>
    </div>
  );
}

function BlinkCursor() {
  return (
    <span className="inline-flex gap-1 items-center">
      <span className="w-1.5 h-1.5 rounded-full bg-amber animate-pulse-soft" />
      <span className="w-1.5 h-1.5 rounded-full bg-amber animate-pulse-soft" style={{ animationDelay: "0.2s" }} />
      <span className="w-1.5 h-1.5 rounded-full bg-amber animate-pulse-soft" style={{ animationDelay: "0.4s" }} />
    </span>
  );
}
