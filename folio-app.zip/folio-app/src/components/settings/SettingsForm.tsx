"use client";

import { useState } from "react";

export function SettingsForm({ user }: { user: { id: string; name: string; email: string } }) {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<Date | null>(null);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const res = await fetch("/api/account", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email }),
    });
    setSaving(false);
    if (res.ok) setSavedAt(new Date());
    else alert("Save failed");
  }

  return (
    <form onSubmit={save} className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="bg-cream-2 border border-rule rounded-md px-3 py-2 text-[14px] focus:border-ink outline-none"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-cream-2 border border-rule rounded-md px-3 py-2 text-[14px] focus:border-ink outline-none"
          />
        </div>
      </div>
      <div className="flex items-center justify-end gap-3">
        {savedAt && (
          <span className="font-mono text-[10.5px] uppercase tracking-[0.06em] text-moss">
            ● Saved {savedAt.toLocaleTimeString()}
          </span>
        )}
        <button type="submit" disabled={saving} className="btn btn-amber disabled:opacity-60">
          {saving ? "Saving…" : "Save changes"}
        </button>
      </div>
    </form>
  );
}
