interface StatsProps {
  applied: number;
  responseRate: number;
  interviews: number;
  avgScore: number;
}

export function Stats({ applied, responseRate, interviews, avgScore }: StatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 mb-9">
      <Stat num="№ 01" label="Applications, last 7 days" value={applied.toString()} stroke="#C44A1A" />
      <Stat num="№ 02" label="Response rate" value={`${responseRate}%`} stroke="#3D5240" />
      <Stat num="№ 03" label="Interviews this week" value={interviews.toString()} stroke="#A86B3D" />
      <Stat num="№ 04" label="Average ATS score" value={avgScore > 0 ? `${avgScore}%` : "—"} stroke="#1B1916" />
    </div>
  );
}

function Stat({ num, label, value, stroke }: { num: string; label: string; value: string; stroke: string }) {
  const hasUnit = value.includes("%");
  const main = hasUnit ? value.replace("%", "") : value;
  return (
    <div className="bg-paper border border-rule rounded-xl p-5 pb-4 relative overflow-hidden transition-all duration-300 hover:border-ink hover:-translate-y-0.5">
      <div className="font-mono text-[10px] text-ink-mute tracking-[0.14em] uppercase mb-4">{num}</div>
      <div className="font-serif italic text-[12.5px] text-ink-soft mb-3.5">{label}</div>
      <div className="font-serif text-[52px] font-normal tracking-[-0.04em] leading-none mb-2.5 text-ink">
        {main}
        {hasUnit && <span className="text-[22px] text-ink-mute ml-px">%</span>}
      </div>
      <div className="flex items-center justify-between text-[11.5px] pt-3 border-t border-rule">
        <span className="font-mono text-[11px] font-medium text-moss">↑ active</span>
        <span className="font-mono text-[10.5px] text-ink-mute tracking-[0.04em]">7d</span>
      </div>
      <svg className="absolute bottom-14 right-4 w-20 h-7 opacity-70" viewBox="0 0 80 28" preserveAspectRatio="none">
        <path d="M0,22 L11,18 L22,20 L33,14 L44,12 L55,8 L66,11 L80,5" fill="none" stroke={stroke} strokeWidth="1.4" />
      </svg>
    </div>
  );
}
