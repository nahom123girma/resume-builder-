"use client";

import type { Job, JobStatus } from "@prisma/client";
import { useState } from "react";
import { cn, formatDate } from "@/lib/utils";

interface KanbanProps {
  jobs: Record<JobStatus, Job[]>;
}

const COLUMNS: { status: JobStatus; label: string; prefix: string; barColor: string }[] = [
  { status: "SAVED", label: "Saved", prefix: "A.", barColor: "border-t-ink-mute" },
  { status: "APPLIED", label: "Applied", prefix: "B.", barColor: "border-t-clay" },
  { status: "INTERVIEW", label: "Interview", prefix: "C.", barColor: "border-t-amber" },
  { status: "OFFER", label: "Offer", prefix: "D.", barColor: "border-t-moss" },
  { status: "REJECTED", label: "Rejected", prefix: "E.", barColor: "border-t-brick" },
];

export function Kanban({ jobs: initial }: KanbanProps) {
  const [jobs, setJobs] = useState(initial);
  const [draggedId, setDraggedId] = useState<string | null>(null);

  async function handleDrop(status: JobStatus) {
    if (!draggedId) return;
    setDraggedId(null);

    // Find the job
    let dragged: Job | undefined;
    let oldStatus: JobStatus | undefined;
    for (const s of Object.keys(jobs) as JobStatus[]) {
      const j = jobs[s].find((j) => j.id === draggedId);
      if (j) { dragged = j; oldStatus = s; break; }
    }
    if (!dragged || !oldStatus || oldStatus === status) return;

    // Optimistic update
    setJobs((prev) => ({
      ...prev,
      [oldStatus!]: prev[oldStatus!].filter((j) => j.id !== draggedId),
      [status]: [{ ...dragged!, status }, ...prev[status]],
    }));

    // Persist
    await fetch(`/api/jobs/${draggedId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
  }

  return (
    <>
      <div className="flex justify-between items-end mb-4 gap-5 flex-wrap">
        <h2 className="font-serif text-3xl font-normal tracking-tight leading-none">
          The <em className="italic text-amber">job tracker</em>.
        </h2>
        <div className="flex gap-1.5 items-center flex-wrap">
          <FilterPill active>All roles</FilterPill>
          <FilterPill>Remote only</FilterPill>
          <FilterPill>$200k+</FilterPill>
          <FilterPill>+ Filter</FilterPill>
        </div>
      </div>

      <div className="bg-paper border border-rule rounded-2xl p-2 overflow-x-auto mb-9">
        <div className="grid grid-cols-5 gap-2 min-w-[1100px]">
          {COLUMNS.map((col) => (
            <div
              key={col.status}
              data-status={col.status}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(col.status)}
              className={cn("bg-cream-2 rounded-xl p-3 min-h-[420px] border-t-2 relative", col.barColor)}
            >
              <div className="flex justify-between items-center mb-3.5 pb-3 border-b border-rule px-1">
                <div className="font-serif text-sm font-medium tracking-tight flex items-baseline gap-2">
                  <span className="font-mono text-[10px] text-ink-mute tracking-[0.06em]">{col.prefix}</span>
                  {col.label}
                </div>
                <div className="flex items-center">
                  <span className="font-mono text-[10.5px] text-ink-mute">{jobs[col.status].length}</span>
                  <button className="ml-1.5 w-[22px] h-[22px] rounded grid place-items-center text-ink-mute hover:bg-paper hover:text-ink text-sm">+</button>
                </div>
              </div>

              <div className="flex flex-col gap-2.5">
                {jobs[col.status].length === 0 && (
                  <div className="text-[12px] text-ink-mute italic font-serif text-center py-8">
                    No {col.label.toLowerCase()} jobs yet
                  </div>
                )}
                {jobs[col.status].map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    onDragStart={() => setDraggedId(job.id)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function JobCard({ job, onDragStart }: { job: Job; onDragStart: () => void }) {
  const initial = job.company[0].toUpperCase();
  return (
    <div
      draggable
      onDragStart={onDragStart}
      className="bg-paper border border-rule rounded-xl p-3.5 px-4 cursor-grab active:cursor-grabbing transition-all hover:border-ink hover:-translate-y-0.5 hover:shadow-soft"
    >
      <div className="flex items-start gap-2.5 mb-2.5">
        <div className="w-7 h-7 rounded-md bg-ink text-paper grid place-items-center font-serif font-semibold text-[13px] flex-shrink-0">
          {initial}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-serif text-[14.5px] font-medium leading-tight tracking-tight mb-0.5">{job.title}</div>
          <div className="text-[11.5px] text-ink-mute italic font-serif">{job.company}{job.location ? ` · ${job.location}` : ""}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-2.5">
        {job.salaryRange && <Chip>{job.salaryRange}</Chip>}
        {job.matchScore != null && <Chip color="amber">{job.matchScore}% match</Chip>}
      </div>

      <div className="flex justify-between items-center pt-2.5 border-t border-dashed border-rule text-[11px] text-ink-mute font-mono">
        <span>{formatDate(job.updatedAt)}</span>
        {job.matchScore != null && (
          <div className="w-14 h-[3px] bg-cream-2 rounded-sm overflow-hidden">
            <div className="h-full bg-amber rounded-sm" style={{ width: `${job.matchScore}%` }} />
          </div>
        )}
      </div>
    </div>
  );
}

function Chip({ children, color = "default" }: { children: React.ReactNode; color?: "default" | "amber" | "moss" }) {
  const colors = {
    default: "text-ink-soft border-rule bg-cream-2",
    amber: "text-amber border-amber/30 bg-amber-soft",
    moss: "text-moss border-moss/30 bg-moss-soft",
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono border ${colors[color]}`}>
      {children}
    </span>
  );
}

function FilterPill({ active = false, children }: { active?: boolean; children: React.ReactNode }) {
  return (
    <button
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs border transition-all",
        active ? "bg-ink border-ink text-cream" : "border-rule text-ink-soft hover:border-ink-mute hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}
