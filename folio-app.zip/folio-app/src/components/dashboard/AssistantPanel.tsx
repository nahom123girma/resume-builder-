"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const SUGGESTIONS = [
  "Tailor my résumé for this Anthropic role",
  "Write a cover letter for the offer in column D",
  "Suggest interview questions for tomorrow",
];

export function AssistantPanel() {
  const router = useRouter();
  const [prompt, setPrompt] = useState("");
  const [thinking, setThinking] = useState(false);

  async function send() {
    if (!prompt.trim()) return;
    setThinking(true);
    // Stub — real impl will route to /api/ai/chat with streaming
    await new Promise((r) => setTimeout(r, 800));
    setThinking(false);
    router.push(`/assistant?q=${encodeURIComponent(prompt)}`);
  }

  return (
    <div className="bg-ink text-cream rounded-xl p-6 px-7 relative overflow-hidden">
      {/* Amber radial glow */}
      <div
        className="absolute -top-[120px] -right-[120px] w-[300px] h-[300px] rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(196,74,26,0.18) 0%, transparent 70%)" }}
      />

      <div className="relative">
        <div className="font-mono text-[10px] tracking-[0.16em] uppercase text-amber font-medium mb-2.5 flex items-center gap-1.5 before:content-[''] before:w-[18px] before:h-px before:bg-amber">
          ✦ Assistant
        </div>
        <h3 className="font-serif text-[26px] font-normal tracking-tight leading-[1.1] mb-4">
          What should we<br />
          <em className="italic text-amber">work on</em> next?
        </h3>
        <p className="text-[13px] text-cream/70 leading-relaxed mb-4">
          Ask anything — résumé tweaks, cover-letter drafts, interview prep, or PDF surgery.
        </p>

        <div className="flex flex-col gap-1.5 mb-4">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setPrompt(s)}
              className="text-left bg-white/[0.04] border border-white/[0.08] rounded-md px-3 py-2 font-serif italic text-[13.5px] text-cream/85 hover:bg-white/[0.08] hover:text-cream transition-all hover:translate-x-0.5"
            >
              {s}
            </button>
          ))}
        </div>

        <div className="bg-white/5 border border-white/10 rounded-lg flex items-center gap-2 p-1 px-2">
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Type your question…"
            className="flex-1 bg-transparent text-cream font-sans text-[13px] py-2.5 px-1.5 outline-none placeholder:text-cream/40 placeholder:italic"
          />
          <button
            onClick={send}
            disabled={thinking}
            className="bg-amber text-paper font-sans text-[13px] font-medium px-3.5 py-2 rounded-md hover:bg-amber-deep transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            {thinking ? "…" : "Ask →"}
          </button>
        </div>
      </div>
    </div>
  );
}
