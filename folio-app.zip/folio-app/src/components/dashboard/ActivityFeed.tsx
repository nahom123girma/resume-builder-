import type { Job } from "@prisma/client";
import { formatDate } from "@/lib/utils";

export function ActivityFeed({ jobs }: { jobs: Job[] }) {
  return (
    <div className="bg-paper border border-rule rounded-xl p-6">
      <div className="flex justify-between items-baseline mb-5 pb-4 border-b border-rule">
        <h3 className="font-serif text-[22px] font-medium tracking-tight">
          Recent <em className="italic text-amber">activity</em>
        </h3>
        <span className="font-mono text-[10.5px] text-ink-mute uppercase tracking-[0.06em]">last 7d</span>
      </div>

      {jobs.length === 0 ? (
        <div className="text-center py-12 text-ink-mute">
          <div className="font-serif italic text-[15px] mb-1.5">No activity yet.</div>
          <div className="text-[13px]">Add your first job to start tracking.</div>
        </div>
      ) : (
        <ol className="flex flex-col gap-3.5 relative">
          {jobs.map((job, i) => (
            <li key={job.id} className="grid grid-cols-[80px_1fr_auto] items-baseline gap-3 pb-3 border-b border-dashed border-rule last:border-0">
              <span className="font-mono text-[10.5px] text-ink-mute uppercase tracking-[0.06em]">
                {formatDate(job.updatedAt)}
              </span>
              <span className="font-serif text-[14px] leading-snug">
                <strong className="font-medium text-ink">{job.title}</strong>
                <span className="text-ink-soft"> — {job.company}</span>
                <em className="italic text-ink-mute"> · {actionLabel(job)}</em>
              </span>
              <span className={`font-mono text-[10px] uppercase tracking-[0.1em] px-2 py-0.5 rounded ${tagColor(job.status)}`}>
                {job.status}
              </span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function actionLabel(job: Job): string {
  if (job.status === "INTERVIEW") return "interview scheduled";
  if (job.status === "OFFER") return "received an offer";
  if (job.status === "REJECTED") return "rejected";
  if (job.status === "APPLIED") return "applied";
  return "saved";
}

function tagColor(status: string): string {
  switch (status) {
    case "INTERVIEW": return "bg-amber-soft text-amber-deep";
    case "OFFER": return "bg-moss-soft text-moss";
    case "REJECTED": return "bg-brick-soft text-brick";
    case "APPLIED": return "bg-clay-soft text-clay";
    default: return "bg-cream-2 text-ink-mute";
  }
}
