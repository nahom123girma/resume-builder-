"use client";

import Link from "next/link";

export function AppTopbar({ user }: { user: { name?: string | null; email: string } }) {
  const initial = (user.name?.[0] ?? user.email[0]).toUpperCase();

  return (
    <header className="bg-cream/80 backdrop-blur-md border-b border-rule flex items-center px-5 gap-5 z-30">
      <div className="flex items-center gap-4">
        <Link href="/" className="flex items-baseline gap-1.5 font-serif text-2xl font-semibold tracking-tighter">
          Folio<span className="self-center w-1.5 h-1.5 rounded-full bg-amber inline-block ml-0.5" />
        </Link>
      </div>

      <button className="flex-1 max-w-[480px] mx-auto flex items-center gap-3 bg-paper border border-rule rounded-lg px-3.5 py-1.5 hover:border-ink-mute transition-colors">
        <span className="text-ink-mute text-sm">⌕</span>
        <span className="text-ink-mute text-sm font-serif italic flex-1 text-left">Search jobs, résumés, or ask the assistant…</span>
        <span className="font-mono text-[10.5px] bg-cream-2 border border-rule px-1.5 py-px rounded text-ink-soft">⌘ K</span>
      </button>

      <div className="flex items-center gap-1.5">
        <button className="w-9 h-9 rounded-lg grid place-items-center text-ink-soft hover:bg-cream-2 hover:text-ink transition-colors">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
          </svg>
        </button>
        <div className="w-8 h-8 rounded-full bg-amber grid place-items-center font-serif font-medium text-sm text-paper cursor-pointer ml-1">
          {initial}
        </div>
      </div>
    </header>
  );
}
