"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV_GROUPS = [
  {
    title: "Studio",
    items: [
      { label: "Home", icon: "⌂", href: "/dashboard" },
      { label: "Composer", icon: "✎", href: "/composer", count: null },
      { label: "PDF Tools", icon: "▤", href: "/pdf-tools" },
      { label: "Job Tracker", icon: "⊞", href: "/jobs" },
      { label: "Cover Letters", icon: "✉", href: "/letters" },
      { label: "Assistant", icon: "✦", href: "/assistant" },
    ],
  },
  {
    title: "Library",
    items: [
      { label: "Templates", icon: "▦", href: "/templates" },
      { label: "Settings", icon: "⚙", href: "/settings" },
    ],
  },
] as const;

export function AppSidebar() {
  const pathname = usePathname();

  return (
    <aside className="bg-cream-2 border-r border-rule p-5 px-3.5 overflow-y-auto flex flex-col gap-7">
      {NAV_GROUPS.map((group) => (
        <div key={group.title}>
          <h5 className="font-mono text-[10px] font-medium tracking-[0.16em] uppercase text-ink-mute px-2.5 mb-2.5 before:content-['✦_'] before:text-amber">
            {group.title}
          </h5>
          <div className="flex flex-col gap-px">
            {group.items.map((item) => {
              const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-2.5 py-2 rounded-md text-[13.5px] transition-all",
                    active ? "bg-ink text-paper" : "text-ink-soft hover:bg-paper hover:text-ink"
                  )}
                >
                  <span className="w-4 grid place-items-center font-serif italic text-[13px]">{item.icon}</span>
                  <span className="flex-1">{item.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      ))}

      {/* Pro tip card */}
      <div className="mt-auto bg-paper border border-rule rounded-xl p-4 px-4 relative">
        <div className="font-mono text-[10px] text-amber tracking-[0.16em] uppercase mb-2 flex items-center gap-1.5 before:content-[''] before:w-[18px] before:h-px before:bg-amber">
          Pro tip
        </div>
        <h6 className="font-serif text-[19px] font-medium tracking-tight leading-tight mb-2">
          Tailor before<br />you <em className="italic text-amber">apply</em>.
        </h6>
        <p className="text-[12.5px] text-ink-soft leading-relaxed mb-3">
          Pro users see 4× more callbacks when résumés are tailored per job description.
        </p>
        <Link href="/pricing" className="text-[12.5px] text-ink font-medium border-b border-ink pb-px hover:text-amber hover:border-amber transition-colors">
          Try it free →
        </Link>
      </div>
    </aside>
  );
}
