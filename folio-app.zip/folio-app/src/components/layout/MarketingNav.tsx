"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

export function MarketingNav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={cn(
        "sticky top-0 z-50 backdrop-blur-md bg-cream/80 transition-colors",
        scrolled ? "border-b border-rule" : "border-b border-transparent"
      )}
    >
      <div className="container-page flex items-center justify-between py-[18px]">
        <Link href="/" className="flex items-baseline gap-1.5 font-serif text-2xl font-semibold tracking-tighter">
          Folio
          <span className="self-center w-[7px] h-[7px] rounded-full bg-amber inline-block ml-0.5" />
        </Link>

        <div className="hidden md:flex gap-8 text-sm text-ink-soft">
          <Link href="#templates" className="relative py-1 hover:text-ink transition-colors">Templates</Link>
          <Link href="#features" className="relative py-1 hover:text-ink transition-colors">Features</Link>
          <Link href="/pdf-tools" className="relative py-1 hover:text-ink transition-colors">PDF Tools</Link>
          <Link href="/jobs" className="relative py-1 hover:text-ink transition-colors">Job Search</Link>
          <Link href="/pricing" className="relative py-1 hover:text-ink transition-colors">Pricing</Link>
        </div>

        <div className="flex items-center gap-3.5">
          <Link href="/login" className="btn btn-ghost hidden md:inline-flex">Log in</Link>
          <Link href="/signup" className="btn btn-ink">Get started</Link>
        </div>
      </div>
    </nav>
  );
}
