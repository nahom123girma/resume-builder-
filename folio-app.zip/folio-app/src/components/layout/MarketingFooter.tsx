import Link from "next/link";

export function MarketingFooter() {
  return (
    <footer className="border-t border-rule pt-12 pb-8 bg-cream-2 text-sm">
      <div className="container-page">
        <div className="grid grid-cols-2 md:grid-cols-[1.4fr_1fr_1fr_1fr] gap-9 md:gap-12 mb-10">
          <div>
            <Link href="/" className="flex items-baseline gap-1.5 font-serif text-2xl font-semibold tracking-tighter">
              Folio<span className="self-center w-[7px] h-[7px] rounded-full bg-amber inline-block ml-0.5" />
            </Link>
            <p className="font-serif italic text-base text-ink-soft max-w-[280px] leading-snug mt-3.5">
              "The career and document studio for people who give a damn about how their work looks."
            </p>
          </div>

          <FootCol title="Product" links={[
            ["Resume Builder", "/composer"],
            ["Cover Letters", "/letters"],
            ["PDF Tools", "/pdf-tools"],
            ["Job Search", "/jobs"],
            ["Application Tracker", "/dashboard"],
          ]} />

          <FootCol title="Tools" links={[
            ["PDF to Word", "/pdf-tools/pdf-to-word"],
            ["Word to PDF", "/pdf-tools/word-to-pdf"],
            ["Merge PDF", "/pdf-tools/merge"],
            ["Compress PDF", "/pdf-tools/compress"],
            ["OCR Scanner", "/pdf-tools/ocr"],
          ]} />

          <FootCol title="Company" links={[
            ["About", "/about"],
            ["Blog", "/blog"],
            ["Careers", "/careers"],
            ["Privacy", "/privacy"],
            ["Terms", "/terms"],
          ]} />
        </div>
        <div className="pt-6 border-t border-rule flex justify-between items-center text-ink-mute text-[13px] flex-wrap gap-3.5">
          <span>© 2026 Folio Studio Inc. Designed in Brooklyn. Typeset everywhere.</span>
          <span className="font-mono">v1.0 · Last shipped 2 days ago</span>
        </div>
      </div>
    </footer>
  );
}

function FootCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h5 className="font-mono text-[11px] tracking-[0.16em] uppercase text-ink-mute mb-4 font-medium">{title}</h5>
      <ul className="flex flex-col gap-2.5">
        {links.map(([label, href]) => (
          <li key={href}>
            <Link href={href} className="text-ink-soft hover:text-amber transition-colors">{label}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
