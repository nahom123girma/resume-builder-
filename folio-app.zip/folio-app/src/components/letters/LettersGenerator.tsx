"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

interface Props {
  resumes: { id: string; title: string }[];
}

export function LettersGenerator({ resumes }: Props) {
  const router = useRouter();
  const [resumeId, setResumeId] = useState(resumes[0]?.id ?? "");
  const [jd, setJd] = useState("");
  const [generating, setGenerating] = useState(false);
  const [draft, setDraft] = useState<string | null>(null);

  async function generate() {
    if (!resumeId || jd.trim().length < 50) return;
    setGenerating(true);
    setDraft(null);

    const res = await fetch("/api/ai/cover-letter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resumeId, jobDescription: jd }),
    });
    setGenerating(false);
    if (!res.ok) {
      const j = await res.json();
      alert(j.error ?? "Generation failed");
      return;
    }
    const { letter } = await res.json();
    setDraft(letter.content);
    router.refresh(); // refresh the list
  }

  if (resumes.length === 0) {
    return (
      <div className="bg-paper border border-dashed border-rule rounded-xl p-9 text-center">
        <div className="font-serif text-[18px] mb-1.5">You need a résumé first.</div>
        <p className="text-[13.5px] text-ink-mute mb-4">
          Cover letters are tailored against your résumé content.
        </p>
        <a href="/composer" className="btn btn-amber">+ Create a résumé</a>
      </div>
    );
  }

  return (
    <div className="bg-paper border border-rule rounded-xl p-6">
      <h2 className="font-serif text-[22px] font-medium tracking-tight mb-1">
        Generate a <em className="italic text-amber">letter</em>
      </h2>
      <p className="text-[13px] text-ink-mute font-serif italic mb-5">
        Paste a job description below. We'll match it to your résumé.
      </p>

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-1">
          <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">Résumé</label>
          <select
            value={resumeId}
            onChange={(e) => setResumeId(e.target.value)}
            className="bg-cream-2 border border-rule rounded-md px-2.5 py-2 text-[14px] focus:border-ink outline-none"
          >
            {resumes.map((r) => (
              <option key={r.id} value={r.id}>{r.title}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">Job description</label>
          <textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            rows={10}
            placeholder="Paste the full JD here. The more context, the better the letter."
            className="bg-cream-2 border border-rule rounded-md px-3 py-2.5 text-[13.5px] font-serif resize-y min-h-[200px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
          />
          <div className="text-[11px] text-ink-mute font-mono mt-1">
            {jd.trim().length} chars{" "}
            {jd.trim().length < 50 && jd.length > 0 && (
              <span className="text-amber"> · need at least 50</span>
            )}
          </div>
        </div>

        <button
          onClick={generate}
          disabled={generating || !resumeId || jd.trim().length < 50}
          className="btn btn-amber justify-center disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {generating ? "Drafting…" : "✦ Generate letter"}
        </button>

        {draft && (
          <div className="mt-4">
            <div className="font-mono text-[10px] uppercase tracking-[0.16em] text-moss font-medium mb-2 flex items-center gap-1.5 before:content-[''] before:w-3 before:h-px before:bg-moss">
              Draft saved
            </div>
            <div className="bg-cream-2 border border-rule rounded-lg p-5 font-serif text-[14px] leading-relaxed whitespace-pre-wrap">
              {draft}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
