"use client";

import { useState, useRef, useCallback } from "react";
import Link from "next/link";

interface Props {
  letterId: string;
  initialTitle: string;
  initialContent: string;
}

export function LetterEditor({ letterId, initialTitle, initialContent }: Props) {
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState(initialContent);
  const [saveState, setSaveState] = useState<"saved" | "saving" | "dirty">("saved");
  const [copied, setCopied] = useState(false);
  const saveTimer = useRef<NodeJS.Timeout | null>(null);

  const triggerSave = useCallback((nextTitle: string, nextContent: string) => {
    setSaveState("dirty");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaveState("saving");
      await fetch(`/api/letters/${letterId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: nextTitle, content: nextContent }),
      });
      setSaveState("saved");
    }, 700);
  }, [letterId]);

  function copyAll() {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="px-9 py-8 pb-16 max-w-[760px]">
      <Link href="/letters" className="font-mono text-[11px] uppercase tracking-[0.12em] text-ink-mute hover:text-amber mb-6 inline-block">
        ← All letters
      </Link>

      <div className="flex items-center justify-between gap-3 mb-6 pb-4 border-b border-rule">
        <input
          value={title}
          onChange={(e) => { setTitle(e.target.value); triggerSave(e.target.value, content); }}
          className="font-serif text-[28px] font-medium tracking-tight bg-transparent border-0 outline-none flex-1 max-w-[60%]"
        />
        <div className="flex items-center gap-3">
          <SaveIndicator state={saveState} />
          <button onClick={copyAll} className="btn btn-outline text-xs">
            {copied ? "✓ Copied" : "Copy text"}
          </button>
        </div>
      </div>

      <textarea
        value={content}
        onChange={(e) => { setContent(e.target.value); triggerSave(title, e.target.value); }}
        rows={28}
        className="w-full bg-paper border border-rule rounded-xl p-7 font-serif text-[15px] leading-relaxed resize-y min-h-[600px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
      />
    </div>
  );
}

function SaveIndicator({ state }: { state: "saved" | "saving" | "dirty" }) {
  const map = {
    saved: { dot: "bg-moss", label: "Saved" },
    saving: { dot: "bg-amber animate-pulse-soft", label: "Saving…" },
    dirty: { dot: "bg-clay", label: "Unsaved" },
  };
  const { dot, label } = map[state];
  return (
    <div className="flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-[0.06em] text-ink-mute">
      <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
      {label}
    </div>
  );
}
