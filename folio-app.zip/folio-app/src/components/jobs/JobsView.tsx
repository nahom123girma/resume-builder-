"use client";

import { useState } from "react";
import type { Job, JobStatus } from "@prisma/client";
import { Kanban } from "@/components/dashboard/Kanban";

interface Props {
  initial: Record<JobStatus, Job[]>;
}

export function JobsView({ initial }: Props) {
  const [showModal, setShowModal] = useState(false);
  const [jobs, setJobs] = useState(initial);

  async function createJob(data: {
    title: string;
    company: string;
    location?: string;
    url?: string;
    status: JobStatus;
    description?: string;
    salaryRange?: string;
  }) {
    const res = await fetch("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      alert("Failed to create job");
      return;
    }
    const { job } = await res.json();
    setJobs((prev) => ({ ...prev, [job.status as JobStatus]: [job, ...prev[job.status as JobStatus]] }));
    setShowModal(false);
  }

  const total = Object.values(jobs).flat().length;

  return (
    <div className="px-9 py-8 pb-16">
      <div className="flex justify-between items-end mb-8 pb-7 border-b border-rule flex-wrap gap-4">
        <div>
          <div className="eyebrow mb-3.5">Job tracker</div>
          <h1 className="font-serif text-[44px] font-normal tracking-tight leading-[1.05] mb-1.5">
            All your <em className="italic text-amber">applications</em>.
          </h1>
          <p className="text-ink-soft text-[15px]">
            {total} {total === 1 ? "job" : "jobs"} across the pipeline.
          </p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-amber">
          + Add job
        </button>
      </div>

      <Kanban jobs={jobs} />

      {showModal && <AddJobModal onClose={() => setShowModal(false)} onSubmit={createJob} />}
    </div>
  );
}

function AddJobModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (data: any) => void }) {
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data: any = {
      title: formData.get("title"),
      company: formData.get("company"),
      location: formData.get("location") || undefined,
      url: formData.get("url") || undefined,
      salaryRange: formData.get("salaryRange") || undefined,
      description: formData.get("description") || undefined,
      status: formData.get("status") || "SAVED",
    };
    Object.keys(data).forEach((k) => data[k] === "" && delete data[k]);
    await onSubmit(data);
    setLoading(false);
  }

  return (
    <div
      className="fixed inset-0 bg-ink/40 backdrop-blur-sm z-50 grid place-items-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-paper border border-rule rounded-2xl w-full max-w-[520px] p-7 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-baseline mb-6">
          <h2 className="font-serif text-[26px] font-medium tracking-tight">
            Add <em className="italic text-amber">job</em>
          </h2>
          <button onClick={onClose} className="text-ink-mute hover:text-ink text-lg">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <Field label="Job title" name="title" required />
          <Field label="Company" name="company" required />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Location" name="location" />
            <Field label="Salary range" name="salaryRange" placeholder="$120k - $150k" />
          </div>
          <Field label="Posting URL" name="url" type="url" placeholder="https://…" />
          <div className="flex flex-col gap-1">
            <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">Status</label>
            <select
              name="status"
              defaultValue="SAVED"
              className="bg-cream-2 border border-rule rounded-md px-2.5 py-2 text-[14px] focus:border-ink outline-none"
            >
              <option value="SAVED">Saved</option>
              <option value="APPLIED">Applied</option>
              <option value="INTERVIEW">Interview</option>
              <option value="OFFER">Offer</option>
              <option value="REJECTED">Rejected</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">
              Description (optional)
            </label>
            <textarea
              name="description"
              rows={4}
              placeholder="Paste the JD here for AI matching and tailoring…"
              className="bg-cream-2 border border-rule rounded-md px-3 py-2 text-[13.5px] font-serif resize-none focus:border-ink outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 mt-3">
            <button type="button" onClick={onClose} className="btn btn-outline">Cancel</button>
            <button type="submit" disabled={loading} className="btn btn-amber disabled:opacity-60">
              {loading ? "Adding…" : "Add job"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex flex-col gap-1">
      <label className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-mute">{label}</label>
      <input
        {...props}
        className="bg-cream-2 border border-rule rounded-md px-2.5 py-2 text-[14px] focus:border-ink focus:ring-2 focus:ring-ink/10 outline-none transition"
      />
    </div>
  );
}
