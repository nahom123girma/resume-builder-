# Folio

> The career & document studio. Résumés, cover letters, PDF tools, job tracking, AI assistant — in one editorial-warm interface.

A real, runnable Next.js codebase. Not a mockup. Clone, install, configure, ship.

---

## Quick start (5 minutes)

```bash
# 1. Install
npm install

# 2. Set up your env
cp .env.example .env
# Edit .env. For first run, the only required value is NEXTAUTH_SECRET.
# Generate one: openssl rand -base64 32

# 3. Push the schema to a local SQLite DB
npx prisma db push

# 4. Seed with demo data (optional but recommended)
npm run db:seed

# 5. Run the dev server
npm run dev
```

Then visit **http://localhost:3000**.

If you ran the seed, log in with:
- email: `demo@folio.studio`
- password: `password123`

---

## What's implemented

### ✅ Frontend
- **Landing page** with editorial-warm design system (paper grain, Fraunces serif, IBM Plex Sans, hand-drawn flourishes)
- **Pricing page** with 3 tiers and Stripe checkout
- **Auth pages** (signup, login) with credentials provider
- **Dashboard** with stats, kanban job tracker, activity feed, AI assistant panel
- **Composer** — full résumé editor with live preview, auto-save, AI rewrite buttons, real-time PDF/DOCX export
- **Job tracker** — drag-and-drop kanban with 5 status columns, add-job modal
- **PDF tools hub** + working merge & split tools
- **Cover letters** — generator + saved-letter editor with auto-save
- **Assistant** — streaming chat with the career assistant
- **Settings** — account info, plan, AI usage stats, account deletion
- **404 + global error boundary** with on-brand styling
- **Sitemap + robots.txt** generated programmatically

### ✅ Backend
- **Prisma schema** covering users, résumés (with version history), jobs, cover letters, PDF jobs, subscriptions, AI usage
- **NextAuth v5** with credentials provider (Google OAuth optional via env vars)
- **API routes** for résumé CRUD, AI rewrites, ATS scoring, cover letter generation + editing, **streaming AI chat**, job CRUD with status transitions, account update + delete, Stripe checkout + webhooks
- **PDF processing** with `pdf-lib` (merge, split — both client & server working)
- **Résumé export** to real PDF and real DOCX files

### ✅ AI integration
- **Anthropic SDK** wrapper with hand-tuned system prompts for: résumé bullet rewriting, summary rewriting, cover letter generation, ATS scoring, résumé tailoring
- **Token counting & cost tracking** — every AI call logged to `AiUsage` table with model, tokens, cents
- **Graceful fallback** — works in dev without `ANTHROPIC_API_KEY`, returns mock data so you can see the UI

### ✅ Stripe
- Checkout session creation with 7-day trial
- Webhook handler for subscription lifecycle events (created, updated, deleted)
- Plan auto-promotion to PRO on active subscription, demotion to FREE on cancel

---

## What's NOT implemented (yet)

The product spec is large. I prioritized making the core flows work end-to-end. These are next-up:

- **PDF tools 3-7**: compress, PDF↔Word, OCR, sign — UI shells exist, processing not wired. Compress needs Ghostscript or a service. PDF↔Word needs LibreOffice headless. OCR needs Tesseract or AWS Textract. Sign needs an image-overlay flow.
- **Job search engine** — the spec calls for aggregation across LinkedIn / Indeed / etc. The tracker currently is "you bring the job, we organize it." Realistic options for search: Adzuna API, USAJobs API, RemoteOK, or paid SerpAPI for Google Jobs.
- **Browser extension** — Manifest V3 extension to one-click-save jobs from LinkedIn/Indeed
- **Personal page** (`folio.cv/you`) — public résumé view, not built
- **Mock interview** — system prompt drafted in `lib/ai.ts`, no UI
- **Templates 2-18** — preview-only on landing; only the `Broadsheet` template renders fully in the composer
- **LinkedIn import** — extract structured data from a LinkedIn PDF export
- **File upload to S3/R2** — currently PDF tools process in-memory; for production scale, upload to storage and process as background jobs
- **Email** — verification, password reset, lifecycle emails (Resend SDK ready, templates not written)
- **Admin panel** — separate `/admin` route with role check
- **Programmatic SEO pages** — "PDF to Word", "Resume Examples for [job]"
- **Tests** — none yet. Recommend Playwright for E2E and Vitest for unit

---

## Production deployment

### Database
Switch from SQLite to Postgres in `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

Then `npx prisma migrate deploy`. Recommended hosts: Neon, Supabase, Railway, or RDS.

### Hosting
- **Vercel** is the easiest fit (auto-builds Next.js, edge runtime, environment variables)
- Set every value from `.env.example` in the Vercel project settings
- For PDF tools that exceed the 4.5MB Lambda body limit, deploy the API routes to a separate Node service or use Vercel's Fluid Compute

### Environment variables you MUST set in production
- `DATABASE_URL` — Postgres connection string
- `NEXTAUTH_SECRET` — `openssl rand -base64 32`
- `NEXTAUTH_URL` — your production URL
- `ANTHROPIC_API_KEY` — from console.anthropic.com (otherwise AI returns mocks)
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`, `STRIPE_PRICE_PRO_MONTHLY` — from Stripe dashboard

### Stripe webhook
Point `https://your-domain.com/api/stripe/webhook` at your Stripe webhook with these events:
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`

---

## Project structure

```
folio-app/
├── prisma/
│   ├── schema.prisma        # Full data model
│   └── seed.ts              # Demo user + sample jobs
├── src/
│   ├── app/
│   │   ├── (auth)/          # Login + signup
│   │   ├── (app)/           # Authenticated app shell + pages
│   │   │   ├── dashboard/
│   │   │   ├── composer/    # Resume editor (the main feature)
│   │   │   ├── jobs/
│   │   │   └── pdf-tools/
│   │   ├── api/             # All API routes
│   │   │   ├── ai/          # AI feature endpoints
│   │   │   ├── resumes/     # Resume CRUD
│   │   │   ├── jobs/        # Job tracker CRUD
│   │   │   ├── pdf/         # PDF processing
│   │   │   ├── export/      # Resume to PDF/DOCX
│   │   │   ├── stripe/      # Checkout + webhooks
│   │   │   └── auth/        # NextAuth + signup
│   │   ├── pricing/
│   │   ├── page.tsx         # Landing page
│   │   ├── layout.tsx
│   │   └── globals.css      # Design tokens, fonts, base styles
│   ├── components/
│   │   ├── landing/         # Hero, Templates, Features, etc.
│   │   ├── layout/          # Nav, sidebar, topbar
│   │   ├── composer/        # Resume editor + preview
│   │   ├── dashboard/       # Stats, Kanban, ActivityFeed, AssistantPanel
│   │   └── jobs/
│   ├── lib/
│   │   ├── db.ts            # Prisma singleton
│   │   ├── auth.ts          # NextAuth config
│   │   ├── ai.ts            # Anthropic SDK + system prompts
│   │   ├── stripe.ts        # Stripe client + plan limits
│   │   └── utils.ts         # cn(), formatDate()
│   └── types/
│       └── resume.ts        # ResumeContent type + sample data
└── tailwind.config.ts       # Editorial-warm design tokens
```

---

## Design system

Locked colors, fonts, and spacing live in `tailwind.config.ts` and `globals.css`. The aesthetic is what we called **editorial-warm**:

- **Palette**: cream `#F4EDE0`, paper `#FAF6EC`, ink `#1B1916`, amber `#C44A1A` (primary accent), moss `#3D5240`, clay `#A86B3D`, brick `#8E3320`
- **Type**: Fraunces (serif display, italic for emphasis), IBM Plex Sans (body), IBM Plex Mono (eyebrows, dates), Caveat (handwritten signatures)
- **Signature moves**: paper-grain SVG noise overlay (`body::before`), italic-amber emphasis on key words, mono uppercase eyebrows with horizontal rules, numbered prefixes (`№ 01`, `i.`, `ii.`), wavy hand-drawn underlines, hand-drawn arrow SVGs

To change the brand, edit those two files. The components consume tokens, so the whole product re-skins.

---

## License

Private / proprietary. No license granted.
