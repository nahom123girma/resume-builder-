import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // Editorial-warm palette — single source of truth
        cream: {
          DEFAULT: "#F4EDE0",
          2: "#EFE6D4",
        },
        paper: {
          DEFAULT: "#FAF6EC",
          2: "#F8F2E4",
        },
        ink: {
          DEFAULT: "#1B1916",
          soft: "#3A352D",
          mute: "#6E6557",
        },
        rule: {
          DEFAULT: "#D9CFB8",
          soft: "#E5DCC4",
        },
        amber: {
          DEFAULT: "#C44A1A",
          soft: "rgba(196, 74, 26, 0.10)",
          deep: "#9F3A13",
        },
        moss: {
          DEFAULT: "#3D5240",
          soft: "rgba(61, 82, 64, 0.10)",
        },
        clay: {
          DEFAULT: "#A86B3D",
          soft: "rgba(168, 107, 61, 0.10)",
        },
        brick: {
          DEFAULT: "#8E3320",
          soft: "rgba(142, 51, 32, 0.10)",
        },
      },
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
        hand: ['Caveat', 'cursive'],
      },
      letterSpacing: {
        tightest: '-0.04em',
        tighter: '-0.025em',
        tight: '-0.015em',
      },
      boxShadow: {
        soft: '0 1px 0 rgba(27,25,22,.04), 0 12px 30px -10px rgba(27,25,22,.12)',
        lg: '0 30px 80px -30px rgba(27,25,22,.28)',
      },
      animation: {
        'fade-up': 'fadeUp 0.8s cubic-bezier(.2,.8,.2,1)',
        'pulse-soft': 'pulse 1.5s ease-in-out infinite',
        'bob': 'bob 3s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(28px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        bob: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-3px)' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
