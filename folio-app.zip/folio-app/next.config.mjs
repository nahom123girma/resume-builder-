/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: '10mb', // for PDF uploads
    },
  },
};

export default nextConfig;
